package com.tdw.transaction.hlt.submit;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.model.constants.MessageState;
import com.tdw.transaction.model.constants.OverMark;
import com.tdw.transaction.model.constants.Thresholds;

/**
 * message-manage 启动参数： java -Dsend.thresholds=1,1,1,1,1,1,1,1,1,1  -Dpresend.back.thresholds=1,1,1,1,1,1 -jar
 * message-manage-0.0.1-SNAPSHOT.jar
 * 
 * @author jianggq
 *
 */
@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@DirtiesContext
@TestPropertySource(properties = { "server.port=11011" })
public class CreateTransactionMessageTest {
	private static final Logger logger = LoggerFactory.getLogger(CreateTransactionMessageTest.class);

	@Autowired
	private TestRestTemplate restTemplate;

	private String serviceUrl;

	@Before
	public void init() {
		serviceUrl = "http://127.0.0.1:8080/";
	}

	/**
	 * 场景： 提交消息创建消息成功，预发送回调确认， 回调成功，验证状态是否发送消息；
	 */
	@Test
	public void creatorMessageSuccessStateToSend() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("expectResult", "a");
		httpbodyMap.put("message", "hello world");
		httpbodyMap.put("messageTopic", "TeststringTopic");
		httpbodyMap.put("presendBackUrl", "http://127.0.0.1:11011/msg/messageid/check/success");
		httpbodyMap.put("resultBackUrl", "");
		httpbodyMap.put("serviceName", "hlt");
		httpbodyMap.put("expectResult", "a");
		httpbodyMap.put("expectResult", "a");

		// 创建消息成功
		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		Long transactionId = JSONObject.parseObject(response.getBody()).getLong("data");
		assertThat(transactionId).isNotNull();
		logger.info("======= 创建消息成功 ======= : {}" ,transactionId);

		// 查询消息是否正常回调执行
		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.PRESEND.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
				.isEqualTo(OverMark.ACTIVE.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getString("messageTopic"))
				.isEqualTo(httpbodyMap.get("messageTopic"));
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getString("serviceName"))
				.isEqualTo(httpbodyMap.get("serviceName"));
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getString("presendBackUrl"))
				.isEqualTo(httpbodyMap.get("presendBackUrl"));
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("presendBackThreshold"))
				.isEqualTo(Thresholds.MAX_PRESENDBACK.code());
		logger.info("======= 创建消息验证成功 =======");

		// 触发回调
		Thread.sleep(3000);
		response = this.restTemplate.exchange(serviceUrl + "/message/task/presend", HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 回调成功 =======");

		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isIn(MessageState.SEND.code(), MessageState.DIED.code(), MessageState.DONE.code());
		logger.info("======= 确认状态是否为： 发送 =======");

	}

	/**
	 * 场景： 提交消息创建消息成功，预发送回调确认， 重复回调超过阀值，异常消息，人工干预，废弃消息；
	 */
	@Test
	public void creatorMessageFailedStateToAbnomal() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("expectResult", "a");
		httpbodyMap.put("message", "hello world");
		httpbodyMap.put("messageTopic", "TeststringTopic");
		httpbodyMap.put("presendBackUrl", "http://127.0.0.1:11011/msg/messageid/check/failed");
		httpbodyMap.put("resultBackUrl", "");
		httpbodyMap.put("serviceName", "hlt");
		httpbodyMap.put("expectResult", "a");

		// 创建消息成功
		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		Long transactionId = JSONObject.parseObject(response.getBody()).getLong("data");
		assertThat(transactionId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		// 触发回调
		Thread.sleep(3000);
		response = this.restTemplate.exchange(serviceUrl + "/message/task/presend", HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 触发回调 =======");

		// 查询消息是否正常回调执行
		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("presendBackSendTimes"))
				.isEqualTo(1);
		logger.info("======= 查询消息是否正常回调执行 =======");

		// 触发回调，超过阀值
		for (int i = 0; i < 9; i++) {
			Thread.sleep(3000);
			response = this.restTemplate.exchange(serviceUrl + "/message/task/presend", HttpMethod.POST,
					new HttpEntity<String>(null, null), String.class);
			assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		}
		logger.info("======= 触发回调，超过阀值 =======");

		// 确认状态是否为： 异常消息
		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.ABNORMAL.code());
		logger.info("======= 确认状态是否为： 异常消息 =======");

		// 人工干预，废弃消息；
		response = this.restTemplate.exchange(serviceUrl + "/message/change/abnormal/" + + MessageState.DISCARD.code(), HttpMethod.POST,
				new HttpEntity<String>(String.valueOf(transactionId), null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 人工干预，废弃消息； =======");

		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.DISCARD.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
				.isEqualTo(OverMark.OVER.code());
		logger.info("======= 确认状态是否为： 废弃消息 =======");

	}

	/**
	 * 场景： 提交消息创建消息成功，预发送回调确认， 回调取消消息，验证是否废弃；
	 */
	@Test
	public void creatorMessageFailedStateToCancel() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("expectResult", "a");
		httpbodyMap.put("message", "hello world");
		httpbodyMap.put("messageTopic", "TeststringTopic");
		httpbodyMap.put("presendBackUrl", "http://127.0.0.1:11011/msg/messageid/check/rollback");
		httpbodyMap.put("resultBackUrl", "");
		httpbodyMap.put("serviceName", "hlt");
		httpbodyMap.put("expectResult", "a");
		httpbodyMap.put("expectResult", "a");

		// 创建消息成功
		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		Long transactionId = JSONObject.parseObject(response.getBody()).getLong("data");
		assertThat(transactionId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		// 触发回调
		Thread.sleep(3000);
		response = this.restTemplate.exchange(serviceUrl + "/message/task/presend", HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 回调取消消息 =======");

		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.DISCARD.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
				.isEqualTo(OverMark.OVER.code());
		logger.info("======= 确认状态是否为： 废弃消息 =======");

	}

}
