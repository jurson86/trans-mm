package com.tdw.transaction.hlt.consumer;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;
import java.util.Random;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.model.constants.MessageState;
import com.tdw.transaction.model.constants.OverMark;
import com.tdw.transaction.model.request.MessageIdAck;
import com.tdw.transaction.service.TransactionRocketMQConsumer;
import com.tdw.transaction.service.TransactionRocketMQConsumer2;

/**
 * message-manage 启动参数： java -Dsend.thresholds=1,1,1,1,1,1,1,1,1,1
 * -Dpresend.back.thresholds=1,1,1,1,1,1 -jar message-manage-0.0.1-SNAPSHOT.jar
 * 
 * @author jianggq
 *
 */
@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@DirtiesContext
@TestPropertySource(properties = { "server.port=11011" })
public class ConsumerTransactionMessageTest {
	private static final Logger logger = LoggerFactory.getLogger(ConsumerTransactionMessageTest.class);

	@Autowired
	private TestRestTemplate restTemplate;

	private String serviceUrl;

	@Before
	public void init() {
		serviceUrl = "http://127.0.0.1:8080/";
	}
	

	private Random random = new Random();

	/**
	 * 【注： 此场景需要正常啟動 消息服务】 场景： 提交消息创建消息成功，确认成功，消息消费成功。
	 */
	@Test
	public void consumerMessageSuccess() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("expectResult", "a");
		httpbodyMap.put("message", "hello world");
		//测试消息消费
		httpbodyMap.put("messageTopic", "HLTConsumerTestTopic");
		httpbodyMap.put("presendBackUrl", "http://127.0.0.1:11011/msg/messageid/check/success");
		httpbodyMap.put("resultBackUrl", "");
		httpbodyMap.put("serviceName", "hlt");
		httpbodyMap.put("expectResult", "a");

		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		Long transactionId = JSONObject.parseObject(response.getBody()).getLong("data");
		assertThat(transactionId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		MessageIdAck messageIdAck = new MessageIdAck();
		messageIdAck.setTransactionId(Long.valueOf(transactionId));
		response = restTemplate.exchange(serviceUrl + "/message/send/true", HttpMethod.POST,
				new HttpEntity<MessageIdAck>(messageIdAck, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 确认消息成功 =======");

		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
		.isIn(MessageState.DONE.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
		.isIn(OverMark.OVER.code());
		logger.info("======= 确认状态是否为： 完成 =======");
		
		while(TransactionRocketMQConsumer.MESSAGE_RESULT == 0 )
		{
			Thread.sleep(1000);
			logger.info("======= 检测数据是否正常消费 =======");			
		}

	}
	

	/**
	 * 【注： 此场景需要正常啟動 消息服务】 场景： 提交消息创建消息成功，确认成功，消息消费异常，不需要結果稽核回調；
	 */
	@Test
	public void consumerMessageFailed() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("expectResult", "a");
    	int message_prefix = random.nextInt(9999);
    	TransactionRocketMQConsumer2.MESSAGE_BODY = String.valueOf(message_prefix );
		httpbodyMap.put("message", TransactionRocketMQConsumer2.MESSAGE_BODY);
		//测试消息消费
		httpbodyMap.put("messageTopic", "HLTConsumerTestTopicFailed");
		httpbodyMap.put("presendBackUrl", "http://127.0.0.1:11011/msg/messageid/check/success");
		httpbodyMap.put("resultBackUrl", "");
		httpbodyMap.put("serviceName", "hlt");
		httpbodyMap.put("expectResult", "a");

		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		Long transactionId = JSONObject.parseObject(response.getBody()).getLong("data");
		assertThat(transactionId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		MessageIdAck messageIdAck = new MessageIdAck();
		messageIdAck.setTransactionId(Long.valueOf(transactionId));
		response = restTemplate.exchange(serviceUrl + "/message/send/true", HttpMethod.POST,
				new HttpEntity<MessageIdAck>(messageIdAck, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 确认消息成功 =======");

		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
		.isIn(MessageState.DONE.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
		.isIn(OverMark.OVER.code());
		logger.info("======= 确认状态是否为： 完成 =======");
		
		//检测死信消息
//		while(TransactionRocketMQConsumer2.MESSAGE_RESULT != 100 )
//		{
//			Thread.sleep(60000);
//			logger.info("======= 检测消费异常，是否重复消费 ======= : {} 次" , TransactionRocketMQConsumer2.MESSAGE_RESULT);
//			logger.info("消费情况： \n {}",TransactionRocketMQConsumer2.consumerTime.toString());
//		}

	}
	
}
