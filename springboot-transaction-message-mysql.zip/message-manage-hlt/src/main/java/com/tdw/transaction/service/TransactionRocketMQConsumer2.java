package com.tdw.transaction.service;

import java.util.Date;
import java.util.HashMap;

import org.apache.rocketmq.common.message.MessageExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.qianmi.ms.starter.rocketmq.annotation.RocketMQMessageListener;
import com.qianmi.ms.starter.rocketmq.core.RocketMQListener;

@Component
@RocketMQMessageListener(topic = "HLTConsumerTestTopicFailed", consumerGroup = "transaction-group-2")
public class TransactionRocketMQConsumer2 implements RocketMQListener<MessageExt> {
	private static final Logger logger = LoggerFactory.getLogger(TransactionRocketMQConsumer2.class);

	public static Integer MESSAGE_RESULT = 0;
	
	public static String MESSAGE_BODY = "";
	
	public static HashMap<String,Date> consumerTime = new HashMap<String,Date>();

	public void onMessage(MessageExt messageExt) {
		if(MESSAGE_BODY.equals(new String(messageExt.getBody())))
		{
			MESSAGE_RESULT++;
			consumerTime.put(MESSAGE_RESULT.toString(), new Date());
			logger.info("TransactionRocketMQConsumer RuntimeException! ============= \n {}", messageExt);
			throw new RuntimeException("===== HLTConsumerTestTopicFailed ==== : " + new String(messageExt.getBody()));
		}
	}

}