package com.tdw.transaction.controller;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping(value = "/msg")
public class ApiController {

	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);


	/**
	 * 事务消息回调
	 */
	@RequestMapping(value = "/messageid/check/failed", method = RequestMethod.POST)
	public HashMap<String, Object> checkFailedListener(@RequestBody String body) {
        	logger.info("checkListener RuntimeException! ============= \n ");
            throw new RuntimeException("Could not find db");
	}

	/**
	 * 事务消息回调
	 */
	@RequestMapping(value = "/messageid/check/rollback", method = RequestMethod.POST)
	public HashMap<String, Object> checkRollbackListener(@RequestBody String body) {
		HashMap<String, Object> msg = new HashMap<String, Object>();

		logger.info("=======================messageid/check===========================body: {}", body);
		logger.info("TransactionExecuterImpl ROLLBACK_MESSAGE! =============>  " + body + "\n");
		msg.put("status", 204);
		msg.put("message", "rollback");
		return msg;
	}

	/**
	 * 事务消息回调
	 */
	@RequestMapping(value = "/messageid/check/success", method = RequestMethod.POST)
	public HashMap<String, Object> checkListener(@RequestBody String body) {
		HashMap<String, Object> msg = new HashMap<String, Object>();

		logger.info("TransactionExecuterImpl COMMIT_MESSAGE! =============>  " + body + "\n");
		msg.put("status", 200);
		msg.put("message", "commit");
		return msg;
	}


	/**
	 * 事务消息结果稽核
	 */
	@RequestMapping(value = "/messageid/check/result", method = RequestMethod.POST)
	public HashMap<String, Object> checkResultListener(@RequestBody String body) {
		HashMap<String, Object> msg = new HashMap<String, Object>();

		logger.info("TransactionExecuterImpl CHECK_RESULT! =============>  " + body + "\n");
		msg.put("status", 200);
		msg.put("message", "commit");
		return msg;
	}
		
}