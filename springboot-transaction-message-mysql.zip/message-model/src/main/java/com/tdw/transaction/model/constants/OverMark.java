package com.tdw.transaction.model.constants;

/**
 * 生命状态
 * @author jianggq
 *
 */
public enum OverMark {

	ACTIVE(false, "活动"), OVER(true, "结束");

	private final Boolean code;

	private final String message;

	OverMark(Boolean code, String message) {
		this.code = code;
		this.message = message;
	}

	public Boolean code() {
		return code;
	}

	public String message() {
		return message;
	}
		
}
