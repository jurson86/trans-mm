package com.tdw.transaction.model.request;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(value = "MessageIdAck")
public class MessageIdAck {

    @ApiModelProperty(value = "事物消息ID", required = true)
    @NotNull
    private Long transactionId;

    @ApiModelProperty(value = "消息")
    private String message;

    @ApiModelProperty(value = "期望结果")
    @Size(max = 10)
    private String expectResult;



    @Override
    public String toString() {
        return "MessageIdCreator{" +
                "transactionId=" + transactionId +
                ", message='" + message +
                ", expectResult='" + expectResult +
                '}';
    }

    

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getExpectResult() {
		return expectResult;
	}

	public void setExpectResult(String expectResult) {
		this.expectResult = expectResult;
	}

    
}
