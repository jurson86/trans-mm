package com.tdw.transaction.model.constants;

/**
 * 消息状态定义
 * @author jianggq
 *
 */
public enum MessageType {

	ACTIVE(0, "活动"), OVER(1, "结束");

	private final int code;

	private final String message;

	MessageType(int code, String message) {
		this.code = code;
		this.message = message;
	}

	public int code() {
		return code;
	}

	public String message() {
		return message;
	}
	
	public MessageType isValidCode(int _code)
	{
		return MessageType.valueOf("");
	}
	
}
