package com.tdw.transaction.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.service.AbnomalProcessMessageService;
import com.tdw.transaction.service.NomalProcessMessageService;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ ConsoleController.class,NomalProcessMessageService.class, AbnomalProcessMessageService.class })
public class ConsoleControllerTest {

	private static final Logger logger = LoggerFactory.getLogger(ConsoleControllerTest.class);

	@InjectMocks
	private ConsoleController consoleController;

	private MockMvc mvc;

	@Mock
	AbnomalProcessMessageService abnomalProcessMessageService;
	
	@Mock
	NomalProcessMessageService nomalProcessMessageService;

	@Before
	public void setUp() throws Exception {
		//将需要mock的对象预习准备好；
		consoleController = new ConsoleController();
		MockitoAnnotations.initMocks(this);
		//mock mvc 控制器
		mvc = MockMvcBuilders.standaloneSetup(consoleController).build();
	}
	

	@After
	public void tearDown() throws Exception {
		reset(nomalProcessMessageService);
		reset(abnomalProcessMessageService);
	}

	@Test
	public void messageStateCountTest() throws Exception {
		when(nomalProcessMessageService.getMessageStateCount(anyInt())).thenReturn(10);
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/monitor/30").contentType(MediaType.APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getInteger("data")).as("判断是否成功").isEqualTo(10);
        
	}
	
	@Test
	public void queryMessageListByStateTest() throws Exception {
		when(nomalProcessMessageService.queryTransactionMessageByState(anyInt())).thenReturn(null);
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/query/30").contentType(MediaType.APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getInteger("data")).as("判断是否成功").isEqualTo(null);
        
	}
	

	
	@Test
	public void queryMessageByTransactionIdTest() throws Exception {
		when(nomalProcessMessageService.getTransactionMessageById(anyLong())).thenReturn(null);
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/get/10001").contentType(MediaType.APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getInteger("data")).as("判断是否成功").isEqualTo(null);
        
	}
	


	
	@Test
	public void changeAbnormalTest1() throws Exception {
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/change/abnormal/10").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);
		//验证方法是否被执行
		verify(nomalProcessMessageService).updateMessageToPreSend(1001L);
		
		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isEqualTo("");
        
	}

	@Test
	public void changeAbnormalTest2() throws Exception {
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/change/abnormal/100").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);
		//验证方法是否被执行
		verify(nomalProcessMessageService).updateMessageToDiscard(1001L);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isEqualTo("");
        
	}

	@Test
	public void changeAbnormalTest3() throws Exception {
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/change/abnormal/30").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isNotNull();
	}
	


	@Test
	public void changeDiedTest1() throws Exception {
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/change/died/20").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		//验证方法是否被执行
		verify(nomalProcessMessageService).updateMessageToSend(1001L,null);
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isEqualTo("");
	}

	@Test
	public void changeDiedTest2() throws Exception {
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/change/died/100").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		//验证方法是否被执行
		verify(nomalProcessMessageService).updateMessageToDiscard(1001L);
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isEqualTo("");
	}


	@Test
	public void changeDiedTest3() throws Exception {
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/change/died/30").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isNotNull();
	}
	

	@Test
	public void messageResendTest() throws Exception {
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/resend").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		//验证方法是否被执行
		verify(abnomalProcessMessageService).resendMessageByTransactionId(1001);
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isEqualTo("");
	}
	

	@Test
	public void messageToDiscardTest() throws Exception {
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/discard").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content("1001,1002,1003"))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		//验证方法是否被执行
		verify(nomalProcessMessageService).updateMessageToDiscard(1001L);
		logger.info("===================> result: {}" ,resultstr);

		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getString("data")).as("判断是否成功").isEqualTo("");
	}

}
