package com.tdw.transaction.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.tdw.transaction.model.request.MessageIdCreator;
import com.tdw.transaction.service.AbnomalProcessMessageService;
import com.tdw.transaction.service.NomalProcessMessageService;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AbnomalProcessMessageService.class, NomalController.class })
public class NomalControllerTest {

	private static final Logger logger = LoggerFactory.getLogger(TaskControllerTest.class);

	@InjectMocks
	private NomalController nomalController;

	private MockMvc mvc;

	@Mock
	NomalProcessMessageService nomalProcessMessageService;
	
	MessageIdCreator messageIdCreator;
	
	private void init()
	{
		messageIdCreator = new MessageIdCreator();
		messageIdCreator.setExpectResult("a");
		messageIdCreator.setMessage("hello");
		messageIdCreator.setMessageTopic("test");
		messageIdCreator.setMessageType(0);
		messageIdCreator.setPresendBackUrl("http://1.1.1.1:0000");
		messageIdCreator.setResultBackUrl("");
		messageIdCreator.setServiceName("test");
	}

	@Before
	public void setUp() throws Exception {
		//初始化数据
		init();
		//将需要mock的对象预习准备好；
		nomalController = new NomalController();
		MockitoAnnotations.initMocks(this);
		//mock mvc 控制器
		mvc = MockMvcBuilders.standaloneSetup(nomalController).build();
	}
	

	@After
	public void tearDown() throws Exception {
		reset(nomalProcessMessageService);
	}

	@Test
	public void createMessageTest() throws Exception {
		when(nomalProcessMessageService.createMessage(anyObject())).thenReturn(100001L);
		
		//@ResponseBody标识 JSON字符串
		ObjectMapper mapper = new ObjectMapper();
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        java.lang.String requestJson = ow.writeValueAsString(messageIdCreator);
        
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/creator").contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(requestJson))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);
		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        assertThat(jo.getInteger("data")).as("判断是否成功").isEqualTo(100001);
        
	}
	
}
