package com.tdw.transaction.service.impl;

import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyMap;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.tdw.transaction.component.RocketMQHelper;
import com.tdw.transaction.component.ThresholdsTimeManage;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.exception.ServiceException;
import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;

public class AbnomalProcessMessageServiceImplTest {

	@InjectMocks
	private AbnomalProcessMessageServiceImpl abnomalProcessMessageService;
	@Mock
	private TransactionMessageRepository transactionMessageRepository;
	@Mock
	private OptLogRepository optLogRepository;
	@Mock
	private AbnomalThreadCallService abnomalThreadCallService;
	@Mock
	private RocketMQHelper rocketMQHelper;
	@Mock
	private ThresholdsTimeManage thresholdsTimeManage;

	// 预发送回调 TransactionMessage 列表
	TransactionMessage transactionMessage = null;
	List<TransactionMessage> findForPresendBackList = new ArrayList<TransactionMessage>();
	List<TransactionMessage> findForSendMQList = new ArrayList<TransactionMessage>();
	List<TransactionMessage> findForDoneBackList = new ArrayList<TransactionMessage>();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟

	ResponseEntity<String> responseOk = new ResponseEntity<String>("{'status':200}", HttpStatus.OK);

	@Before
	public void setUp() throws ParseException {
		// 初始化 findForPresendBackList 数据；
		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setMessageState(10);
		transactionMessage.setTransactionId(1000000001L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setMessageType(1);
		findForPresendBackList.add(transactionMessage);

		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setMessageState(10);
		transactionMessage.setTransactionId(1000000002L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setMessageType(1);
		findForPresendBackList.add(transactionMessage);

		

		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setMessageState(20);
		transactionMessage.setTransactionId(1000000003L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setMessageType(1);
		findForSendMQList.add(transactionMessage);

		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(0);
		transactionMessage.setMessageState(20);
		transactionMessage.setTransactionId(1000000004L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setMessageType(1);
		findForSendMQList.add(transactionMessage);
		

		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setMessageState(30);
		transactionMessage.setTransactionId(1000000005L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageType(0);
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		findForDoneBackList.add(transactionMessage);

		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setMessageState(30);
		transactionMessage.setTransactionId(1000000006L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageType(1);
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		findForDoneBackList.add(transactionMessage);
		
		abnomalProcessMessageService = new AbnomalProcessMessageServiceImpl();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(transactionMessageRepository);
		reset(abnomalThreadCallService);
		reset(optLogRepository);
		reset(rocketMQHelper);
		reset(thresholdsTimeManage);
	}

	/**
	 * [预发送回调]请求多线程调启
	 * 
	 * @throws Exception
	 */
	@Test
	public void preSendCallbackByTask_CallbackTrue() throws Exception {
		// stubbing
		when(transactionMessageRepository.findForPresendBack(anyMap())).thenReturn(findForPresendBackList);
		
		when(abnomalThreadCallService.presendCallback(anyObject())).thenReturn(true);
		
		abnomalProcessMessageService.preSendCallbackByTask();
		
	}

	/**
	 * [发送消息]消息发送，成功
	 */
	@Test
	public void sendToMQByTask_success() throws InterruptedException {

		when(transactionMessageRepository.findForSendMQ(anyMap())).thenReturn(findForSendMQList);
		
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());

		abnomalProcessMessageService.sendToMQByTask();
		verify(rocketMQHelper).sendTranTopicMsg(findForSendMQList.get(0));
	}
	
	/**
	 * [发送消息]消息发送，异常
	 */
	@Test
	public void sendToMQByTask_exception() throws InterruptedException {

		when(transactionMessageRepository.findForSendMQ(anyMap())).thenReturn(findForSendMQList);
		
		doThrow(new RuntimeException("error")).when(rocketMQHelper).sendTranTopicMsg(anyObject());
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());

		abnomalProcessMessageService.sendToMQByTask();
	}

	/**
	 * 结果回调多线程触发
	 */
	@Test
	public void resultCallbackByTask_success() throws InterruptedException {

		// stubbing
		when(transactionMessageRepository.findForDoneBack(anyMap())).thenReturn(findForDoneBackList);
		when(abnomalThreadCallService.presendCallback(anyObject())).thenReturn(true);

		abnomalProcessMessageService.resultCallbackByTask();
	}

	/**
	 * [发送消息]消息重新发送 成功
	 */
	@Test
	public void resendMessageByTransactionId_success() throws InterruptedException {
		transactionMessage.setMessageState(30);
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		//doThrow(new RuntimeException("error")).when(rocketMQHelper).sendTranTopicMsg(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());

		abnomalProcessMessageService.resendMessageByTransactionId(10001);
	}

	/**
	 * [发送消息]消息重新发送 INVALID_STATE_OPTION
	 */
	@Test(expected=ServiceException.class)
	public void resendMessageByTransactionId_invalid() throws InterruptedException {
		transactionMessage.setMessageState(100);
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());

		abnomalProcessMessageService.resendMessageByTransactionId(10001);
		
	}

	/**
	 * [发送消息]消息重新发送  rocketMQHelper Exception
	 */
	@Test(expected=ServiceException.class)
	public void resendMessageByTransactionId_exception() throws InterruptedException {
		transactionMessage.setMessageState(30);		
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doThrow(new RuntimeException("error")).when(rocketMQHelper).sendTranTopicMsg(anyObject());
		abnomalProcessMessageService.resendMessageByTransactionId(10001);
	}

}
