package com.tdw.transaction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.reset;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.tdw.transaction.component.RocketMQHelper;
import com.tdw.transaction.component.ThresholdsTimeManage;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AbnomalThreadCallService.class,RestTemplate.class,TransactionMessageRepository.class,OptLogRepository.class})
public class AbnomalThreadCallServiceTest {

	@InjectMocks
	private AbnomalThreadCallService abnomalThreadCallService;
	
	@Mock
	private TransactionMessageRepository transactionMessageRepository;

	@Mock
	private OptLogRepository optLogRepository;
	
	@Mock
	private RestTemplate thRestTemplate ;

	@Mock
	private ThresholdsTimeManage thresholdsTimeManage;

	@Mock
	private RocketMQHelper rocketMQHelper;
	
	// 预发送回调 TransactionMessage 列表
	TransactionMessage transactionMessage = new TransactionMessage();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟

	ResponseEntity<String> responseOk = null;

	@Before
	public void setUp() throws ParseException {
		// 初始化 transactionMessage 数据;
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("hello");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setTransactionId(1000000001L);
		transactionMessage.setPresendBackUrl("http://127.0.0.1:8090/");
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setMessageState(10);
		transactionMessage.setPresendBackThreshold(6);
		transactionMessage.setResultBackThreshod(3);
		transactionMessage.setMessageType(1);

		abnomalThreadCallService = new AbnomalThreadCallService();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(transactionMessageRepository);
		reset(optLogRepository);
	}

	/**
	 * [预发送回调]请求 success
	 * 
	 * @throws Exception
	 */
	@Test
	public void presendCallback_success() throws Exception {
		// stubbing
		responseOk = new ResponseEntity<String>("{'status':200}", HttpStatus.OK);
		thRestTemplate = PowerMockito.mock(RestTemplate.class); 
		PowerMockito.whenNew(RestTemplate.class).withAnyArguments().thenReturn(thRestTemplate);
		PowerMockito.when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);
		

		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		
		boolean result = abnomalThreadCallService.presendCallback(transactionMessage);

        assertThat(result).as("判断是否成功").isTrue();
	}

	/**
	 * [预发送回调]请求 discard
	 * 
	 * @throws Exception
	 */
	@Test
	public void presendCallback_discard() throws Exception {
		// stubbing
		responseOk = new ResponseEntity<String>("{'status':204}", HttpStatus.OK);
		thRestTemplate = PowerMockito.mock(RestTemplate.class); 
		PowerMockito.whenNew(RestTemplate.class).withAnyArguments().thenReturn(thRestTemplate);
		PowerMockito.when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);
		

		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		
		boolean result = abnomalThreadCallService.presendCallback(transactionMessage);

        assertThat(result).as("判断是否成功").isTrue();
	}

	/**
	 * [预发送回调]请求 failed
	 * 
	 * @throws Exception
	 */
	@Test
	public void presendCallback_failed() throws Exception {
		// stubbing
		thRestTemplate = PowerMockito.mock(RestTemplate.class); 
		PowerMockito.whenNew(RestTemplate.class).withAnyArguments().thenReturn(thRestTemplate);
		PowerMockito.when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenThrow(new RuntimeException());
		

		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		
		boolean result = abnomalThreadCallService.presendCallback(transactionMessage);

        assertThat(result).as("判断回调异常是否正确").isFalse();
	}

	


	/**
	 * [预发送回调]请求 success
	 * 
	 * @throws Exception
	 */
	@Test
	public void resultCallback_success() throws Exception {
		// stubbing
		responseOk = new ResponseEntity<String>("{'status':200}", HttpStatus.OK);
		thRestTemplate = PowerMockito.mock(RestTemplate.class); 
		PowerMockito.whenNew(RestTemplate.class).withAnyArguments().thenReturn(thRestTemplate);
		PowerMockito.when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);
		

		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		
		boolean result = abnomalThreadCallService.resultCallback(transactionMessage);

        assertThat(result).as("判断是否成功").isTrue();
	}

	/**
	 * [预发送回调]请求 failed
	 * 
	 * @throws Exception
	 */
	@Test
	public void resultCallback_failed() throws Exception {
		// stubbing
		thRestTemplate = PowerMockito.mock(RestTemplate.class); 
		PowerMockito.whenNew(RestTemplate.class).withAnyArguments().thenReturn(thRestTemplate);
		PowerMockito.when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenThrow(new RuntimeException("test exception error"));
		

		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		
		boolean result = abnomalThreadCallService.resultCallback(transactionMessage);

        assertThat(result).as("判断回调异常是否正确").isFalse();
	}
	
}
