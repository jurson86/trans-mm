package com.tdw.transaction.config;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest
@TestPropertySource(
	    properties = { "presend.back.threshods=1200,600,60,30,10,8","result.back.threshods=30" }
	)
public class SpringBootConfigTest {
private static final Logger logger = LoggerFactory.getLogger(SpringBootConfigTest.class);
	

    @Value("${presend.back.threshods}")
    String preSendBackThreshodstr;
    
    @Autowired
    SpringBootConfig springBootConfig;
    
    @Test
    public void getvalue()
    {
    	logger.info("====> : " + springBootConfig.getPreSendBackThresholdstr());
    }
    
}
