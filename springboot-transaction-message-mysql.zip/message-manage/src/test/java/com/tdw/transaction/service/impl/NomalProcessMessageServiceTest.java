package com.tdw.transaction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.component.RocketMQHelper;
import com.tdw.transaction.component.ThresholdsTimeManage;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.exception.ServiceException;
import com.tdw.transaction.model.constants.MessageState;
import com.tdw.transaction.model.request.MessageIdCreator;
import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;

public class NomalProcessMessageServiceTest {

	@InjectMocks
	private NomalProcessMessageServiceImpl nomalProcessMessageServiceImpl;
	@Mock
	private TransactionMessageRepository transactionMessageRepository;
	@Mock
	private OptLogRepository optLogRepository;
	@Mock
	private RocketMQHelper rocketMQHelper;
	@Mock
	private ThresholdsTimeManage thresholdsTimeManage;
	@Mock
	private RestTemplate restTemplate;

	// 预发送回调 TransactionMessage 列表
	MessageIdCreator messageIdCreator = null;
	TransactionMessage transactionMessage = null;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟

	ResponseEntity<String> responseOk = new ResponseEntity<String>("{'status':200}", HttpStatus.OK);

	@Before
	public void setUp() throws ParseException {

		messageIdCreator = new MessageIdCreator();
		messageIdCreator.setExpectResult("a");
		messageIdCreator.setMessage("{}");
		messageIdCreator.setMessageTopic("TestTopic");
		messageIdCreator.setMessageType(0);
		messageIdCreator.setPresendBackUrl("http://1.1.1.1:0000");
		messageIdCreator.setResultBackUrl("http://1.1.1.1:0000");
		messageIdCreator.setServiceName("test");
		
		transactionMessage = new TransactionMessage();
		transactionMessage.setServiceName("test");
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setExpectResult("a");
		transactionMessage.setMessage("{}");
		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionMessage.setMessageSendThreshold(10);
		transactionMessage.setMessageState(10);
		transactionMessage.setTransactionId(1000000001L);
		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setMessageState(10);
		transactionMessage.setPresendBackThreshold(6);
		transactionMessage.setResultBackThreshod(3);
		transactionMessage.setMessageType(1);
		
		nomalProcessMessageServiceImpl = new NomalProcessMessageServiceImpl();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(transactionMessageRepository);
		reset(optLogRepository);
		reset(rocketMQHelper);
		reset(thresholdsTimeManage);
	}

	@Test(expected=ServiceException.class)
	public void createMessage_exception() throws Exception {
		// stubbing : Id is generaled by db so asset is zero.
		doNothing().when(transactionMessageRepository).insert(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		nomalProcessMessageServiceImpl.createMessage(messageIdCreator);
	}
	

	@Test
	public void updateMessageToSend_success() throws Exception {
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.updateMessageToSend(10001L,"hello");

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.DONE.code());
	}

	@Test
	public void updateMessageToSend_sendFailed() throws Exception {
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doThrow(new RuntimeException("test exception ")).when(rocketMQHelper).sendTranTopicMsg(anyObject());
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.updateMessageToSend(10001L,"hello");

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.SEND.code());
	}
	

	@Test
	public void updateMessageToDiscard_success() throws Exception {
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.updateMessageToDiscard(10001L);

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.DISCARD.code());
	}
	

	@Test
	public void getTransactionMessageById_success() throws Exception {
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		
		TransactionMessage result = nomalProcessMessageServiceImpl.getTransactionMessageById(10001L);

        assertThat(result).as("判断是否成功").isNotNull();
	}
	

	@Test
	public void updateMessageToPreSend_success() throws Exception {
		transactionMessage.setMessageState(MessageState.ABNORMAL.code());
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.updateMessageToPreSend(10001L);

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.PRESEND.code());
	}

	@Test(expected=ServiceException.class)
	public void updateMessageToPreSend_failed() throws Exception {
		transactionMessage.setMessageState(MessageState.SEND.code());
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		nomalProcessMessageServiceImpl.updateMessageToPreSend(10001L);
	}
	

	@Test
	public void updateMessageToAbnormal_success() throws Exception {
		transactionMessage.setMessageState(MessageState.PRESEND.code());
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.updateMessageToAbnormal(10001L);

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.ABNORMAL.code());
	}


	@Test(expected=ServiceException.class)
	public void updateMessageToAbnormal_failed() throws Exception {
		transactionMessage.setMessageState(MessageState.SEND.code());
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		nomalProcessMessageServiceImpl.updateMessageToAbnormal(10001L);
	}
	

	@Test
	public void updateMessageToDied_success() throws Exception {
		transactionMessage.setMessageState(MessageState.SEND.code());
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.updateMessageToDied(10001L);

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.DIED.code());
	}


	@Test(expected=ServiceException.class)
	public void updateMessageToDied_failed() throws Exception {
		transactionMessage.setMessageState(MessageState.PRESEND.code());
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		nomalProcessMessageServiceImpl.updateMessageToDied(10001L);
	}
	
	


	@Test
	public void resultToDone_success() throws Exception {
		transactionMessage.setMessageState(MessageState.SEND.code());
		transactionMessage.setResult("");
		transactionMessage.setExpectResult("a");
		JSONObject msgJo = new JSONObject();
		msgJo.put("messageId", transactionMessage.getTransactionId());
		msgJo.put("message", "a");
		
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		when(restTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);
		
		TransactionMessage result = nomalProcessMessageServiceImpl.resultToDone(msgJo);

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.DONE.code());
	}
	

	@Test
	public void resultToDone_needMoreResult() throws Exception {
		transactionMessage.setMessageState(MessageState.SEND.code());
		transactionMessage.setResult("a");
		transactionMessage.setExpectResult("abc");
		JSONObject msgJo = new JSONObject();
		msgJo.put("messageId", transactionMessage.getTransactionId());
		msgJo.put("message", "b");
		
		when(transactionMessageRepository.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		doNothing().when(transactionMessageRepository).update(anyObject());
		doNothing().when(optLogRepository).save(anyObject());
		
		TransactionMessage result = nomalProcessMessageServiceImpl.resultToDone(msgJo);

        assertThat(result.getMessageState()).as("判断是否成功").isEqualTo(MessageState.SEND.code());
	}
	
	

	@Test
	public void getMessageStateCount_success() throws Exception {		
		when(transactionMessageRepository.messageStateCount(anyInt())).thenReturn(10);

		int result = nomalProcessMessageServiceImpl.getMessageStateCount(10);

        assertThat(result).as("判断是否成功").isEqualTo(10);
	}
	


	@Test
	public void queryTransactionMessageByState_success() throws Exception {		
		when(transactionMessageRepository.findByMessageState(anyInt())).thenReturn(new ArrayList<TransactionMessage>());

		List<TransactionMessage> result = nomalProcessMessageServiceImpl.queryTransactionMessageByState(10);

        assertThat(result).as("判断是否成功").isNotNull();
	}
	
}
