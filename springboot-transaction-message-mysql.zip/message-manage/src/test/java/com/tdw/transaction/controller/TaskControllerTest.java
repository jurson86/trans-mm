package com.tdw.transaction.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.reset;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.service.AbnomalProcessMessageService;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AbnomalProcessMessageService.class, TaskController.class })
public class TaskControllerTest {

	private static final Logger logger = LoggerFactory.getLogger(TaskControllerTest.class);

	@InjectMocks
	private TaskController taskController;

	private MockMvc mvc;

	@Mock
	AbnomalProcessMessageService abnomalProcessMessageService;

	@Before
	public void setUp() throws Exception {
		//将需要mock的对象预习准备好；
		taskController = new TaskController();
		MockitoAnnotations.initMocks(this);
		//mock mvc 控制器
		mvc = MockMvcBuilders.standaloneSetup(taskController).build();
	}
	

	@After
	public void tearDown() throws Exception {
		reset(abnomalProcessMessageService);
	}

	@Test
	public void presendTaskTest() throws Exception {
		doNothing().when(abnomalProcessMessageService).preSendCallbackByTask();
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/task/presend").contentType(MediaType.APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);
				//.andDo(MockMvcResultMatchers.content().toString());
		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        
	}
	

	@Test
	public void sendTask() throws Exception {
		doNothing().when(abnomalProcessMessageService).sendToMQByTask();
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/task/send").contentType(MediaType.APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);
				//.andDo(MockMvcResultMatchers.content().toString());
		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        
	}
	

	@Test
	public void doneTask() throws Exception {
		doNothing().when(abnomalProcessMessageService).resultCallbackByTask();
		String resultstr = mvc.perform(MockMvcRequestBuilders.post("/message/task/done").contentType(MediaType.APPLICATION_JSON_UTF8)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andDo(MockMvcResultHandlers.print())
                .andReturn()
                .getResponse()
                .getContentAsString();
		logger.info("===================> result: {}" ,resultstr);
				//.andDo(MockMvcResultMatchers.content().toString());
		JSONObject jo = JSONObject.parseObject(resultstr);
        assertThat(jo.getInteger("status")).as("判断是否成功").isEqualTo(200);
        
	}
	
	

}
