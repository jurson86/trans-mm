package com.tdw.transaction.repository;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.tdw.transaction.domain.TransactionMessage;

@Mapper
public interface TransactionMessageRepository {

    void createIfNotExistsTable();
    
    void truncateTable();
        
    void delete(Long transactionId);
    
    void dropTable();

    
	void insert(TransactionMessage transactionMessage);
    
	void update(TransactionMessage transactionMessage);

	TransactionMessage findByTransactionId(long transactionId);

	List<TransactionMessage> findByMessageState(int messageState);
	
	List<TransactionMessage> findForPresendBack(Map<?, ?> paramMap);
	
	List<TransactionMessage> findForSendMQ(Map<?, ?> paramMap);
	
	List<TransactionMessage> findForDoneBack(Map<?, ?> paramMap);

	int messageStateCount(int messageState);

}
