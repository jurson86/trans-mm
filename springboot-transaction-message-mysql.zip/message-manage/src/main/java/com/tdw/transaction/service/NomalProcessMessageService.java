package com.tdw.transaction.service;

import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.exception.ServiceException;
import com.tdw.transaction.model.request.MessageIdCreator;

public interface NomalProcessMessageService {
	
	/**
	 * 创建消息
	 */
	Long createMessage(MessageIdCreator messageIdCreator) throws ServiceException;

	/**
	 * 更新消息为预发送状态
	 */
	TransactionMessage updateMessageToPreSend(Long messageId) throws ServiceException;
	

	/**
	 * 更新消息为发送状态
	 */
	TransactionMessage updateMessageToSend(Long messageId,String message) throws ServiceException;
	


	/**
	 * 更新消息为异常状态
	 */
	TransactionMessage updateMessageToAbnormal(Long messageId) throws ServiceException;
	

	/**
	 * 更新消息为死亡状态
	 */
	TransactionMessage updateMessageToDied(Long messageId) throws ServiceException;
	

	/**
	 * 更新消息为完成状态
	 */
	TransactionMessage updateMessageToDone(TransactionMessage transactionMessage) throws ServiceException;
	

	/**
	 * 消息确认完成
	 */
	TransactionMessage resultToDone(JSONObject msgJo) throws ServiceException;
	

	/**
	 * 更新消息为废弃状态
	 */
	TransactionMessage updateMessageToDiscard(Long messageId) throws ServiceException;
	
	
	/**
	 * 根据ID获取消息信息
	 */
	TransactionMessage  getTransactionMessageById(Long messageId) throws ServiceException;
	

	/**
	 * 查询各状态当前消息数
	 */
	Integer getMessageStateCount(Integer messageState) throws ServiceException;
	

	/**
	 * 根据状态获取消息列表
	 */
	List<TransactionMessage>  queryTransactionMessageByState(Integer messageState) throws ServiceException;
	
	

}
