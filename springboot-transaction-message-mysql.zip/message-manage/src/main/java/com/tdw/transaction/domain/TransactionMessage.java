package com.tdw.transaction.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public final class TransactionMessage  {

	private Long transactionId;

	private String serviceName;
	
	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	private Integer messageType;

	private String messageTopic;

	private String message;

	private Integer messageState;

	private Integer messageSendThreshold;

	private Integer messageSendTimes;

	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date messageNextSendTime;

	private String presendBackUrl;

	private String presendBackMethod;

	private Integer presendBackThreshold;

	private Integer presendBackSendTimes;

	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date presendBackNextSendTime;

	private String resultBackUrl;

	private String resultBackMethod;

	private Integer resultBackThreshod;

	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date resultBackNextSendTime;

	private String result;

	private String expectResult;
	
	private Boolean over;
	
	private Integer count;
	
	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getMessageType() {
		return messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

	public String getMessageTopic() {
		return messageTopic;
	}

	public void setMessageTopic(String messageTopic) {
		this.messageTopic = messageTopic;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getMessageState() {
		return messageState;
	}

	public void setMessageState(Integer messageState) {
		this.messageState = messageState;
	}

	public Integer getMessageSendThreshold() {
		return messageSendThreshold;
	}

	public void setMessageSendThreshold(Integer messageSendThreshold) {
		this.messageSendThreshold = messageSendThreshold;
	}

	public Integer getMessageSendTimes() {
		return messageSendTimes;
	}

	public void setMessageSendTimes(Integer messageSendTimes) {
		this.messageSendTimes = messageSendTimes;
	}

	public Date getMessageNextSendTime() {
		return messageNextSendTime;
	}

	public void setMessageNextSendTime(Date messageNextSendTime) {
		this.messageNextSendTime = messageNextSendTime;
	}

	public String getPresendBackUrl() {
		return presendBackUrl;
	}

	public void setPresendBackUrl(String presendBackUrl) {
		this.presendBackUrl = presendBackUrl;
	}

	public String getPresendBackMethod() {
		return presendBackMethod;
	}

	public void setPresendBackMethod(String presendBackMethod) {
		this.presendBackMethod = presendBackMethod;
	}

	public Integer getPresendBackThreshold() {
		return presendBackThreshold;
	}

	public void setPresendBackThreshold(Integer presendBackThreshold) {
		this.presendBackThreshold = presendBackThreshold;
	}

	public Integer getPresendBackSendTimes() {
		return presendBackSendTimes;
	}

	public void setPresendBackSendTimes(Integer presendBackSendTimes) {
		this.presendBackSendTimes = presendBackSendTimes;
	}

	public Date getPresendBackNextSendTime() {
		return presendBackNextSendTime;
	}

	public void setPresendBackNextSendTime(Date presendBackNextSendTime) {
		this.presendBackNextSendTime = presendBackNextSendTime;
	}

	public String getResultBackUrl() {
		return resultBackUrl;
	}

	public void setResultBackUrl(String resultBackUrl) {
		this.resultBackUrl = resultBackUrl;
	}

	public String getResultBackMethod() {
		return resultBackMethod;
	}

	public void setResultBackMethod(String resultBackMethod) {
		this.resultBackMethod = resultBackMethod;
	}

	public Integer getResultBackThreshod() {
		return resultBackThreshod;
	}

	public void setResultBackThreshod(Integer resultBackThreshod) {
		this.resultBackThreshod = resultBackThreshod;
	}

	public Date getResultBackNextSendTime() {
		return resultBackNextSendTime;
	}

	public void setResultBackNextSendTime(Date resultBackNextSendTime) {
		this.resultBackNextSendTime = resultBackNextSendTime;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getExpectResult() {
		return expectResult;
	}

	public void setExpectResult(String expectResult) {
		this.expectResult = expectResult;
	}

	public Boolean getOver() {
		return over;
	}

	public void setOver(Boolean over) {
		this.over = over;
	}

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}

	@Override
    public String toString() {
        return String.format("serviceName: %s", serviceName);
    }

}