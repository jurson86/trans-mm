package com.tdw.transaction.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public final class OptLog  {

	private Long optId;
	
	private Integer messageType;

	private Long transactionId;

	private Integer beginState;

	private Integer endState;

	private String optionLog;

	private String optionMethod;

	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date optionTime;
	
	public Long getOptId() {
		return optId;
	}

	public void setOptId(Long optId) {
		this.optId = optId;
	}

	public Integer getMessageType() {
		return messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getBeginState() {
		return beginState;
	}

	public void setBeginState(Integer beginState) {
		this.beginState = beginState;
	}

	public Integer getEndState() {
		return endState;
	}

	public void setEndState(Integer endState) {
		this.endState = endState;
	}

	public String getOptionLog() {
		return optionLog;
	}

	public void setOptionLog(String optionLog) {
		this.optionLog = optionLog;
	}

	public String getOptionMethod() {
		return optionMethod;
	}

	public void setOptionMethod(String optionMethod) {
		this.optionMethod = optionMethod;
	}

	public Date getOptionTime() {
		return optionTime;
	}

	public void setOptionTime(Date optionTime) {
		this.optionTime = optionTime;
	}

	@Override
	public String toString() {
		return String.format(
				"{'transactionId':'%s', 'beginState':'%s', 'endState':'%s', 'optionLog':'%s', 'optionMethod':'%s', 'optionTime':'%s' }",
				transactionId, beginState, endState, optionLog, optionMethod, optionTime.toString());
	}

}