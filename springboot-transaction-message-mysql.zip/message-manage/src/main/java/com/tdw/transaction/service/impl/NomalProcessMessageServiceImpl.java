package com.tdw.transaction.service.impl;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Preconditions;
import com.tdw.transaction.component.RocketMQHelper;
import com.tdw.transaction.component.ThresholdsTimeManage;
import com.tdw.transaction.constant.BZStatusCode;
import com.tdw.transaction.constant.Constants;
import com.tdw.transaction.domain.OptLog;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.exception.ServiceException;
import com.tdw.transaction.model.constants.MessageState;
import com.tdw.transaction.model.constants.OverMark;
import com.tdw.transaction.model.constants.Thresholds;
import com.tdw.transaction.model.message.SendMessage;
import com.tdw.transaction.model.request.MessageIdCreator;
import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;
import com.tdw.transaction.service.NomalProcessMessageService;
import com.tdw.transaction.service.util.OptLogsService;
import com.tdw.transaction.util.SortString;

@Service
public class NomalProcessMessageServiceImpl implements NomalProcessMessageService {
	private static final Logger logger = LoggerFactory.getLogger(NomalProcessMessageServiceImpl.class);

	@Resource
	private TransactionMessageRepository transactionMessageRepository;

	@Resource
	private OptLogRepository optLogRepository;

	@Autowired
	private ThresholdsTimeManage ThresholdsTimeManage;

	@Autowired
	private RocketMQHelper rocketMQHelper;

	@Autowired
	private RestTemplate restTemplate;

	private final Random random = new Random();

	@Override
	public Long createMessage(MessageIdCreator mc) throws ServiceException {

		Preconditions.checkNotNull(mc);
		Preconditions.checkNotNull(mc.getServiceName());
		// define transaction message
		TransactionMessage transactionMessage = new TransactionMessage();

		// 初始化
		transactionMessage.setServiceName(mc.getServiceName());
		transactionMessage.setCreateTime(Calendar.getInstance().getTime());
		// 当前版本随机值，用于分库
		transactionMessage.setMessageType(random.nextInt(9));
		transactionMessage.setMessageTopic(mc.getMessageTopic());
		transactionMessage.setMessage(mc.getMessage());
		transactionMessage.setMessageState(MessageState.PRESEND.code());
		transactionMessage.setMessageSendThreshold(Thresholds.MAX_SEND.code());
		transactionMessage.setMessageSendTimes(0);
		transactionMessage.setMessageNextSendTime(Calendar.getInstance().getTime());

		transactionMessage.setPresendBackUrl(mc.getPresendBackUrl());
		transactionMessage.setPresendBackMethod(HttpMethod.POST.toString());
		transactionMessage.setPresendBackThreshold(Thresholds.MAX_PRESENDBACK.code());
		transactionMessage.setPresendBackSendTimes(0);
		transactionMessage.setPresendBackNextSendTime(
				ThresholdsTimeManage.createPreSendBackTime(Thresholds.MAX_PRESENDBACK.code()));

		transactionMessage.setResultBackUrl(mc.getResultBackUrl());
		transactionMessage.setResultBackMethod(HttpMethod.POST.toString());
		transactionMessage.setResultBackThreshod(Thresholds.MAX_RESULTBACK.code());
		transactionMessage.setResultBackNextSendTime(Calendar.getInstance().getTime());

		transactionMessage.setResult("");
		transactionMessage.setExpectResult(mc.getExpectResult());
		// 消息类型已完成，活动【over 1 , active 0 】
		transactionMessage.setOver(OverMark.ACTIVE.code());

		transactionMessageRepository.insert(transactionMessage);

		if (null == transactionMessage.getTransactionId()) {
			logger.error("插入数据生成ID为空！");
			throw new ServiceException(BZStatusCode.SERVER_UNKNOWN_ERROR);
		}
		// 操作日志
		optLogRepository.save(OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
				transactionMessage.getMessageType(), 0, MessageState.PRESEND.code(), null));

		return transactionMessage.getTransactionId();
	}

	@Override
	public TransactionMessage updateMessageToSend(Long transactionId, String message) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionMessage);

		if (MessageState.PRESEND.code() != transactionMessage.getMessageState()
				&& MessageState.DIED.code() != transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		if (null != message && message.length() > 1) {
			transactionMessage.setMessage(message);
		}

		transactionMessage.setMessageState(MessageState.SEND.code());

		transactionMessage.setMessageSendThreshold(Thresholds.MAX_SEND.code());
		int sendTimes = transactionMessage.getMessageSendTimes() + 1;
		transactionMessage.setMessageSendTimes(sendTimes);
		transactionMessage.setMessageNextSendTime(ThresholdsTimeManage.createSendNextTime(Thresholds.MAX_SEND.code()));

		int sendMark = 0;
		try {
			// 消息发送
			rocketMQHelper.sendTranTopicMsg(transactionMessage);
			sendMark = 1;
		} catch (Exception e) {
			logger.error("=================send exception============= {}", e.getMessage());
		}

		if (1 == sendMark) {
			transactionMessage.setMessageState(MessageState.DONE.code());
			if (null == transactionMessage.getResultBackUrl() || transactionMessage.getResultBackUrl().isEmpty()
					|| transactionMessage.getResultBackUrl().length() < 1) {
				// 不需要回调确认，数据转移
				transactionMessage.setOver(OverMark.OVER.code());
			}
			transactionMessageRepository.update(transactionMessage);

			// 操作信息
			optLogRepository.save(OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
					transactionMessage.getMessageType(), MessageState.SEND.code(), MessageState.DONE.code(), null));
		} else {
			transactionMessageRepository.update(transactionMessage);
			// 操作信息
			optLogRepository.save(OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
					transactionMessage.getMessageType(), MessageState.SEND.code(), MessageState.SEND.code(), null));
		}

		return transactionMessage;
	}

	@Override
	public TransactionMessage updateMessageToDiscard(Long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionMessage);

		if (MessageState.DISCARD.code() == transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
				transactionMessage.getMessageType(), transactionMessage.getMessageState(), MessageState.DISCARD.code(),
				null);

		transactionMessage.setMessageState(MessageState.DISCARD.code());
		// 数据转移
		transactionMessage.setOver(OverMark.OVER.code());

		transactionMessageRepository.update(transactionMessage);
		// 操作信息
		optLogRepository.save(optlog);

		return transactionMessage;
	}

	@Override
	public TransactionMessage getTransactionMessageById(Long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		return transactionMessage;
	}

	@Override
	public TransactionMessage updateMessageToPreSend(Long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionMessage);

		if (MessageState.ABNORMAL.code() != transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		// 操作日志
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
				transactionMessage.getMessageType(), transactionMessage.getMessageState(), MessageState.PRESEND.code(),
				null);

		transactionMessage.setMessageState(MessageState.PRESEND.code());
		transactionMessage.setPresendBackThreshold(Thresholds.MAX_PRESENDBACK.code());
		transactionMessage.setPresendBackNextSendTime(
				ThresholdsTimeManage.createPreSendBackTime(Thresholds.MAX_PRESENDBACK.code()));

		transactionMessageRepository.update(transactionMessage);
		// 操作信息
		optLogRepository.save(optlog);

		return transactionMessage;
	}

	@Override
	public TransactionMessage updateMessageToAbnormal(Long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionMessage);

		if (MessageState.PRESEND.code() != transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
				transactionMessage.getMessageType(), transactionMessage.getMessageState(), MessageState.ABNORMAL.code(),
				null);
		transactionMessage.setMessageState(MessageState.ABNORMAL.code());

		transactionMessageRepository.update(transactionMessage);
		// 操作信息
		optLogRepository.save(optlog);

		return transactionMessage;
	}

	@Override
	public TransactionMessage updateMessageToDied(Long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionMessage);

		if (MessageState.SEND.code() != transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
				transactionMessage.getMessageType(), transactionMessage.getMessageState(), MessageState.DIED.code(),
				null);

		transactionMessage.setMessageState(MessageState.DIED.code());

		transactionMessageRepository.update(transactionMessage);
		// 操作信息
		optLogRepository.save(optlog);

		return transactionMessage;
	}

	/**
	 * 按照多结果匹配回调，适应多条topic
	 */
	@Override
	public TransactionMessage resultToDone(JSONObject msgJo) throws ServiceException {
		SendMessage sendMessage = new SendMessage();
		try {
			sendMessage = JSONObject.toJavaObject(msgJo, SendMessage.class);
		} catch (Exception e) {
			// TODO 接入告警
			logger.error("Result message : {};   Exception: {}", msgJo, e.getMessage());
			return null;
		}

		long transactionId = Long.valueOf(sendMessage.getMessageId());
		String messageResult = sendMessage.getMessage().toString();

		// 检测ID有效性
		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);
		Preconditions.checkNotNull(transactionMessage);
		// 结果合法性
		if (messageResult.length() != 1 || !transactionMessage.getExpectResult().contains(messageResult)) {
			logger.error("===========Result message error ==========: {} ; expect: {} ", msgJo,
					transactionMessage.getExpectResult());
			return null;
		}
		// 幂等
		if (transactionMessage.getResult().contains(messageResult)) {
			logger.error("==========幂等===========: {} ", transactionId);
			return null;
		}

		logger.info("============Process=============== : {} ", transactionId);

		StringBuilder sbuild = new StringBuilder();
		sbuild.append(transactionMessage.getResult());
		sbuild.append(messageResult);
		String newResult = SortString.sortString(sbuild.toString());

		if (newResult.equals(transactionMessage.getExpectResult())) {
			transactionMessage.setResult(newResult);
			return updateMessageToDone(transactionMessage);
		} else {
			OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
					transactionMessage.getMessageType(), transactionMessage.getMessageState(),
					transactionMessage.getMessageState(), messageResult);
			transactionMessage.setResult(newResult);
			transactionMessageRepository.update(transactionMessage);
			// 操作信息
			optLogRepository.save(optlog);

			return transactionMessage;
		}

	}

	/**
	 * 消息结果回调
	 */
	@Override
	public TransactionMessage updateMessageToDone(TransactionMessage transactionMessage) throws ServiceException {

		if (MessageState.SEND.code() != transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),
				transactionMessage.getMessageType(), transactionMessage.getMessageState(), MessageState.DONE.code(),
				"Done");

		transactionMessage.setMessageState(MessageState.DONE.code());
		transactionMessage.setResultBackThreshod(Thresholds.MAX_RESULTBACK.code());
		try {
			HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
			httpbodyMap.put("messageId", transactionMessage.getTransactionId());
			// 回调结果接口
			final ResponseEntity<String> response = restTemplate.exchange(transactionMessage.getResultBackUrl(),
					HttpMethod.POST, new HttpEntity<HashMap<String, Object>>(httpbodyMap, Constants.header),
					String.class);
			if (response.getStatusCode().equals(HttpStatus.OK)) {
				transactionMessage.setResultBackThreshod(Thresholds.OVER.code());
			}
		} catch (Exception e) {
			logger.error("{} result back method exception: {}", transactionMessage.getTransactionId(), e.getMessage());
		}

		transactionMessageRepository.update(transactionMessage);
		// 操作信息
		optLogRepository.save(optlog);

		return transactionMessage;
	}

	@Override
	public Integer getMessageStateCount(Integer messageState) throws ServiceException {
		int stateCount = transactionMessageRepository.messageStateCount(messageState);
		return stateCount;
	}

	@Override
	public List<TransactionMessage> queryTransactionMessageByState(Integer messageState) throws ServiceException {

		List<TransactionMessage> result = transactionMessageRepository.findByMessageState(messageState);

		return result;
	}

}
