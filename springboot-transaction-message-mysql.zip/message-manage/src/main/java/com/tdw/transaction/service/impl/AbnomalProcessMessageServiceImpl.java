package com.tdw.transaction.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Preconditions;
import com.tdw.transaction.component.RocketMQHelper;
import com.tdw.transaction.component.ThresholdsTimeManage;
import com.tdw.transaction.constant.BZStatusCode;
import com.tdw.transaction.constant.Constants;
import com.tdw.transaction.domain.OptLog;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.exception.ServiceException;
import com.tdw.transaction.model.constants.MessageState;
import com.tdw.transaction.model.constants.OverMark;
import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;
import com.tdw.transaction.service.AbnomalProcessMessageService;
import com.tdw.transaction.service.util.OptLogsService;

@Service
public class AbnomalProcessMessageServiceImpl implements AbnomalProcessMessageService {

	private static final Logger logger = LoggerFactory.getLogger(AbnomalProcessMessageServiceImpl.class);

	@Resource
	private TransactionMessageRepository transactionMessageRepository;

	@Resource
	private OptLogRepository optLogRepository;

	@Autowired
	private ThresholdsTimeManage thresholdsTimeManage;

	@Autowired
	private AbnomalThreadCallService abnomalThreadCallService;

	@Autowired
	private RocketMQHelper rocketMQHelper;

	private static Date PRESEND_CALLBACK_BYTASK_TIME = null;

	/**
	 * 预发送回调确认
	 */
	@Override
	public void preSendCallbackByTask() throws ServiceException {
		// 任务执行中不可重复调用
		if (isPreSendCallbackRuning()) {
			return;
		}
		Calendar calendar = Calendar.getInstance();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("dt", calendar.getTime());
		paramMap.put("messageState", MessageState.PRESEND.code());
		List<TransactionMessage> transactionMessageList = transactionMessageRepository.findForPresendBack(paramMap);
		// 操作数据，直接返回
		if (transactionMessageList.size() == 0) {
			logger.debug("PresendCallback list is null....");
			return;
		}

		logger.debug("PresendCallback running....");
		ExecutorService poll = Executors.newFixedThreadPool(transactionMessageList.size());

		for (TransactionMessage transactionMessage : transactionMessageList) {
			Future<Boolean> future = poll.submit(new Callable<Boolean>() {
				@Override
				public Boolean call() throws Exception {
					return abnomalThreadCallService.presendCallback(transactionMessage);
				}
			});
			try {
				// 设置超时
				future.get(Constants.RESTFUL_MAX_TIMEOUT_SECONDS, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				logger.error("PresendCallback 任务异常中止 : {}", e.getMessage());
			} catch (ExecutionException e) {
				logger.error("PresendCallback 计算出现异常: {}", e.getMessage());
			} catch (TimeoutException e) {
				logger.error("PresendCallback 超时异常: {}", e.getMessage());
				// 超时后取消任务
				future.cancel(true);
			}
		}

		poll.shutdown();
	}

	@Override
	public void sendToMQByTask() throws ServiceException {
		Calendar calendar = Calendar.getInstance();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("dt", calendar.getTime());
		paramMap.put("messageState", MessageState.SEND.code());
		List<TransactionMessage> transactionMessageList = transactionMessageRepository.findForSendMQ(paramMap);
		// 操作数据，直接返回
		if (transactionMessageList.size() == 0) {
			logger.debug("sendToMQByTask list is null....");
			return;
		}

		logger.debug("sendToMQByTask running....");

		for (TransactionMessage transactionMessage : transactionMessageList) {

			try {
				// 消息发送
				rocketMQHelper.sendTranTopicMsg(transactionMessage);

				OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
						transactionMessage.getMessageState(), MessageState.DONE.code(), null);
				transactionMessage.setMessageState(MessageState.DONE.code());
				if (null == transactionMessage.getResultBackUrl() || transactionMessage.getResultBackUrl().isEmpty()
						|| transactionMessage.getResultBackUrl().length() < 1) {
					// 不需要回调确认，数据转移
					transactionMessage.setOver(OverMark.OVER.code());
				}

				transactionMessageRepository.update(transactionMessage);
				// 操作信息
				optLogRepository.save(optlog);

			} catch (Exception e) {
				logger.error("=================send exception============= {}", e.getMessage());

				int timesTmp = transactionMessage.getMessageSendTimes();
				transactionMessage.setMessageSendTimes(timesTmp + 1);

				int thresholdTmp = transactionMessage.getMessageSendThreshold();
				if (thresholdTmp <= 0) {
					OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
							transactionMessage.getMessageState(), MessageState.DIED.code(), "SendToMQ  Died");
					transactionMessage.setMessageState(MessageState.DIED.code());

					transactionMessageRepository.update(transactionMessage);
					// 操作信息
					optLogRepository.save(optlog);
				} else {
					OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
							transactionMessage.getMessageState(), transactionMessage.getMessageState(),
							"SendToMQ  ...");
					transactionMessage.setMessageNextSendTime(thresholdsTimeManage.createSendNextTime(thresholdTmp));
					transactionMessage.setMessageSendThreshold(thresholdTmp - 1);

					transactionMessageRepository.update(transactionMessage);
					// 操作信息
					optLogRepository.save(optlog);
				}

			}
		}

	}

	@Override
	public void resultCallbackByTask() throws ServiceException {
		// 任务执行中不可重复调用
		if (isPreSendCallbackRuning()) {
			return;
		}
		Calendar calendar = Calendar.getInstance();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("dt", calendar.getTime());
		paramMap.put("messageState", MessageState.DONE.code());
		List<TransactionMessage> transactionMessageList = transactionMessageRepository.findForDoneBack(paramMap);
		// 操作数据为空，直接返回
		if (transactionMessageList.size() == 0) {
			logger.debug("resultCallbackByTask list is null....");
			return;
		}

		logger.debug("resultCallbackByTask running....");
		ExecutorService poll = Executors.newFixedThreadPool(transactionMessageList.size());

		for (TransactionMessage transactionMessage : transactionMessageList) {
			// 已完成消息过滤掉
			if (OverMark.OVER.code() == transactionMessage.getOver()) {
				continue;
			}
			Future<Boolean> future = poll.submit(new Callable<Boolean>() {
				@Override	
				public Boolean call() throws Exception {
					return abnomalThreadCallService.resultCallback(transactionMessage);
				}
			});
			try {
				// 设置超时
				future.get(Constants.RESTFUL_MAX_TIMEOUT_SECONDS, TimeUnit.SECONDS);
			} catch (InterruptedException e) {
				logger.error("DoneCallback 任务异常中止 : {}", e.getMessage());
			} catch (ExecutionException e) {
				logger.error("DoneCallback 计算出现异常: {}", e.getMessage());
			} catch (TimeoutException e) {
				logger.error("DoneCallback 超时异常: {}", e.getMessage());
				// 超时后取消任务
				future.cancel(true);
			}
		}

		poll.shutdown();

	}

	private boolean isPreSendCallbackRuning() {
		if (null == PRESEND_CALLBACK_BYTASK_TIME) {
			PRESEND_CALLBACK_BYTASK_TIME = new Date();
			return false;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.SECOND, -1 * (Constants.RESTFUL_MAX_TIMEOUT_SECONDS + 2));
		if (calendar.getTime().before(PRESEND_CALLBACK_BYTASK_TIME)) {
			logger.info("PresendCallback 正在执行中，任务不可重复调用 ......!");
			return true;
		}
		return false;
	}

	@Override
	public void resendMessageByTransactionId(long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageRepository.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionMessage);

		if (MessageState.PRESEND.code() == transactionMessage.getMessageState()
				|| MessageState.DISCARD.code() == transactionMessage.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		try {
			// 消息发送
			rocketMQHelper.sendTranTopicMsg(transactionMessage);
		} catch (Exception e) {
			logger.error("=================send exception============= {}", e.getMessage());
			throw new ServiceException(BZStatusCode.SERVER_UNKNOWN_ERROR);
		}
	}

}
