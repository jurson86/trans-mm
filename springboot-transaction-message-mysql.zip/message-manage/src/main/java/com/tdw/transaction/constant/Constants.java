package com.tdw.transaction.constant;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

import com.google.common.collect.ImmutableList;

public class Constants {
	
	public static final int THREAD_POOL_MAX_NUM = 1000;
	
	public static final int RESTFUL_MAX_TIMEOUT_SECONDS = 5;
	

	public static HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();

	public static HttpHeaders header = new HttpHeaders();
	
	static {
		header.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON_UTF8));
		header.setContentType(MediaType.APPLICATION_JSON_UTF8);

		httpRequestFactory.setConnectionRequestTimeout(2000);
		httpRequestFactory.setConnectTimeout(2000);
		httpRequestFactory.setReadTimeout(2000);
	}
}
