package com.tdw.transaction.component;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;

@Component
public class InitailDBTables {
	@Resource
	private TransactionMessageRepository transactionMessageRepository;

	@Resource
	private OptLogRepository optLogRepository;

	public void createTables() {
		transactionMessageRepository.createIfNotExistsTable();
		optLogRepository.createIfNotExistsTable();
	}
}
