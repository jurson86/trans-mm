package com.tdw.transaction.service.util;

import java.util.Date;

import com.tdw.transaction.domain.OptLog;

public class OptLogsService {

	
	public static OptLog createOptLogs(long transactionId,int messageType, int bState,int eState,String logstr)
	{
		OptLog log = new OptLog();
		log.setTransactionId(transactionId);
		log.setBeginState(bState);
		log.setEndState(eState);
		log.setOptionLog(logstr);
		log.setOptionTime(new Date());
		log.setMessageType(messageType);
		
		return log;
	}
	
}
