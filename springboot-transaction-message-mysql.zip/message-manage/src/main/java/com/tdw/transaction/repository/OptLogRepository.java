package com.tdw.transaction.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.tdw.transaction.domain.OptLog;

@Mapper
public interface OptLogRepository {

    void createIfNotExistsTable();
    
    void truncateTable();
        
    void delete(Long transactionId);
    
    List<OptLog> selectAll();
    
    void dropTable();
    
	void save(OptLog optlog);
}
