package com.tdw.transaction.config;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import io.shardingjdbc.core.keygen.DefaultKeyGenerator;

@Component
public class DefineKeyGenerator {

	private static final Logger logger = LoggerFactory.getLogger(DefineKeyGenerator.class);

	public static void initHostNameKeyWorkerId() {
		InetAddress address;
		Long workerId;
		try {
			address = InetAddress.getLocalHost();
		} catch (final UnknownHostException e) {
			throw new IllegalStateException("Cannot get LocalHost InetAddress, please check your network!");
		}
		String hostName = address.getHostName();
		try {
			workerId = Long.valueOf(hostName.replace(hostName.replaceAll("\\d+$", ""), ""));
			logger.info("initWorkerId: {}", workerId);
		} catch (final NumberFormatException e) {
			throw new IllegalArgumentException(
					String.format("Wrong hostname:%s, hostname must be end with number!", hostName));
		}
		DefaultKeyGenerator.setWorkerId(workerId);
	}

	public static void initPropertiesWorkerId(String workerStr) {
		Long workerId;
		try {
			workerId = Long.valueOf(workerStr);
			logger.info("initWorkerId: {}", workerId);
		} catch (final NumberFormatException e) {
			throw new IllegalArgumentException(String.format("args :%s, args must be number!", workerStr));
		}
		DefaultKeyGenerator.setWorkerId(Long.valueOf(workerId));
	}
}
