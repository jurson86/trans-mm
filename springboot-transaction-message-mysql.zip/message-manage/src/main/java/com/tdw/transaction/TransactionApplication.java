package com.tdw.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.tdw.transaction.component.InitailDBTables;
import com.tdw.transaction.config.DefineKeyGenerator;

@SpringBootApplication
public class TransactionApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(TransactionApplication.class, args);
		// DefineKeyGenerator.initWorkerId();
		if (0 == args.length) {
			DefineKeyGenerator.initPropertiesWorkerId("1");
		} else {
			DefineKeyGenerator.initPropertiesWorkerId(args[0]);
		}
		applicationContext.getBean(InitailDBTables.class).createTables();
	}

}
