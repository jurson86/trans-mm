package com.tdw.transaction.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SpringBootConfig {

	@Value("${presend.back.thresholds}")
	String preSendBackThresholdstr;

	@Value("${result.back.thresholds}")
	String resultBackThresholdstr;

	@Value("${send.thresholds}")
	String sendThresholdstr;

	public String getPreSendBackThresholdstr() {
		return preSendBackThresholdstr;
	}


	public String getResultBackThresholdstr() {
		return resultBackThresholdstr;
	}

	public String getSendThresholdstr() {
		return sendThresholdstr;
	}


}
