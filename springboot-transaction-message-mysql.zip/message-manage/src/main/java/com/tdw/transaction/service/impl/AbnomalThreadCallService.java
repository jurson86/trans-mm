package com.tdw.transaction.service.impl;

import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.component.RocketMQHelper;
import com.tdw.transaction.component.ThresholdsTimeManage;
import com.tdw.transaction.constant.Constants;
import com.tdw.transaction.domain.OptLog;
import com.tdw.transaction.domain.TransactionMessage;
import com.tdw.transaction.model.constants.MessageState;
import com.tdw.transaction.model.constants.OverMark;
import com.tdw.transaction.model.constants.Thresholds;
import com.tdw.transaction.repository.OptLogRepository;
import com.tdw.transaction.repository.TransactionMessageRepository;
import com.tdw.transaction.service.util.OptLogsService;

@Service
public class AbnomalThreadCallService {

	@Resource
	private TransactionMessageRepository transactionMessageRepository;

	@Resource
	private OptLogRepository optLogRepository;

	@Autowired
	private ThresholdsTimeManage thresholdsTimeManage;

	@Autowired
	private RocketMQHelper rocketMQHelper;

	private static final Logger logger = LoggerFactory.getLogger(AbnomalThreadCallService.class);

	public Boolean presendCallback(TransactionMessage transactionMessage) {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("messageId", transactionMessage.getTransactionId());
		RestTemplate thRestTemplate = new RestTemplate(Constants.httpRequestFactory);
		
		try {
			ResponseEntity<String> response = thRestTemplate.exchange(transactionMessage.getPresendBackUrl(),
					HttpMethod.POST, new HttpEntity<HashMap<String, Object>>(httpbodyMap, Constants.header), String.class);

			logger.debug("PreSend Callback response: {} ", response.toString());

			if (response.getStatusCode().equals(HttpStatus.OK)) {
				JSONObject jo = JSONObject.parseObject(response.getBody());
				int status = jo.getIntValue("status");
				if (200 == status) {
					logger.debug("{} PreSend Callback success!", transactionMessage.getTransactionId());
					presendCallbackSuccess(transactionMessage);
					return true;
				}
				if (204 == status) {
					logger.debug("{} PreSend Callback discard!", transactionMessage.getTransactionId());
					changeToDiscard(transactionMessage);
					return true;
				}
			}
		} catch (Exception e) {
			logger.error("PreSend Callback Exception : {}", e.getMessage());
		}

		logger.debug("{} PreSend Callback failed!", transactionMessage.getTransactionId());
		presendCallbackFailed(transactionMessage);
		return false;
	}

	public Boolean resultCallback(TransactionMessage transactionMessage) {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("messageId", transactionMessage.getTransactionId());
		RestTemplate thRestTemplate = new RestTemplate(Constants.httpRequestFactory);

		try {
			final ResponseEntity<String> response = thRestTemplate.exchange(transactionMessage.getResultBackUrl(),
					HttpMethod.POST, new HttpEntity<HashMap<String, Object>>(httpbodyMap, Constants.header), String.class);
			if (response.getStatusCode().equals(HttpStatus.OK)) {
				logger.debug("{} Result Callback success!", transactionMessage.getTransactionId());
				resultCallbackSuccess(transactionMessage);
				return true;
			}
		} catch (Exception e) {
			logger.error("Result Callback Exception : {}", e.getMessage());
		}

		logger.debug("{} Result Callback failed!", transactionMessage.getTransactionId());
		resultCallbackFailed(transactionMessage);
		return false;
	}

	/**
	 * @param transactionMessage
	 */
	private void resultCallbackSuccess(TransactionMessage transactionMessage) {
		// 操作信息
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
				transactionMessage.getMessageState(), MessageState.DONE.code(), "result callback success!");

		transactionMessage.setResultBackThreshod(Thresholds.OVER.code());
		// TODO 完成信息数据转移
		transactionMessage.setOver(OverMark.OVER.code());

		transactionMessageRepository.update(transactionMessage);
		optLogRepository.save(optlog);
	}

	private void resultCallbackFailed(TransactionMessage transactionMessage) {
		// 操作信息
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
				transactionMessage.getMessageState(), transactionMessage.getMessageState(), "result callback failed!");

		int thresholdTmp = transactionMessage.getResultBackThreshod();
		transactionMessage.setPresendBackNextSendTime(thresholdsTimeManage.createResultBackTime());
		transactionMessage.setPresendBackThreshold(thresholdTmp - 1);

		transactionMessageRepository.update(transactionMessage);
		optLogRepository.save(optlog);

	}

	private void presendCallbackSuccess(TransactionMessage transactionMessage) {
		// 操作信息
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
				transactionMessage.getMessageState(), MessageState.SEND.code(), "Presend callback success!");

		transactionMessage.setMessageState(MessageState.SEND.code());
		transactionMessage.setMessageSendThreshold(Thresholds.MAX_SEND.code());
		int sendTimes = transactionMessage.getMessageSendTimes() + 1;
		transactionMessage.setMessageSendTimes(sendTimes);
		transactionMessage.setMessageNextSendTime(thresholdsTimeManage.createSendNextTime(Thresholds.MAX_SEND.code()));

		try {
			// 消息发送
			rocketMQHelper.sendTranTopicMsg(transactionMessage);
			optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
					transactionMessage.getMessageState(), MessageState.DONE.code(), null);
			if (null== transactionMessage.getResultBackUrl() || transactionMessage.getResultBackUrl().isEmpty() || transactionMessage.getResultBackUrl().length() < 1) {
				// 不需要回调确认，数据转移
				transactionMessage.setOver(OverMark.OVER.code());
			}
			transactionMessage.setMessageState(MessageState.DONE.code());
		} catch (Exception e) {
			logger.error("=================send exception============= {}", e.getMessage());
		}

		transactionMessageRepository.update(transactionMessage);
		optLogRepository.save(optlog);

	}

	private void presendCallbackFailed(TransactionMessage transactionMessage) {
		// 操作信息
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
				transactionMessage.getMessageState(), transactionMessage.getMessageState(), "Presend callback failed!");

		int timesTmp = transactionMessage.getPresendBackSendTimes();
		transactionMessage.setPresendBackSendTimes(timesTmp + 1);

		int thresholdTmp = transactionMessage.getPresendBackThreshold();
		if (thresholdTmp <= 0) {
			// 异常
			transactionMessage.setMessageState(MessageState.ABNORMAL.code());
		} else {
			transactionMessage.setPresendBackNextSendTime(thresholdsTimeManage.createPreSendBackTime(thresholdTmp));
			transactionMessage.setPresendBackThreshold(thresholdTmp - 1);
		}
		transactionMessageRepository.update(transactionMessage);
		optLogRepository.save(optlog);
	}

	private void changeToDiscard(TransactionMessage transactionMessage) {
		// 操作信息
		OptLog optlog = OptLogsService.createOptLogs(transactionMessage.getTransactionId(),transactionMessage.getMessageType(),
				transactionMessage.getMessageState(), MessageState.DISCARD.code(), "Change to discard!");
		transactionMessage.setMessageState(MessageState.DISCARD.code());
		// 数据转移
		transactionMessage.setOver(OverMark.OVER.code());

		transactionMessageRepository.update(transactionMessage);
		optLogRepository.save(optlog);
	}

}
