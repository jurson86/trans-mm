package com.tdw.transaction.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tdw.transaction.model.request.MessageIdAck;
import com.tdw.transaction.model.request.MessageIdCreator;
import com.tdw.transaction.service.NomalProcessMessageService;
import com.tdw.transaction.util.Result;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
public class NomalController {

	private static final Logger logger = LoggerFactory.getLogger(NomalController.class);

	@Autowired
	private NomalProcessMessageService preSendMessageService;

	@ApiOperation(value = "消息ID获取", notes = "消息ID获取")
	@ApiImplicitParam(name = "messageIdCreator", value = "创建消息ID基础信息", paramType = "body", required = true, dataType = "MessageIdCreator")
	@RequestMapping(value = "/message/creator", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> createMessage(@Valid @RequestBody MessageIdCreator messageIdCreator) {

		logger.debug("MessageIdCreator: {}", messageIdCreator.toString());

		long transactionId = preSendMessageService.createMessage(messageIdCreator);

		return new ResponseEntity<Result<String>>(new Result<String>(String.valueOf(transactionId)), HttpStatus.OK);
	}

	@ApiOperation(value = "预发送消息确认发送状态", notes = "预发送消息确认发送状态【发送、废弃】")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "state", value = "确认状态", paramType = "path", required = true, dataType = "boolean"),
		@ApiImplicitParam(name = "messageIdAck", value = "消息", paramType = "body", required = true, dataType = "MessageIdAck")
		})
	@RequestMapping(value = "/message/send/{state}", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> putMessageToSend(@PathVariable boolean state
			,@Valid @RequestBody MessageIdAck messageIdAck) {

		logger.debug("messageidSend: {} , {}, {}", messageIdAck.getTransactionId(), state, messageIdAck.getMessage());

		if (state) {
			preSendMessageService.updateMessageToSend(messageIdAck.getTransactionId(), messageIdAck.getMessage());
		} else {
			preSendMessageService.updateMessageToDiscard(messageIdAck.getTransactionId());
		}

		return new ResponseEntity<Result<String>>(new Result<String>(""), HttpStatus.OK);
	}


}