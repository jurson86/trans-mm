package com.tdw.transaction.controller;

import java.util.HashMap;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.tdw.transaction.client.producer.LocalTransactionState;
import com.tdw.transaction.client.send.SendMassage;
import com.tdw.transaction.model.request.MessageIdCreator;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/msg")
public class MsgClientController {

	private static final Logger logger = LoggerFactory.getLogger(MsgClientController.class);

	@Value("${massage.manage.url}")
	private String massageManageUrl;
	
	private Random random = new Random();

	/**
	 * 发送事务消息
	 * 
	 * @param name
	 * @return
	 */
	@ApiOperation(value = "測試", notes = "hello world")
	@ApiImplicitParams({ @ApiImplicitParam(name = "presendbackurl", value = "名字", paramType = "query", dataType = "string") })
	@RequestMapping(value = "/producer", method = RequestMethod.GET)
	public JSONObject Producer(@RequestParam String presendbackurl) {
		SendMassage sendMassage = new SendMassage(massageManageUrl);

		logger.info("producer: {}", presendbackurl);
		// 构建消息
		JSONObject msg = new JSONObject();
		msg.put("title", "hello world");
		msg.put("name", "test producer!");

		// 发送事务消息
		MessageIdCreator messageIdCreator = new MessageIdCreator();
		messageIdCreator.setExpectResult("a");
		messageIdCreator.setMessage(msg.toJSONString());
		messageIdCreator.setMessageTopic("ProducerTestTopic");
		messageIdCreator.setMessageType(0);
		messageIdCreator.setPresendBackUrl("http://"+ presendbackurl + "/msg/messageid/check");
		messageIdCreator.setResultBackUrl("");
		messageIdCreator.setServiceName("pro");

		LocalTransactionState lts = sendMassage.preSendMassage(messageIdCreator, new TransactionExecuterImpl(), null);
		
		msg.put("state", lts);
		return msg;
	}

	/**
	 * 事务消息回调
	 */
	@RequestMapping(value = "/messageid/check", method = RequestMethod.POST)
	public HashMap<String, Object> checkListener(@RequestBody String body) {
    	int value = random.nextInt(300);
		HashMap<String, Object> msg = new HashMap<String, Object>();

		logger.info("=======================messageid/check===========================body: {}", body);
		if ((value % 3) == 0) {
			logger.info("TransactionExecuterImpl ROLLBACK_MESSAGE! =============>  " + body + "\n");
			msg.put("status", 204);
			msg.put("message", "rollback");
			return msg;
		}
		
		if ((value % 11) == 0) {
        	logger.info("checkListener RuntimeException! ============= \n ");
            throw new RuntimeException("Could not find db");
		}

		logger.info("TransactionExecuterImpl COMMIT_MESSAGE! =============>  " + body + "\n");
		msg.put("status", 200);
		msg.put("message", "commit");
		return msg;
	}

}