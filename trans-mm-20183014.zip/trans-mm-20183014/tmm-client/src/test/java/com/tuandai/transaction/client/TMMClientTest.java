package com.tuandai.transaction.client;

import com.tuandai.transaction.client.model.BeginLog;
import com.tuandai.transaction.client.model.RabbitMQTopic;
import com.tuandai.transaction.client.utils.CacheMapFileUtils;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class TMMClientTest {

    /**
     *  rpc 分文件处理
     */
    @Test
    public void sendTransBeginToFlumeTest() {
        //TMMService.getInstance().init(null, "10.100.11.160", 5672, "admin", "admin", false);

        BeginLog beginLog = new BeginLog();
        beginLog.setCheck("tmm/check");
       // beginLog.setKey("");
        beginLog.setMessage(null);
        beginLog.setServiceName("tmm");
        RabbitMQTopic rabbitMQTopic = new RabbitMQTopic();
        rabbitMQTopic.setvHost("myVhost");
        rabbitMQTopic.setExchange("myExchange2");
        rabbitMQTopic.setExchangeType("fanout");
        beginLog.setTopic(rabbitMQTopic.toJSONString());
        beginLog.setUid("msgId21212121212121212121212121212121212121212132121212121212121212121212121212121212121212121212121212121212121212121212121212121");
        for (int i = 0; i < 100000; i++) {
           // TMMService.getInstance().sendTransBeginToFlume(beginLog);
        }
//        File[] fs = CacheMapFileUtils.searchFile(new FileNameSelector("rpc"), settingSupport.getRpcDir());
//        assertNotNull(fs);
    }

    /**
     * 持久化
     */
      @Test
    public void persistentEventDefinitionTest() {

      }


}
