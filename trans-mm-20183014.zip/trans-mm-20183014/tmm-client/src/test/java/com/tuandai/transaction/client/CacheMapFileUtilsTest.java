package com.tuandai.transaction.client;

import com.tuandai.transaction.client.utils.CacheMapFileUtils;
import org.junit.Test;

import java.io.File;
import java.io.IOException;

public class CacheMapFileUtilsTest {


    /**
     * 文件排序
     */
    @Test
    public void cacheMapFileUtilsTest() throws IOException {
        String rpcPath = System.getProperty("user.dir") + "/test";

        File file = new File(rpcPath);
        file.mkdirs();
        File f1 = new File(rpcPath + "/a.txt");
        File f2 = new File(rpcPath + "/b.txt");
        File f3 = new File(rpcPath + "/c.txt");
        f1.createNewFile();
        f2.createNewFile();
        f3.createNewFile();

        File[] sdsd = new File[]{f1, f2, f3};
        CacheMapFileUtils.sortDESC(sdsd);

        System.out.println(sdsd);

    }

}
