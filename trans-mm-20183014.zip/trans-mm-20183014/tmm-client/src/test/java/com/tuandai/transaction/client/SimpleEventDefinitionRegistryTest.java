package com.tuandai.transaction.client;

import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.bo.SendState;
import com.tuandai.transaction.client.impl.SettingSupport;
import com.tuandai.transaction.client.impl.SimpleEventDefinitionRegistry;
import com.tuandai.transaction.client.utils.CacheMapFileUtils;
import com.tuandai.transaction.client.utils.ConstantUtils;
import org.junit.Test;
import org.springframework.util.StringValueResolver;

import java.io.File;
import java.util.Date;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;

public class SimpleEventDefinitionRegistryTest {

    /**
     * beginMap基本注册
     */
    @Test
    public void registerEventDefinitionTest() {
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        SimpleEventDefinitionRegistry registry = new SimpleEventDefinitionRegistry(settingSupport);
        EventDefinition event = getEventBegin();
        registry.registerEventDefinition("name", event);
        assertEquals(registry.getBeginMap().get("name"), event);
    }

    /**
     * check数据分离，超时分离
     */
    @Test
    public void getCheckDefinitionMapTest() throws InterruptedException {
        StringValueResolver r1 = mock(StringValueResolver.class);
        given(r1.resolveStringValue("${spring.tmmService.check.interval.time}")).willReturn("1000");

        // 加入beanMap
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        settingSupport.setEmbeddedValueResolver(r1);
        SimpleEventDefinitionRegistry registry = new SimpleEventDefinitionRegistry(settingSupport);
        EventDefinition event = getEventBegin();
        registry.registerEventDefinition("name2", event);
        assertEquals(registry.getBeginMap().get("name2"), event);

        Thread.sleep(2000);

        Map<String, EventDefinition> check_map = registry.getCheckDefinitionMap();
        assertEquals(check_map.get("name2"), event);
    }


    /**
     * begin 持久化
     */
    @Test
    public void persistentEventDefinitionTest()  {
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));

        // 删除rpc文件夹下的文件
        CacheMapFileUtils.delAllFile(settingSupport.getRpcDirCanonicalPath());

        // 加入beanMap
        SimpleEventDefinitionRegistry registry = new SimpleEventDefinitionRegistry(settingSupport);
        EventDefinition beginEvent = getEventBegin();
        EventDefinition endEvent = getEventEnd();

        registry.registerEventDefinition("begin", beginEvent);
        registry.registerEventDefinition("end", endEvent);
        assertEquals(registry.getBeginMap().get("begin"), beginEvent);
        assertEquals(registry.getEndMap().get("end"), endEvent);
        registry.persistentEventDefinition();

        // 检查文件是否存在
        boolean isExists = CacheMapFileUtils.existsFileName(settingSupport.getRpcDirCanonicalPath() + File.separatorChar + ConstantUtils.mapFile);

        assertEquals(isExists, true);

    }

    /**
     * check持久化
     */
    @Test
    public void checkPersistentEventDefinitionTest() throws InterruptedException {
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));

        StringValueResolver r1 = mock(StringValueResolver.class);
        given(r1.resolveStringValue("${spring.tmmService.check.interval.time}")).willReturn("1000");
        settingSupport.setEmbeddedValueResolver(r1);

        // 删除rpc文件夹下的文件
        CacheMapFileUtils.delAllFile(settingSupport.getRpcDirCanonicalPath());

        // 加入beanMap
        SimpleEventDefinitionRegistry registry = new SimpleEventDefinitionRegistry(settingSupport);
        EventDefinition beginEvent = getEventBegin();

        registry.registerEventDefinition("begin", beginEvent);
        assertEquals(registry.getBeginMap().get("begin"), beginEvent);

        // 2秒
        Thread.sleep(2000);

        Map<String, EventDefinition> checkMap = registry.getCheckDefinitionMap();
        assertEquals(checkMap.get("begin"), beginEvent);


        registry.persistentEventDefinition();

        boolean isExists = CacheMapFileUtils.existsFileName(settingSupport.getRpcDirCanonicalPath() + File.separatorChar + ConstantUtils.mapCheckFile);

        assertEquals(isExists, true);

    }




    /**
     * 加载beginMap
     */
    @Test
    public void loadAllPersistentEventDefinitionTest() {
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));

        StringValueResolver r1 = mock(StringValueResolver.class);
        given(r1.resolveStringValue("${spring.tmmService.check.interval.time}")).willReturn("1000");
        settingSupport.setEmbeddedValueResolver(r1);

        // 删除rpc文件夹下的文件
        CacheMapFileUtils.delAllFile(settingSupport.getRpcDirCanonicalPath());

        // 加入beanMap
        SimpleEventDefinitionRegistry registry = new SimpleEventDefinitionRegistry(settingSupport);
        EventDefinition beginEvent = getEventBegin();

        registry.registerEventDefinition("begin", beginEvent);
        assertEquals(registry.getBeginMap().get("begin"), beginEvent);
        registry.persistentEventDefinition();

        registry.loadAllPersistentEventDefinition();

        assertNotNull(registry.getBeginMap().get(beginEvent.getUid()));
    }



    private EventDefinition getEventBegin() {
        EventDefinition event = new EventDefinition();
        event.setUid("uid1212");
        event.setEventType(EventDefinition.EventType.BEGIN);
        event.setTime(new Date().getTime());
        event.setServiceName("test");
        event.setMessage("helloword");
        event.setTopic("{'exchange':'tmm-test','exchangeType':'fanout','vHost':'tmmVhost', 'routeKey':'routeKey'}");
        return event;
    }

    private EventDefinition getEventEnd() {
        EventDefinition event = new EventDefinition();
        event.setUid("uid1212");
        event.setEventType(EventDefinition.EventType.END);
        event.setTime(new Date().getTime());
        event.setServiceName("test");
        event.setSendState(SendState.COMMIT);
        event.setMessage("helloword");
        event.setTopic("{'exchange':'tmm-test','exchangeType':'fanout','vHost':'tmmVhost', 'routeKey':'routeKey'}");
        return event;
    }

}
