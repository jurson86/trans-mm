package com.tuandai.transaction.client;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.bo.SendState;
import com.tuandai.transaction.client.impl.LogEventServiceImpl;
import com.tuandai.transaction.client.impl.SettingSupport;
import com.tuandai.transaction.client.utils.CacheMapFileUtils;
import com.tuandai.transaction.client.utils.ConstantUtils;
import com.tuandai.transaction.client.utils.FileNameSelector;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;

public class LogEventServiceTest {


    @Test
    public void writeLogEventTest() throws InterruptedException {

        ExecutorService exe = Executors.newFixedThreadPool(10);
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        // 删除rpc文件夹下的文件
        CacheMapFileUtils.delAllFile(settingSupport.getRpcDirCanonicalPath());
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        LogEventServiceImpl logEventServiceImpl = new LogEventServiceImpl(settingSupport);

        EventDefinition tmp = getEventDefinition();
        int size = 100;
        for (int i = 0; i< size; i++) {

            exe.execute(new Runnable() {
                @Override
                public void run() {
                    logEventServiceImpl.writeLogEvent(tmp);
                }
            });
        }


        Thread.sleep(1000L);
        File fs = CacheMapFileUtils.locationLastModifyFile(new FileNameSelector("rpc"), settingSupport.getRpcDir(),false);
        assertNotNull(fs);

        CacheMapFileUtils.readDataToMap(fs, new CacheMapFileUtils.ReadDataToMapProcess() {
            int count = 0;
            @Override
            protected boolean process(String keyValueStr) throws Exception {
                EventDefinition sad = JSONObject.parseObject(keyValueStr, EventDefinition.class);
                count++;
                assertEquals(sad.getUid(), tmp.getUid());
                return true;
            }
        });

    }


    /**
     * 基本读写
     */
    @Test
    public void readLogEventTest() throws InterruptedException {
        ExecutorService exe = Executors.newFixedThreadPool(10);
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        // 删除rpc文件夹下的文件
        CacheMapFileUtils.delAllFile(settingSupport.getRpcDirCanonicalPath());
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        LogEventServiceImpl logEventServiceImpl = new LogEventServiceImpl(settingSupport);

        // 写日志
        EventDefinition tmp = getEventDefinition();
        int size = 100;
        for (int i = 0; i< size; i++) {

            exe.execute(new Runnable() {
                @Override
                public void run() {
                    logEventServiceImpl.writeLogEvent(tmp);
                }
            });
        }

        Thread.sleep(5000);

        // 读取日志
        List<EventDefinition> list = logEventServiceImpl.readLogEvent(1000);
        assertEquals(list.size(), 100);

    }


    /**
     * 读写到结束文件
     */
    @Test
    public void readLogEventTest2() throws InterruptedException, IOException {
        ExecutorService exe = Executors.newFixedThreadPool(10);
        SettingSupport settingSupport = new SettingSupport();
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        // 删除rpc文件夹下的文件
        CacheMapFileUtils.delAllFile(settingSupport.getRpcDirCanonicalPath());
        settingSupport.setRpcDir(new File(ConstantUtils.DEFAULT_RPC_PATH));
        LogEventServiceImpl logEventServiceImpl = new LogEventServiceImpl(settingSupport);

        // 写日志
        EventDefinition tmp = getEventDefinition();
        int size = 10000;
        for (int i = 0; i< size; i++) {
            logEventServiceImpl.writeLogEvent(tmp);
        }

        File fs[] = CacheMapFileUtils.searchFile(new FileNameSelector("rpc"), settingSupport.getRpcDir());

        // 写入的文件大于1
        assertNotEquals(fs.length, 1);

        // 读取日志
//        while (true) {
//            List<EventDefinition> list = logEventServiceImpl.readLogEvent(10000);
//            if (list.size() > 0) {
//                continue;
//            }
//            // 持久化
//            logEventServiceImpl.persistentCheckpoint();
//            // logEventServiceImpl.getCheckPoint() TODO
//
//            assertEquals(logEventServiceImpl.isEnd(), true);
//        }



    }





    private EventDefinition getEventDefinition() {
        EventDefinition eventDefinition = new EventDefinition();
        //eventDefinition.setRouteKey("key");
        eventDefinition.setTopic("{'exchange':'tmm-test','exchangeType':'fanout','vHost':'tmmVhost', 'routeKey':''}");
        eventDefinition.setMessage("helloworld");
        eventDefinition.setSendState(SendState.COMMIT);
        eventDefinition.setServiceName("test");
        eventDefinition.setTime(new Date().getTime());
        eventDefinition.setEventType(EventDefinition.EventType.BEGIN);
        eventDefinition.setUid("uid1212");
        return eventDefinition;
    }


}
