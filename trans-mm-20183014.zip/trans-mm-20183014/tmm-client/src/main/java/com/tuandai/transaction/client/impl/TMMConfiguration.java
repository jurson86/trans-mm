package com.tuandai.transaction.client.impl;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TMMConfiguration {

    @Bean
    public TMMService createTMMClient(@Qualifier("settingSupport") SettingSupport settingSupport) {
        return new TMMService(settingSupport);
    }

    @Bean(name = "settingSupport")
    public SettingSupport createSettingSupport() {
        // 初始化目录
        return new SettingSupport();
    }

}
