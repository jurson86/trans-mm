package com.tuandai.transaction.client.impl;

import com.tuandai.transaction.client.bo.SendState;
import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.inf.EventDefinitionRegistry;
import com.tuandai.transaction.client.inf.LogAnalyzerService;

import java.util.Date;

public class LogAnalyzerServiceImpl implements LogAnalyzerService {

    private EventDefinitionRegistry eventDefinitionRegistry;

    public LogAnalyzerServiceImpl(EventDefinitionRegistry eventDefinitionRegistry) {
        this.eventDefinitionRegistry = eventDefinitionRegistry;
    }

    @Override
    public EventDefinition analysis(EventDefinition eventDefinition) {
        if (eventDefinition.getEventType() == EventDefinition.EventType.BEGIN) {
            // 处理开始日志
            eventDefinition.setGoMapTime(new Date().getTime());
            eventDefinitionRegistry.registerEventDefinition(eventDefinition.getUid(), eventDefinition);
        } else {
            // 处理结束日志
            EventDefinition beginEvent = eventDefinitionRegistry.getEventDefinition(eventDefinition.getUid(), EventDefinition.EventType.BEGIN);
            if (beginEvent != null) {
                if (eventDefinition.getSendState() == SendState.COMMIT) { // 提交则返回到主线程发送mq
                    beginEvent.mergedEventDefinition(eventDefinition);
                    return beginEvent;
                } else if (eventDefinition.getSendState() == SendState.CANCEL) { // 如果是回滚则删除begin
                    eventDefinitionRegistry.removeEventDefinition(eventDefinition.getUid(), EventDefinition.EventType.BEGIN);
                }
            }
        }
        return null;
    }
}
