package com.tuandai.transaction.client.impl;

import com.tuandai.transaction.client.utils.CacheMapFileUtils;
import com.tuandai.transaction.client.utils.OldFileSelector;
import org.quartz.Job;
import org.quartz.JobDetail;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;

public class DoneFileQuartz  implements Job {

    private static final Logger logger = LoggerFactory.getLogger(DoneFileQuartz.class);

    public void execute(JobExecutionContext context) throws JobExecutionException {
        logger.error("开始执行.done文件删除任务！");
        JobDetail detail = context.getJobDetail();
        File rpcDir = (File)detail.getJobDataMap().get("rpcDir");
        File[] files = CacheMapFileUtils.searchFile(new OldFileSelector("done", 3), rpcDir);
        if (files != null) {
            for (File file : files) {
                CacheMapFileUtils.removeFileName(file);
            }
        }
        logger.error("执行.done文件删除任务结束！");
    }
}
