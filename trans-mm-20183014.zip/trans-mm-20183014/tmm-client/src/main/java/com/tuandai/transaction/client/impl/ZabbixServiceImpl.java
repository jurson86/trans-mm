package com.tuandai.transaction.client.impl;

import com.tuandai.architecture.zabbix.ItemInfo;
import com.tuandai.architecture.zabbix.ZabbixClient;
import com.tuandai.transaction.client.utils.FileNameSelector;
import com.tuandai.transaction.client.inf.ZabbixService;
import com.tuandai.transaction.client.utils.CacheMapFileUtils;
import com.tuandai.transaction.client.utils.ConstantUtils;
import com.tuandai.transaction.client.utils.NetUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ZabbixServiceImpl implements ZabbixService, Runnable{

    private static final Logger logger = LoggerFactory.getLogger(ZabbixServiceImpl.class);

    private SettingSupport settingSupport;

    private ZabbixClient zabbixClient;

    public ZabbixServiceImpl(SettingSupport settingSupport, ZabbixClient zabbixClient) {
        this.settingSupport = settingSupport;
        this.zabbixClient = zabbixClient;
    }

    @Override
    public int rpcCountMonitor() {
        File[] files = CacheMapFileUtils.searchFile(new FileNameSelector("rpc"), settingSupport.getRpcDir());
        return  files == null ? 0: files.length;
    }

    @Override
    public int doneCountMonitor() {
        File[] files = CacheMapFileUtils.searchFile(new FileNameSelector("done"), settingSupport.getRpcDir());
        return files == null ? 0: files.length;
    }

    @Override
    public void run() {
        Long monitorTime = getMonitorTime();
        String host = NetUtils.getLocalHostLANAddress().getHostAddress();
        // 每个固定秒发送数据给zabbix
        while (true) {
            try {
                Thread.sleep(monitorTime);
                // 获取zabbixClient
                ItemInfo rpcInfo = new ItemInfo();
                rpcInfo.setHost(host);
                rpcInfo.setKey("rpc");
                rpcInfo.setValue(rpcCountMonitor());

                ItemInfo doneInfo = new ItemInfo();
                doneInfo.setHost(host);
                doneInfo.setKey("done");
                doneInfo.setValue(doneCountMonitor());

                List<ItemInfo> items = new ArrayList<>();
                items.add(rpcInfo);
                items.add(doneInfo);
                zabbixClient.send(items);
            } catch (Exception e) {
                logger.error("TMM监控异常！", e);
            }
        }
    }

    private Long getMonitorTime() {
        Long monitorTime = 10000L;
        try {
            String monitorTimeStr = settingSupport.getPropertiesValue(ConstantUtils.monitor_time);
            monitorTime = Long.valueOf(monitorTimeStr);
        } catch (Exception e) {
            logger.debug("未读取到有效的监控时间间隔，采用默认值：" + monitorTime);
        }
        return monitorTime;
    }

}
