package com.tuandai.transaction.client.impl;

import com.tuandai.transaction.client.utils.ConstantUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.util.StringUtils;
import org.springframework.util.StringValueResolver;

import java.io.File;

public class SettingSupport implements EmbeddedValueResolverAware, InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(SettingSupport.class);

    public File rpcDir;

    public File getRpcDir() {
        return rpcDir;
    }

    public void setRpcDir(File rpcDir) {
        this.rpcDir = rpcDir;
    }

    public String getRpcDirCanonicalPath() {
        String str = null;
        try {
            str = rpcDir.getCanonicalPath();
        } catch (Exception e) {
            throw new IllegalArgumentException("不能获得全路径名！");
        }
        return str;
    }

    private StringValueResolver stringValueResolver;

    @Override
    public void setEmbeddedValueResolver(StringValueResolver resolver) {
        stringValueResolver = resolver;
    }

    public String getPropertiesValue(String name){
        return stringValueResolver.resolveStringValue(name);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        String rpcDirName = null;
        try {
            rpcDirName = stringValueResolver.resolveStringValue(ConstantUtils.RPC_PATH);
        } catch (Exception e) {
            logger.info("没加载到自定义的rpcPath，采用默认的配置!");
        }

        if (StringUtils.isEmpty(rpcDirName)) {
            rpcDirName = ConstantUtils.DEFAULT_RPC_PATH;
        }

        rpcDir = new File(rpcDirName);
        // 检查目录权限
        if (! rpcDir.exists()) {
            if (! rpcDir.mkdirs()) {
                throw new IllegalArgumentException("begin.map.directory is not a directory");
            }
        } else if (!rpcDir.canWrite()) {
            throw new IllegalArgumentException("begin.map.directory can not write");
        }
    }

}
