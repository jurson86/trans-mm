package com.tuandai.transaction.client.rabbitmq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Exchange;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.HeadersExchange;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.util.StringUtils;


public class RabbitMqServiceImpl {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqServiceImpl.class);

    public static void sendMessage(String vHost, String exchangeName, String exchangeType, String routeKey , Object msgStr,
                                   boolean isCustomExchange) throws Exception {

        RabbitTemplate rabbitTemplate = RabbitTemplateFactory.getRabbitTemplate(vHost);
        if (!isCustomExchange) {
            ConnectionFactory connectionFactory = rabbitTemplate.getConnectionFactory();
            RabbitAdmin rabbitAdmin = new RabbitAdmin(connectionFactory);
            // 根据不同类型生成交换机
            rabbitAdmin.declareExchange(getExchangeByType(exchangeType, exchangeName));
        }
        try {
            rabbitTemplate.convertAndSend(exchangeName, routeKey, msgStr);
        } catch (Exception e) {
            RabbitTemplate updtaeRabbitTemplate = RabbitTemplateFactory.updateRabbitTemplate(vHost);
            ConnectionFactory updtaeconnectionFactory = updtaeRabbitTemplate.getConnectionFactory();
            RabbitAdmin updaterabbitAdmin = new RabbitAdmin(updtaeconnectionFactory);
            // 根据不同类型生成交换机
            updaterabbitAdmin.declareExchange(getExchangeByType(exchangeType, exchangeName));
            // 再次失败则不做catch
            updtaeRabbitTemplate.convertAndSend(exchangeName, routeKey, msgStr);
        }
    }

    private static Exchange getExchangeByType(String type, String exchangeName) throws Exception {
        if (StringUtils.isEmpty(type)) {
            throw new Exception();
        }
        ExchangeType exchangeType = ExchangeType.findByDes(type);
        if (exchangeType == null) {
            logger.error("not ExchangeType.....");
            throw new Exception();
        }
        
        if (exchangeType == ExchangeType.FANOUT) {
            return new FanoutExchange(exchangeName);
        } else if (exchangeType == ExchangeType.HEADRES) {
            return new HeadersExchange(exchangeName);
        } else if (exchangeType == ExchangeType.DIRECT) {
            return new DirectExchange(exchangeName);
        } else if (exchangeType == ExchangeType.TOPIC) {
            return new TopicExchange(exchangeName);
        }
        return null;
    }

}
