package com.tuandai.transaction.client.impl;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.architecture.zabbix.ZabbixClient;
import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.inf.EventDefinitionRegistry;
import com.tuandai.transaction.client.inf.LogAnalyzerService;
import com.tuandai.transaction.client.inf.LogEventService;
import com.tuandai.transaction.client.inf.ZabbixService;
import com.tuandai.transaction.client.model.BeginLog;
import com.tuandai.transaction.client.model.EndLog;
import com.tuandai.transaction.client.rabbitmq.RabbitMqHelper;
import com.tuandai.transaction.client.rabbitmq.RabbitTemplateFactory;
import com.tuandai.transaction.client.utils.ConstantUtils;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.quartz.SimpleScheduleBuilder.simpleSchedule;

/**
 * 日志事件处理器
 */
public class TMMService implements Runnable, ApplicationContextAware {

    private static final Logger logger = LoggerFactory.getLogger(TMMService.class);

    private LogEventService logEventService = null;

    private EventDefinitionRegistry simpleEventDefinitionRegistry = null;

    private LogAnalyzerService logAnalyzerService;

    private SettingSupport settingSupport = null;

    public TMMService(SettingSupport settingSupport) {
        this.settingSupport = settingSupport;
        logEventService =  new LogEventServiceImpl(settingSupport);
        simpleEventDefinitionRegistry = new SimpleEventDefinitionRegistry(settingSupport);
        logAnalyzerService = new LogAnalyzerServiceImpl(simpleEventDefinitionRegistry);

        String portStr = null;
        String host = null;
        // 另一种配置方式
        try {
            portStr = settingSupport.getPropertiesValue(ConstantUtils.PORT);
            host = settingSupport.getPropertiesValue(ConstantUtils.HOST);
        } catch (Exception e) {
            logger.info("未加载到 spring.rabbitmq.port、spring.rabbitmq.host属性，加载 spring.rabbitmq.addresses 属性");
        }

        // 尝试加载adresses属性
        if (portStr == null && host == null) {
            try {
                String adresses = settingSupport.getPropertiesValue(ConstantUtils.ADDRESSES);
                String hosts[] = adresses.split(":");
                host = hosts[0];
                portStr = hosts[1];
            } catch (Exception e) {
                logger.error("未加载到rabbitmq的端口和ip地址信息！！");
                throw e;
            }
        }
        // 初始化 mq
        RabbitTemplateFactory.initParam(host,
                Integer.valueOf(portStr), settingSupport.getPropertiesValue(ConstantUtils.USER_NAME),
                settingSupport.getPropertiesValue(ConstantUtils.PASS_WORD));
    }

    public Boolean sendTransBeginToFlume(BeginLog beginlog) {
        EventDefinition event = new EventDefinition();
        event.setTopic(beginlog.getTopic());
        event.setMessage(beginlog.getMessage());
        event.setCheckUrl(beginlog.getCheck());
        event.setEventType(EventDefinition.EventType.BEGIN);
        //event.setRouteKey(beginlog.getKey());
        //event.setSendState(beginlog.);
        event.setServiceName(beginlog.getServiceName());
        event.setTime(new Date().getTime());
        event.setUid(beginlog.getUid());
        logEventService.writeLogEvent(event);
        return true;
    }

    public Boolean sendTransEndToFlume(EndLog endLog) {
        EventDefinition event = new EventDefinition();
        event.setTopic(endLog.getTopic());
        event.setMessage(endLog.getMessage());
        event.setEventType(EventDefinition.EventType.END);
        //event.setRouteKey(endLog.getKey());
        event.setSendState(endLog.getState());
        event.setServiceName(endLog.getServiceName());
        event.setTime(new Date().getTime());
        event.setUid(endLog.getUid());
        logEventService.writeLogEvent(event);
        return true;
    }

    public void executor() {
        // 加载磁盘数据
        simpleEventDefinitionRegistry.loadAllPersistentEventDefinition();
        // 加载checkpoint数据
        logEventService.loadCheckpoint();
        int size = getSize();
        while (true) {
            try {
                Thread.sleep(500);
                // 读取数据
                List<EventDefinition> events = logEventService.readLogEvent(size);
                long startTime = System.currentTimeMillis();
                if (!CollectionUtils.isEmpty(events)) {
                    for (EventDefinition eventDefinition : events) {
                        EventDefinition sendEvent = logAnalyzerService.analysis(eventDefinition);
                        if (sendEvent != null) {
                            logger.debug("TMMService 发送业务mq消息，" + sendEvent);
                            RabbitMqHelper.sendRabbitMQ(sendEvent);
                            logger.debug("TMMService 发送业务mq消息成功");
                            // 成功发送消息则删除BeginMap里面的数据
                            simpleEventDefinitionRegistry.removeEventDefinition(eventDefinition.getUid(), EventDefinition.EventType.BEGIN);
                        }
                    }
                }
                // 发送check数据
                EventDefinition checkEvent = getCheckStr(simpleEventDefinitionRegistry.getCheckDefinitionMap());
                if (checkEvent != null) {
                    logger.debug("TMMService 发送业务checkMQ消息，" + checkEvent);
                    RabbitMqHelper.sendRabbitMQ(checkEvent);
                    logger.debug("TMMService 发送业务checkMQ消息成功");
                }
                // 持久化
                simpleEventDefinitionRegistry.persistentEventDefinition();
                // 更新checkPoint
                logEventService.persistentCheckpoint();
                long time = System.currentTimeMillis() - startTime;
                logger.debug(" write log excuse time =============>：[" + time + "ms]");
            } catch (Exception e) {
                logger.error("error: {}", e);
                // 重置checkpoint文件
                logEventService.resetCheckpoint();
            }
        }
    }

    public int getSize() {
        int size = 1000;
        try {
            String sizeStr = settingSupport.getPropertiesValue(ConstantUtils.size);
            size =  Integer.valueOf(sizeStr);
        } catch (Exception e) {
            logger.info("未读取到自定义的size大小，使用默认值1000");
        }
        logger.info("当前读取size值为:" + size);
        return size;
    }

    private EventDefinition getCheckStr(Map<String, EventDefinition> checkMap) {
        if (checkMap.size() <= 0) {
            return null;
        }
        EventDefinition eventDefinition = new EventDefinition();
        String result = "";
        for (Map.Entry<String, EventDefinition> entry : checkMap.entrySet()) {
            EventDefinition event = entry.getValue();
            result = result + JSONObject.toJSONString(event)  + "\n";
        }
        eventDefinition.setMessage(result);
        eventDefinition.setTopic("{'exchange':'tmm-check','exchangeType':'fanout','vHost':'tmmVhost'}"); // TODO
        return eventDefinition;
    }

    @Override
    public void run() {
        executor();
    }

    public LogEventService getLogEventService() {
        return logEventService;
    }

    public EventDefinitionRegistry getSimpleEventDefinitionRegistry() {
        return simpleEventDefinitionRegistry;
    }

    public LogAnalyzerService getLogAnalyzerService() {
        return logAnalyzerService;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        // 启动线程
        new Thread(this).start();
        // 启动监控线程
        new Thread(new ZabbixServiceImpl(settingSupport, applicationContext.getBean(ZabbixClient.class))).start();
        // 启动删除文件定时任务
        initDeleteDoneFile();
    }

    public void initDeleteDoneFile() {

        //创建scheduler
        Scheduler scheduler = null;
        try {
            scheduler = StdSchedulerFactory.getDefaultScheduler();

            //定义一个Trigger
            Trigger trigger = TriggerBuilder.newTrigger().withIdentity("trigger1", "group1") //定义name/group
                    .startNow()//一旦加入scheduler，立即生效
                    .withSchedule(simpleSchedule() //使用SimpleTrigger
                            .withIntervalInSeconds(24 * 60 * 60) //每隔一天执行一次 单位s
                            .repeatForever()) //一直执行
                    .build();

            //定义一个JobDetail
            JobDataMap map = new JobDataMap();
            map.put("rpcDir", settingSupport.getRpcDir());
            JobDetail job = JobBuilder.newJob(DoneFileQuartz.class) //定义Job类为HelloQuartz类，这是真正的执行逻辑所在
                    .withIdentity("job1", "group1") //定义name/group
                    .usingJobData(map) //定义属性
                    .build();

            //加入这个调度
            scheduler.scheduleJob(job, trigger);

            //启动之
            scheduler.start();
        } catch (SchedulerException e) {
            logger.error("启动定时器失败！！");
        }
    }

}
