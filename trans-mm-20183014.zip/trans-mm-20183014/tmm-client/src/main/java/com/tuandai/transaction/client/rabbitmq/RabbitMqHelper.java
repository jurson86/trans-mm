package com.tuandai.transaction.client.rabbitmq;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.model.RabbitMQTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

public class RabbitMqHelper {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqHelper.class);

    public static void sendRabbitMQ(EventDefinition eventDefinition) throws Exception {
        RabbitMQTopic joTopic = JSONObject.parseObject(eventDefinition.getTopic(), RabbitMQTopic.class);
        if(StringUtils.isEmpty(joTopic.getvHost()) || StringUtils.isEmpty(joTopic.getExchange()) || StringUtils.isEmpty(joTopic.getExchangeType())) {
            logger.error("invalid rabbitmq topic : {}", eventDefinition.getTopic());
            return;
        }
        String exchange = joTopic.getExchange();
        String vHost = joTopic.getvHost();
        String exchangeType = joTopic.getExchangeType();
        String routeKey = joTopic.getRouteKey();
        boolean isCustomExchange = joTopic.isCustomExchange();
        RabbitMqServiceImpl.sendMessage(vHost, exchange, exchangeType, routeKey, eventDefinition.getMessage(), isCustomExchange);
    }

}
