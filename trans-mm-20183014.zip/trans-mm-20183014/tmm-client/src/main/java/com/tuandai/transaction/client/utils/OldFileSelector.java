package com.tuandai.transaction.client.utils;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Date;

public class OldFileSelector implements FilenameFilter {

    private String extension = ".";
    private int diffTime = 0;


    public OldFileSelector(String fileExtensionNoDot, int preDiffTime) {
        extension += fileExtensionNoDot;
        diffTime = preDiffTime;
    }

    @Override
    public boolean accept(File dir, String name) {
        long lastModifiedTime = dir.lastModified();
        // 当前时间
        long currentTime = new Date().getTime();
        // 前N天
        long nTime = currentTime - (diffTime * 24 * 60 * 60 * 1000);

        boolean isOk = lastModifiedTime < nTime;

        return name.endsWith(extension) && isOk;
    }
}
