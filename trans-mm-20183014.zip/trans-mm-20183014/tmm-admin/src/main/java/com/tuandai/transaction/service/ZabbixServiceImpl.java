package com.tuandai.transaction.service;

import com.tuandai.architecture.zabbix.ItemInfo;
import com.tuandai.architecture.zabbix.ZabbixClient;
import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.bo.TwoTuple;
import com.tuandai.transaction.dao.TransactionCheckDao;
import com.tuandai.transaction.service.inf.ZabbixService;
import com.tuandai.transaction.utils.NetUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ZabbixServiceImpl implements ZabbixService {

    @Autowired
    private TransactionCheckDao transactionCheckDao;

    @Autowired
    private ZabbixClient zabbixClient;

    @Override
    public Map<MessageState, Long> messageStateMonitor() {
        Map<MessageState, Long> map = new HashMap<>();
        List<TwoTuple<Integer, Long>> list = transactionCheckDao.messageStateCountMap();
        if (!CollectionUtils.isEmpty(list)) {
            for (TwoTuple<Integer, Long> tuple : list) {
                MessageState state = MessageState.findByValue(tuple.a);
                if (state != null) {
                    map.put(state, tuple.b);
                }

            }
        }
        return map;
    }

    @Scheduled(cron="0/10 * *  * * ? ") // 每10秒钟执行一次
    public void messageStateMonitorTask() {
        Map<MessageState, Long> map = messageStateMonitor();
        List<ItemInfo> list = new ArrayList<>();
        // 获取本机ip地址
        InetAddress ipAddress = NetUtils.getLocalHostLANAddress();
        for (Map.Entry<MessageState, Long> entry : map.entrySet()) {
            ItemInfo item = new ItemInfo();
            item.setValue(entry.getValue());
            item.setKey(entry.getKey().message());
            item.setHost(ipAddress.getHostAddress());
            list.add(item);
        }
        zabbixClient.send(list);
    }

}
