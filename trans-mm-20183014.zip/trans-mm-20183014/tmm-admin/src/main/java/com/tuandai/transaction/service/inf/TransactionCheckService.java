package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.utils.ServiceException;

import java.util.Date;
import java.util.List;

public interface TransactionCheckService {


    /**
     * 触发check操作
     */
    void preSendCallbackByTask()  throws ServiceException;

    /**
     * 触发Send操作
     */
    void sendTask() throws ServiceException;


    List<TransactionCheck> queryMessageByState(int state);

    boolean resend(Long pid);

    boolean discard(Long pid);


    boolean delete(Date startTime, Date endTime, Integer messageState);

}
