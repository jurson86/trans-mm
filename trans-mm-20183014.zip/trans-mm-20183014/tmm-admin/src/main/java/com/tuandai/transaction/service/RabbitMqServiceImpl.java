package com.tuandai.transaction.service;

import com.alibaba.fastjson.JSONObject;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.tuandai.transaction.bo.*;
import com.tuandai.transaction.dao.TransactionCheckDao;
import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.domain.filter.TransactionCheckFilter;
import com.tuandai.transaction.mq.RabbitTemplateFactory;
import com.tuandai.transaction.service.inf.RabbitMqService;
import com.tuandai.transaction.utils.BZStatusCode;
import com.tuandai.transaction.utils.ServiceException;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class RabbitMqServiceImpl implements RabbitMqService {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqServiceImpl.class);


    private RestTemplate restTemplate = new RestTemplate();

    Pattern pattern = Pattern.compile("^dlq--");

    @Value("${spring.rabbitmq.host}")
    private String url;

    @Value("${spring.rabbitmq.port}")
    private int port;

    @Value("${spring.rabbitmq.username}")
    private String username;

    @Value("${spring.rabbitmq.password}")
    private String password;

    private Map<String, ConnectionFactory> connectionFactoryCache = new ConcurrentHashMap<>();

    @Autowired
    private TransactionCheckDao transactionCheckDao;

    @Override
    public List<String> queryQueueList(String user, String passkey, String vHost) {

        return null;
    }

    public List<QueueJson> queryDLQList() {
        List<QueueJson> list = new ArrayList<>();
        // http://10.100.11.160:15672/api/queues/myVhost2?page=1&page_size=100&name=&use_regex=false&pagination=true
        // 通过url接口请求队列列表
        HttpHeaders header = new HttpHeaders();
        String base64ClientCredentials = new String(Base64.encodeBase64(new String(username + ":" + password).getBytes()));
        header.add("Authorization", "Basic " + base64ClientCredentials);
        //String vStr = vHost.equals("/") ? "%2F": (vHost);
        ResponseEntity<String> response = restTemplate.exchange("http://" + url + ":15672/api/queues/",
                HttpMethod.GET, new HttpEntity<String>(header), String.class);
        if (null != response && HttpStatus.OK.equals(response.getStatusCode())) {
            String resStr = response.getBody();
            List<QueueJson> tmplist = JSONObject.parseArray(resStr, QueueJson.class);
            if (tmplist != null) {
                for (QueueJson queueJson : tmplist) {
                    if (pattern.matcher(queueJson.getName()).find()) {
                        list.add(queueJson);
                    }
                }
            }
        }
        return list;
    }

    @Override
    public List<String> queryAllHostList() {
        List<String> list = new ArrayList<>();
        // http://10.100.11.73:15672/api/vhosts
        // 通过url接口请求队列列表
        HttpHeaders header = new HttpHeaders();
        String base64ClientCredentials = new String(Base64.encodeBase64(new String(username + ":" + password).getBytes()));
        header.add("Authorization", "Basic " + base64ClientCredentials);
        ResponseEntity<String> response = restTemplate.exchange( "http://10.100.11.73:15672/api/vhosts",
                HttpMethod.GET, new HttpEntity<String>(header), String.class);
        if (null != response && HttpStatus.OK.equals(response.getStatusCode())) {
            String resStr = response.getBody();
            List<VHostJson> array = JSONObject.parseArray(resStr, VHostJson.class);
            return array.stream().map(VHostJson::getName).collect(Collectors.toList());
        }
        return list;
    }

    @Override
    @Scheduled(cron="0/10 * *  * * ? ") // 每10秒钟执行一次
    public void rabbitmqDLQConsumer() {
        // 查询现有的死信队列
        List<QueueJson> dlqList = queryDLQList();
        for (QueueJson queue : dlqList) {
            doRabbitmqDLQConsumer(queue);
        }
    }

    @Override
    public boolean dlqResend(String queue) {
        boolean isResult = true;
        while (true) {
            TransactionCheckFilter filter = new TransactionCheckFilter();
            filter.setServiceName(queue);
            filter.setMessageState(MessageState.ABNORMAL.code());
            List<TransactionCheck> list = transactionCheckDao.queryTransactionCheckByFilter(filter, new Limiter(0, 1000, "pid ASC"));
            if (CollectionUtils.isEmpty(list) || list.size() == 0) {
                break;
            }
            // 重发
            for (TransactionCheck transactionCheck : list) {
                boolean isSend = false;
                try {
                    sendMessageToQueue(transactionCheck);
                    isSend = true;
                } catch (Exception e) {
                    logger.debug("重发消息失败！");
                    isResult = false;
                }
                if (isSend) {
                    TransactionCheck updateTmp = new TransactionCheck();
                    updateTmp.setPid(transactionCheck.getPid());
                    updateTmp.setUpdateTime(new Date());
                    updateTmp.setMessageState(MessageState.DONE.code());
                    transactionCheckDao.update(updateTmp);
                }
            }
        }
        return isResult;
    }

    @Override
    public List<QueueJson> dlqList() {
        List<QueueJson> resultList = new ArrayList<>();
        List<TwoTuple<String, Long>> list = transactionCheckDao.dlqList();
        if (!CollectionUtils.isEmpty(list)) {
            for (TwoTuple<String, Long> twoTuple : list) {
                String serviceName = twoTuple.a;
                // 解析相关信息
                String[] pnames = serviceName.split("--");
                String vHost = pnames[1]; // 虚拟host
                QueueJson queueJson = new QueueJson();
                queueJson.setMessages(twoTuple.b == null ? 0 : twoTuple.b);
                queueJson.setName(twoTuple.a);
                queueJson.setVhost(vHost);
                resultList.add(queueJson);
            }
        }
        return resultList;
    }


    private void doRabbitmqDLQConsumer(QueueJson queue) {
        RabbitTemplate rabbitTemplate = RabbitTemplateFactory.getRabbitTemplate(queue.getVhost());
        Long count = queue.getMessages();
        List<TransactionCheck> daoList = new ArrayList<>();
        while (count-- > 0) {
            byte[] sad = null;
            try {
                sad = (byte[]) rabbitTemplate.receiveAndConvert(queue.getName());
            } catch (Exception e) {
                logger.error("消费死信队列消息异常，" , e);
            }
            if (sad == null) {
                break;
            }
            daoList.add(buildTransactionCheck(queue, sad));
            if (daoList.size() > 100) {
                break;
            }
        }
        if (!CollectionUtils.isEmpty(daoList)) {
            transactionCheckDao.insertBatch(daoList);
        }
    }

    public void sendMessageToQueue(TransactionCheck transactionMessage) {
        if (transactionMessage == null || transactionMessage.getMessageTopic() == null) {
            logger.error("transactionMessage or transactionMessage.getMessageTopic() is not null...");
            throw new ServiceException(BZStatusCode.INVALID_PARAMS_IS_NULL);
        }

        RabbitMQTopic rabbitTopic = JSONObject.parseObject(transactionMessage.getMessageTopic(), RabbitMQTopic.class);
        if (rabbitTopic == null || rabbitTopic.getQueue() == null || rabbitTopic.getvHost() == null) {
            logger.error("rabbitTopic or properties is not null...");
            throw new ServiceException(BZStatusCode.INVALID_PARAMS_IS_NULL);
        }

        ConnectionFactory factory = connectionFactoryCache.get(rabbitTopic.getvHost());
        if (factory == null) {
            factory = new ConnectionFactory();
            factory.setHost(url);// MQ的IP
            factory.setPort(port);// MQ端口
            factory.setUsername(username);// MQ用户名
            factory.setPassword(password);// MQ密码
            factory.setVirtualHost(rabbitTopic.getvHost());
            connectionFactoryCache.put(rabbitTopic.getvHost(), factory);
        }
        Channel channel = null;
        Connection connection = null;
        try{
            connection = factory.newConnection();
            channel = connection.createChannel();
            // 一定先创建队列，否则系统不会报错，但是信息被丢弃了。
            channel.basicPublish("",rabbitTopic.getQueue(),null, transactionMessage.getMessage().getBytes());
        } catch (Exception e) {
            logger.error("消息发送失败！", e);
            throw new ServiceException(BZStatusCode.SERVER_UNKNOWN_ERROR);
        } finally {
            if (channel != null) {
                try {
                    channel.close();
                } catch (Exception e) {
                    logger.error("关闭channel失败", e);
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (IOException e) {
                    logger.error("关闭connection失败", e);
                }
            }
        }
    }


    private TransactionCheck buildTransactionCheck(QueueJson queue, byte[] sad) {
        MessageJson message = JSONObject.parseObject(sad, MessageJson.class);

        // 入库
        Date date = new Date();
        TransactionCheck transactionState = new TransactionCheck();
        transactionState.setuId(message.getUid());
        transactionState.setServiceName(queue.getName());
        transactionState.setCreateTime(date);
        transactionState.setUpdateTime(date);
        transactionState.setMessageState(MessageState.ABNORMAL.code()); // 消费异常
        transactionState.setMessageSendThreshold(Thresholds.MAX_SEND.code()); // 最大重试次数
        transactionState.setMessageSendTimes(0);
        transactionState.setMessageNextSendTime(new Date());
        transactionState.setMessageNextSendTime(date);
        transactionState.setPresendBackNextSendTime(new Date());
        transactionState.setPresendBackUrl("");
        transactionState.setPresendBackMethod("");
        transactionState.setPresendBackThreshold(0); // 不需要回调
        transactionState.setPresendBackSendTimes(0);
        transactionState.setMessage(new String(sad));

        RabbitMQTopic topic = new RabbitMQTopic();
        // 生产者队列名
        String[] pnames = queue.getName().split("--");
        String dqueue = pnames[3]; // 要发送的队列名称
        String vHost = pnames[1]; // 虚拟host
        String vExchange = pnames[2];
        topic.setExchange(vExchange);
        topic.setExchangeType("fanout");
        topic.setvHost(vHost);
        topic.setQueue(dqueue);
        transactionState.setMessageTopic(JSONObject.toJSONString(topic));
        return transactionState;
    }

}

