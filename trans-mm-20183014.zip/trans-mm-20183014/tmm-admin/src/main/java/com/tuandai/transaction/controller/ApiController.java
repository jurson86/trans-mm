package com.tuandai.transaction.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.tuandai.transaction.bo.QueueJson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.service.inf.RabbitMqService;
import com.tuandai.transaction.service.inf.TransactionCheckService;
import com.tuandai.transaction.utils.Result;

@RestController
@RequestMapping(value = "/api")
public class ApiController {

	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);

	@Autowired
	private TransactionCheckService transactionCheckService;

	@Autowired
	private RabbitMqService rabbitMqService;

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public HashMap<String, Object> get(@RequestParam String name) {
		
    	logger.info("get: {}",name);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("title", "hello world");
		map.put("name", name);
		
		return map;
	}

	@RequestMapping(value = "/preSendCallbackByTask", method = RequestMethod.GET)
	public void preSendCallbackByTask() {
		transactionCheckService.preSendCallbackByTask();
	}

	// 查询消息状态列表
	@RequestMapping(value = "/messageList/state", method = RequestMethod.GET)
	public Object queryMessageListByState(@RequestParam Integer state) {
		logger.debug("queryMessageListByState: {} ", state);
		List<TransactionCheck> list = transactionCheckService.queryMessageByState(state);
		return new ResponseEntity<Result<List<TransactionCheck>>>(new Result<List<TransactionCheck>>(list),
				HttpStatus.OK);
	}

	// 消息重发
	@RequestMapping(value = "/message/resend", method = RequestMethod.POST)
	public Object resend(@RequestParam long pid) {
		boolean result = transactionCheckService.resend(pid);
		return new  ResponseEntity<Result<Boolean>>(new Result<Boolean>(result), HttpStatus.OK);
	}

	// 消息废弃
	@RequestMapping(value = "/message/discard", method = RequestMethod.POST)
	public Object discard(@RequestParam long pid) {
		boolean result = transactionCheckService.discard(pid);
		return new  ResponseEntity<Result<Boolean>>(new Result<Boolean>(result), HttpStatus.OK);
	}

	// 消费者死信队列重发
	@RequestMapping(value = "/message/dlq/resend", method = RequestMethod.POST)
	public Object dlqResend(@RequestParam String queue) {
		boolean result = rabbitMqService.dlqResend(queue);
		return new  ResponseEntity<Result<Boolean>>(new Result<Boolean>(result), HttpStatus.OK);
	}

	// 消费者死信队列统计
	@RequestMapping(value = "/message/dlq/list", method = RequestMethod.GET)
	public Object dlqList() {
		List<QueueJson> result = rabbitMqService.dlqList();
		return new  ResponseEntity<Result<List<QueueJson>>>(new Result<List<QueueJson>>(result), HttpStatus.OK);
	}

	@RequestMapping(value = "/message/delete", method = RequestMethod.POST)
		public Object deleteMessage(@RequestParam long startTime, @RequestParam long endTime, @RequestParam int state) {
		boolean result = transactionCheckService.delete(new Date(startTime), new Date(endTime), state);
		return new ResponseEntity<Result<Boolean>>(new Result<Boolean>(result), HttpStatus.OK);
	}

}