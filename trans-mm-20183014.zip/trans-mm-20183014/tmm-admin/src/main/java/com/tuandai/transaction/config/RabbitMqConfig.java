package com.tuandai.transaction.config;


import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMqConfig {

    @Bean
    public FanoutExchange mychange() {
        return  new FanoutExchange("tmm-check");
    }

    @Bean
    public Queue createQueue() {
        return new Queue("tmm-check-queue");
    }

    @Bean
    public Binding bindingDemoQuAndMychange(@Qualifier("createQueue") Queue queue, @Qualifier("mychange") FanoutExchange fanoutExchange ) {
        return BindingBuilder.bind(queue).to(fanoutExchange);
    }
}
