package com.tuandai.transaction.config;

import com.tuandai.transaction.dao.TransactionCheckDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tuandai.transaction.repository.TransactionCheckRepository;


@Component
public class InitailDBTables {

	@Autowired
	private TransactionCheckDao transactionCheckDao;

	public void createTables() {
		transactionCheckDao.createIfNotExistsTable();
	}
}
