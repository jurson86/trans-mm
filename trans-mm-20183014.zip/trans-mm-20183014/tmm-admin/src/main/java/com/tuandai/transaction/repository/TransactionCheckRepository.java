package com.tuandai.transaction.repository;


import com.tuandai.transaction.bo.Limiter;
import com.tuandai.transaction.bo.TwoTuple;
import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.domain.filter.TransactionCheckFilter;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface TransactionCheckRepository {

    void createIfNotExistsTable();

    void insertBatch(List<TransactionCheck> transactionStates);

    List<TransactionCheck> queryTransactionCheckByFilter(@Param("filter") TransactionCheckFilter transactionCheckFilter, @Param("limiter")  Limiter limiter);

    void update(TransactionCheck transactionCheck);

    // 删除表里面所有的数据
    void deleteAll();

    // 统计各状态下的消息状态数量
    List<TwoTuple<Integer, Long>> messageStateCountMap();

    List<TwoTuple<String, Long>> dlqList();

    void delete(@Param("startTime")Date startTime, @Param("endTime") Date endTime, @Param("state") Integer state);

}
