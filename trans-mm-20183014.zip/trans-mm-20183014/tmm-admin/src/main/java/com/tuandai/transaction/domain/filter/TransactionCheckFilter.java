package com.tuandai.transaction.domain.filter;

import java.util.Date;

public class TransactionCheckFilter {

    // 消息状态
    private Integer messageState;

    // 最大预发送回调时间
    private Date endPresendBackNextSendTime;

    // 最大发送回调时间
    private Date endMessageNextSendTime;

    private Long pid;

    private String serviceName;

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public Date getEndMessageNextSendTime() {
        return endMessageNextSendTime;
    }

    public void setEndMessageNextSendTime(Date endMessageNextSendTime) {
        this.endMessageNextSendTime = endMessageNextSendTime;
    }

    public Long getPid() {
        return pid;
    }

    public void setPid(Long pid) {
        this.pid = pid;
    }

    public Date getEndPresendBackNextSendTime() {
        return endPresendBackNextSendTime;
    }

    public void setEndPresendBackNextSendTime(Date endPresendBackNextSendTime) {
        this.endPresendBackNextSendTime = endPresendBackNextSendTime;
    }

    public Integer getMessageState() {
        return messageState;
    }

    public void setMessageState(Integer messageState) {
        this.messageState = messageState;
    }
}
