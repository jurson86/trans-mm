package com.tuandai.architecture.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.tuandai.architecture.model.TryPointModel;
import com.tuandai.architecture.service.PointService;
import com.tuandai.architecture.util.Result;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@RestController
public class NomalController {

	private static final Logger logger = LoggerFactory.getLogger(NomalController.class);

	@Autowired
	PointService pointService;
	

	/** 防止远程调用链超时 , 快速失败时间不宜设置太短，一致性要求较高的场景，需要尽量长的时间保障，防止降级导致一致性异常。
	 *  当前采用 信号量 隔离策略
	 * @param body
	 * @return
	 */	
	@HystrixCommand(fallbackMethod = "tccTryFallback", 
			commandKey = "PointTryTimeout", commandProperties = {
					@HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
					@HystrixProperty(name = "execution.isolation.semaphore.maxConcurrentRequests", value = "22"),
					@HystrixProperty(name = "fallback.isolation.semaphore.maxConcurrentRequests", value = "10")})
	@ApiOperation(value = "预添加积分", notes = "预添加积分")
	@ApiImplicitParam(name = "body", value = "事务信息", paramType = "body", required = true, dataType = "TryPointModel")
	@RequestMapping(value = "/point/try", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> tccTry(@Valid @RequestBody TryPointModel body) {

		String name = body.getName();
		String transId = body.getTransId();

		int row = pointService.transTry(name, transId);

		HttpStatus httpStatus = HttpStatus.OK;
		if (0 == row) {
			httpStatus = HttpStatus.FAILED_DEPENDENCY;
		}
		return new ResponseEntity<Result<String>>(new Result<String>(transId), httpStatus);

	}

	public ResponseEntity<Result<String>> tccTryFallback(@Valid @RequestBody TryPointModel body) {
		logger.error("fallback =============== tccTry : {}", body.toString());

		return new ResponseEntity<Result<String>>(new Result<String>(""), HttpStatus.FAILED_DEPENDENCY);
	}

}