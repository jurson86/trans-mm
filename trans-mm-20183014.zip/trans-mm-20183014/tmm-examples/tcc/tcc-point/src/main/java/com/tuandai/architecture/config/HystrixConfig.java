package com.tuandai.architecture.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.config.ConfigurationManager;

@Component
public class HystrixConfig {
	private static final Logger logger = LoggerFactory.getLogger(HystrixConfig.class);
	
	//断路器配置
	public void inital()
	{
		// fallback make max concurrent requests to 200
		ConfigurationManager.getConfigInstance().setProperty("hystrix.command.default.fallback.isolation.semaphore.maxConcurrentRequests", 200);
		
		// 防止远程调用链超时 , 快速失败时间不宜设置太短，一致性要求较高的场景，需要尽量长的时间保障，防止降级导致一致性异常。
		logger.info("========= Point Try max timeout =========: {} ms", 3000);
	    ConfigurationManager.getConfigInstance().setProperty("hystrix.command.PointTryTimeout.execution.isolation.thread.timeoutInMilliseconds",3000);

		// 资源隔离，限流降级
		logger.info("========= Point Try max pool =========: {}" , 10);
	    ConfigurationManager.getConfigInstance().setProperty("hystrix.threadpool.PointTryPool.coreSize",10);
	}

}
