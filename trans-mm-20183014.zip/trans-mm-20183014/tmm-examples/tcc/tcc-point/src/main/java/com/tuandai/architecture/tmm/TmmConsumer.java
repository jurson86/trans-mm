package com.tuandai.architecture.tmm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.architecture.service.PointService;

@Component
public class TmmConsumer {
	private static final Logger logger = LoggerFactory.getLogger(TmmConsumer.class);
	@Autowired
	PointService pointService;

	@RabbitListener(queues = "tccpoint")
	@RabbitHandler
	public void hadler(@Payload String datas) {
		String msg = datas;
		logger.debug("消费消息:" +  msg);
		String transId = JSONObject.parseObject(msg).getString("uid");
		int state = JSONObject.parseObject(msg).getIntValue("state");
		if (state == 0) {// 提交
			if (!pointService.transConfirm(transId)) {
				throw new RuntimeException("deal  message exception!");
			}
		} else if (state == 1) {// 回滚
			logger.error("cancel point : {}", transId);
			if (!pointService.transCancel(transId)) {
				throw new RuntimeException("deal  message exception!");
			}
		}
	}
}
