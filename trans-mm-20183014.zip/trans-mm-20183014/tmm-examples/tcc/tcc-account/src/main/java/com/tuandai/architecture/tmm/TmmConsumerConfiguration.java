package com.tuandai.architecture.tmm;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.tuandai.transaction.client.consumer.DeclareDeadQueue;

@Configuration
public class TmmConsumerConfiguration {

	//【业务自定义】声明消费交换机
	@Bean
	public TopicExchange mychange() {
		return new TopicExchange("tccExchange");
	}
	
	//【业务自定义】消费队列绑定消费交换机
	@Bean
	public Binding bingdingqueue(@Qualifier("tccaccount") Queue queue,
			@Qualifier("mychange") TopicExchange topicExchange) {
		return BindingBuilder.bind(queue).to(topicExchange).with("#.tcc-account/account.#");
	}

	//【TMMCLient】消费队列绑定死信交换机
	@Bean
	public DeclareDeadQueue createAmqpConfig() {
		return new DeclareDeadQueue("tccaccount", "myVhost2", "tccExchange");
	}
}
