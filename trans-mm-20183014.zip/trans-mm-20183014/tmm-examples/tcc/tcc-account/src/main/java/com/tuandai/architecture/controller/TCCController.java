package com.tuandai.architecture.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.tuandai.architecture.model.TryAccountModel;
import com.tuandai.architecture.service.AccountService;
import com.tuandai.architecture.util.Result;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@RestController
public class TCCController {

	private static final Logger logger = LoggerFactory.getLogger(TCCController.class);

	@Autowired
	AccountService accountService;

	/** 防止远程调用链超时 , 快速失败超时时间不宜设置太短，一致性要求较高的场景，需要尽量长的时间保障，防止降级导致一致性异常。
	 *  当前采用 信号量 隔离策略
	 * @param body
	 * @return
	 */	
	@HystrixCommand(fallbackMethod = "tccTryFallback", 
			commandKey = "AccountTryTimeout", commandProperties = {
					@HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
					@HystrixProperty(name = "execution.isolation.semaphore.maxConcurrentRequests", value = "21"),
					@HystrixProperty(name = "fallback.isolation.semaphore.maxConcurrentRequests", value = "100")})
	@ApiOperation(value = "冻结资金", notes = "冻结资金")
	@ApiImplicitParam(name = "body", value = "事务信息", paramType = "body", required = true, dataType = "TryAccountModel")
	@RequestMapping(value = "/account/try", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> tccTry(@Valid @RequestBody TryAccountModel body) {

		logger.debug("tccTry b: {}", body.toString());
		String name = body.getName();
		String transId = body.getTransId();

		int row = accountService.transTry(name, transId);

		logger.debug("tccTry e: {}", transId);

		HttpStatus httpStatus = HttpStatus.OK;
		if (0 == row) {
			httpStatus = HttpStatus.FAILED_DEPENDENCY;
		}
		return new ResponseEntity<Result<String>>(new Result<String>(transId), httpStatus);

	}

	public ResponseEntity<Result<String>> tccTryFallback(@Valid @RequestBody TryAccountModel body) {
		logger.error("fallback =============== tccTry : {}", body.toString());
		
		return new ResponseEntity<Result<String>>(new Result<String>(""), HttpStatus.FAILED_DEPENDENCY);
	}

}