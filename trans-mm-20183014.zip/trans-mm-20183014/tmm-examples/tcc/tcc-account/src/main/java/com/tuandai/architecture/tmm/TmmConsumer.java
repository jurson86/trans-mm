package com.tuandai.architecture.tmm;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.architecture.service.AccountService;

@Component
public class TmmConsumer {
	private static final Logger logger = LoggerFactory.getLogger(TmmConsumer.class);

	@Autowired
	AccountService accountService;

	@RabbitListener(queues = "tccaccount")
	@RabbitHandler
	public void hadler(@Payload String datas) {
		String msg = datas;
		String transId = JSONObject.parseObject(msg).getString("uid");
		int state = JSONObject.parseObject(msg).getIntValue("state");
		if (state == 0) {// 提交
			if (!accountService.transConfirm(transId)) {
				throw new RuntimeException("deal  message exception!");
			}
		} else if (state == 1) {// 回滚
			logger.error("cancel account : {}", transId);
			if (!accountService.transCancel(transId)) {
				throw new RuntimeException("deal  message exception!");
			}
		}
	}
}
