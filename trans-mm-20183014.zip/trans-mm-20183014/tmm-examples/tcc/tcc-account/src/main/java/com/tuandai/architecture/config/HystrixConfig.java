package com.tuandai.architecture.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.netflix.config.ConfigurationManager;

@Component
public class HystrixConfig {
	private static final Logger logger = LoggerFactory.getLogger(HystrixConfig.class);
	
	/*
	 * hystrix config change 
	 */
	public void inital()
	{
		// fallback make max concurrent requests to 200
		ConfigurationManager.getConfigInstance().setProperty("hystrix.command.default.fallback.isolation.semaphore.maxConcurrentRequests", 200);
		
		logger.info("=========  Try max timeout =========: {} ms", 3000);
	    ConfigurationManager.getConfigInstance().setProperty("hystrix.command.AccountServiceTimeout.execution.isolation.thread.timeoutInMilliseconds",3000);

		logger.info("=========  pool =========: {}" , 20);
	    ConfigurationManager.getConfigInstance().setProperty("hystrix.threadpool.AccountServicePool.coreSize",20);
	}

}
