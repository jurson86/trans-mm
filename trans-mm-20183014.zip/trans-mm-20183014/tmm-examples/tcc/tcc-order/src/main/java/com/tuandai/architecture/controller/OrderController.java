package com.tuandai.architecture.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.architecture.controller.client.TccClientRest;
import com.tuandai.architecture.util.Result;
import com.tuandai.transaction.client.SendState;
import com.tuandai.transaction.client.impl.TMMService;
import com.tuandai.transaction.client.model.BeginLog;
import com.tuandai.transaction.client.model.EndLog;
import com.tuandai.transaction.client.model.RabbitMQTopic;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;

@RestController
public class OrderController {

	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	TccClientRest tccClientRest;
	
	@Autowired
	TMMService tmmService;
	
	// 创建事务
	private String serviceName = "tcc-order";
	private static final String KEY_SEPARATOR_CHAR = ".";


	@ApiOperation(value = "发起事务订单", notes = "发起事务订单")
	@RequestMapping(value = "/tcc", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> tcc(String name) {
		
		
		/**
		 * 开始事务日志
		 */
		//将消费者资源方设置为 key
		String resUrlsKey = KEY_SEPARATOR_CHAR + TccClientRest.ACCOUNT_SERVICE + KEY_SEPARATOR_CHAR
				+ TccClientRest.POINT_SERVICE + KEY_SEPARATOR_CHAR;
		//设置topic
		RabbitMQTopic rabbitMQTopic = new RabbitMQTopic();
		rabbitMQTopic.setvHost("myVhost2");
		rabbitMQTopic.setExchange("tccExchange");
		rabbitMQTopic.setExchangeType("topic");
		rabbitMQTopic.setRouteKey(resUrlsKey);
		
		String uid = UUID.randomUUID().toString();
		
		BeginLog beginLog = new BeginLog();
		beginLog.setCheck("tcc-order/check");
		beginLog.setMessage(null);
		beginLog.setServiceName(serviceName);
		beginLog.setTopic(rabbitMQTopic.toJSONString());
		beginLog.setUid(uid);
		tmmService.sendTransBeginToFlume(beginLog);
		

		/**
		 * TODO 业务处理
		 */
		PatchTransModel patchTransModel = new PatchTransModel();
		patchTransModel.setName(name);
		patchTransModel.setTransId(uid);
		MessageModel messageModel = new MessageModel();
		messageModel.setUid(uid);
		messageModel.setMsg("hello world!");
		// 冻结 资金 ， 积分
		if (!(tccClientRest.tryAccount(patchTransModel) && tccClientRest.tryPoint(patchTransModel))) {
			// 取消TCC事务;
			messageModel.setState(1);
		} else {
			// 提交TCC事务;
			messageModel.setState(0);
		}
		
		
		/**
		 * 结束事务日志
		 */
		EndLog endLog = new EndLog();
		endLog.setState(SendState.COMMIT);
		endLog.setMessage(JSONObject.toJSONString(messageModel));
		endLog.setServiceName(serviceName);
		endLog.setUid(uid);
		tmmService.sendTransEndToFlume(endLog);

		return new ResponseEntity<Result<String>>(new Result<String>(""), HttpStatus.OK);
	}

	@ApiOperation(value = "检测事务订单", notes = "检测事务订单")
	@ApiImplicitParam(name = "transId", value = "事务ID", paramType = "transId", required = true, dataType = "String")
	@RequestMapping(value = "/check", method = RequestMethod.POST)
	public HashMap<String, Object> tccCheck(@Valid @RequestBody String transId) {

		logger.info("check: {}", transId);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("uid", transId);
		map.put("serviceName", serviceName);
		map.put("state", SendState.CANCEL);

		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
		String dateString = formatter.format(currentTime);
		map.put("ctime", dateString);

		return map;
	}

	@RequestMapping(value = "/healthy", method = RequestMethod.GET)
	public HashMap<String, Object> healthy(@Valid @RequestBody String transId) {

		logger.info("check: {}", transId);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("uid", transId);
		map.put("serviceName", serviceName);
		map.put("state", SendState.CANCEL);

		Date currentTime = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
		String dateString = formatter.format(currentTime);
		map.put("ctime", dateString);

		return map;
	}
}