package com.tuandai.transaction.mq;

import com.tuandai.transaction.config.SpringBootConfig;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.model.constants.MqType;
import com.tuandai.transaction.mq.inf.MqService;
import com.tuandai.transaction.mq.inf.MqServiceFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 默认的适配Mq中间件策略
 */
public class DefaultMqServiceFactory extends AbstractMqServiceFactory {

    private static final Logger logger = LoggerFactory.getLogger(DefaultMqServiceFactory.class);

    public DefaultMqServiceFactory() {
        super(SpringBootConfig.getMqType());
    }

    @Override
    public MqService createMqService() {

        MqType mqType = getMqType();

        if (mqType == null) {
            logger.error("mqType is not null ....");
        }

        return mqType == MqType.RABBIT ? new RabbitMqServiceImpl() : new RocketMqServiceImpl();
    }
}
