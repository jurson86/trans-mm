package com.tuandai.transaction.dao;

import com.tuandai.transaction.domain.filter.Limiter;
import com.tuandai.transaction.domain.filter.TransactionMessageFilter;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.repository.TransactionMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class TransactionMessageDao {

    @Autowired
    private TransactionMessageRepository transactionMessageRepository;


    public void createIfNotExistsTable() {
        transactionMessageRepository.createIfNotExistsTable();
    }


    public void insert(TransactionMessage transactionMessage) {
        transactionMessageRepository.insert(transactionMessage);
    }


    public TransactionMessage findByTransactionId(Long transactionId) {
        if (transactionId == null) {
            return null;
        }
        TransactionMessageFilter filter = new TransactionMessageFilter();
        List<Long> ids = new ArrayList<>();
        ids.add(transactionId);
        filter.setTransactionIds(ids);
        List<TransactionMessage> list = transactionMessageRepository.findTransactionMessageListByFilter(filter, new Limiter(0, 1,
                "transaction_id DESC"));
        return CollectionUtils.isEmpty(list) ? null : list.get(0);
    }

    public Map<Long, TransactionMessage> findByTransactionMessageMapByIds(List<Long> transactionIds) {
        Map<Long, TransactionMessage> map = new HashMap<>();
        if (CollectionUtils.isEmpty(transactionIds)) {
            return map;
        }
        TransactionMessageFilter filter = new TransactionMessageFilter();
        filter.setTransactionIds(transactionIds);
        List<TransactionMessage> list = transactionMessageRepository.findTransactionMessageListByFilter(filter,
                new Limiter(0, 1, "transaction_id DESC"));
        if (!CollectionUtils.isEmpty(list)) {
            for (TransactionMessage transactionMessage : list) {
                map.put(transactionMessage.getTransactionId(), transactionMessage);
            }
        }
        return map;
    }

    public List<TransactionMessage> findByTransactionMessageListByIds(List<Long> transactionIds) {
        List<TransactionMessage> list = new ArrayList<>();
        if (CollectionUtils.isEmpty(transactionIds)) {
            return list;
        }
        TransactionMessageFilter filter = new TransactionMessageFilter();
        filter.setTransactionIds(transactionIds);
        List<TransactionMessage> reusltList = transactionMessageRepository.findTransactionMessageListByFilter(filter,
                new Limiter(0, 1, "transaction_id DESC"));
        return CollectionUtils.isEmpty(reusltList) ? list : reusltList;
    }

    public List<TransactionMessage> findByTransactionMessageByFilter(TransactionMessageFilter filter, Limiter limiter) {
        return transactionMessageRepository.findTransactionMessageListByFilter(filter, limiter);
    }


}
