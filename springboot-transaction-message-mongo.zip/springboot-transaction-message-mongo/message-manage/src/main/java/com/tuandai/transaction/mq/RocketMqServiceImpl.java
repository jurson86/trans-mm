package com.tuandai.transaction.mq;

import org.apache.rocketmq.common.message.MessageConst;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.qianmi.ms.starter.rocketmq.core.RocketMQTemplate;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.mq.inf.MqService;
import com.tuandai.transaction.util.SpringUtil;

public class RocketMqServiceImpl implements MqService {

    private RocketMQTemplate rocketMQTemplate;

    public RocketMqServiceImpl() {
        rocketMQTemplate = SpringUtil.getBean(RocketMQTemplate.class);
    }

    @Override
    public void sendMessage(TransactionMessage transactionMessage) {

        String keyStr = transactionMessage.getWorkerId() + Constants.MESSAGE_ID_SPLIT + transactionMessage.getTransactionId();

        Message<?> message = MessageBuilder.withPayload(transactionMessage.getMessage())
                .setHeader(MessageConst.PROPERTY_KEYS, keyStr).build();

        rocketMQTemplate.send(transactionMessage.getMessageTopic(), message);
    }
}
