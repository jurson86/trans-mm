package com.tuandai.transaction.component;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;


@Component
public class InitailDBTables {

	@Autowired
	private TransactionMessageDao transactionMessageDao;


	@Autowired
	private TransactionStateDao transactionStateDao;

	public void createTables() {
		transactionMessageDao.createIfNotExistsTable();
		transactionStateDao.createIfNotExistsTable();
	}
}
