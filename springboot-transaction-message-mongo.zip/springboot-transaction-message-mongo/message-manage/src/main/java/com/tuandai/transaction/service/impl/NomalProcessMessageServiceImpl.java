package com.tuandai.transaction.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.google.common.base.Preconditions;
import com.tuandai.transaction.component.ThresholdsTimeManage;
import com.tuandai.transaction.constant.BZStatusCode;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;
import com.tuandai.transaction.domain.OptLog;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.domain.filter.Limiter;
import com.tuandai.transaction.domain.filter.TransactionStateFilter;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.model.constants.Thresholds;
import com.tuandai.transaction.model.request.MessageIdAck;
import com.tuandai.transaction.model.request.MessageIdCreator;
import com.tuandai.transaction.mq.MqSendHelper;
import com.tuandai.transaction.service.NomalProcessMessageService;
import com.tuandai.transaction.service.TmmLogService;
import com.tuandai.transaction.service.util.NomalProcessMessageServiceHelper;

@Service
public class NomalProcessMessageServiceImpl implements NomalProcessMessageService {

	private static final Logger logger = LoggerFactory.getLogger(NomalProcessMessageServiceImpl.class);

	@Resource
	private TransactionMessageDao transactionMessageDao;

	@Resource
	private TransactionStateDao transactionStateDao;

	@Autowired
	private ThresholdsTimeManage thresholdsTimeManage;

	@Autowired
	private TransactionTemplate transactionTemplate;

	@Autowired
	private MqSendHelper mqSendHelper;
	
	@Autowired
	private TmmLogService tmmLogService;

	@Override
	public Long createMessage(MessageIdCreator mc) {
		Long workerId = Constants.getRouteKey();

		// 生成预发送消息
		TransactionState transactionState = NomalProcessMessageServiceHelper.
				messageIdCreator2TransactionState(mc, workerId);
		transactionState.setPresendBackNextSendTime(thresholdsTimeManage.
				createPreSendBackTime(Thresholds.MAX_PRESENDBACK.code()));
		
		long time = System.currentTimeMillis();
		transactionStateDao.insert(transactionState);
		logger.debug("transactionMessageRepository.insert, oldNoSharding,time[" + (System.currentTimeMillis() - time) + "ms]");

		Long transactionId = transactionState.getTransactionId();

		if (null == transactionId || 0 == transactionId) {
			logger.error("transaction id generator error!");
			throw new ServiceException(BZStatusCode.SERVER_IS_BUSY_NOW);
		}

		// 操作日志
		OptLog log = new OptLog();
		log.setBeginState(0);
		log.setEndState(MessageState.PRESEND.code());
		log.setOptionLog("create");
		log.setOptionMethod("createMessage");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionId);
		log.setWorkerId(workerId);
		tmmLogService.writeLog(log);

		return transactionId;
	}

	@Override
	public void updateMessageToSend(Long transactionId, MessageIdAck messageIdAck) {

		TransactionState transactionState = transactionStateDao.findByTransactionId(transactionId);
		Preconditions.checkNotNull(transactionState);

		if (MessageState.PRESEND.code() != transactionState.getMessageState()
				&& MessageState.DIED.code() != transactionState.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		TransactionMessage transactionMessage = null;

		if (MessageState.PRESEND.code() == transactionState.getMessageState()) {
			Preconditions.checkNotNull(messageIdAck);			
			transactionMessage = NomalProcessMessageServiceHelper.messageState2MessageManage(transactionState, messageIdAck);
			// 持久化汇总表的消息
			transactionMessageDao.insert(transactionMessage);
		} else {
			// 查询汇总表
			transactionMessage = transactionMessageDao.findByTransactionId(transactionId);
		}


		//TODO 后续添加JOB项目，下面操作需要JOB异步处理， 消息发送
		Preconditions.checkNotNull(transactionMessage);
		Boolean sendMark = false;
		try {
			mqSendHelper.sendTranTopicMsg(transactionMessage);
			sendMark = true;
		} catch (Exception e) {
			logger.error("=================send exception============= {}", e.getMessage());
		}

		Boolean finalSendMark = sendMark;
		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				if (finalSendMark) { // 发送mq成功
					transactionStateDao.delete(transactionId);
					// 操作信息
					OptLog log = new OptLog();
					log.setBeginState(MessageState.SEND.code());
					log.setEndState(MessageState.DONE.code());
					log.setOptionLog("send");
					log.setOptionMethod("send");
					log.setOptionTime(new Date());
					log.setTransactionId(transactionId);
					log.setWorkerId(transactionState.getWorkerId());
					tmmLogService.writeLog(log);
				} else {
					// 更新中间状态表
					TransactionState updateTransactionState = NomalProcessMessageServiceHelper.
							buildUpdateTransactionState(transactionState, messageIdAck,
									thresholdsTimeManage.createSendNextTime(Thresholds.MAX_SEND.code()));
					transactionStateDao.update(updateTransactionState);
					// 操作信息
					OptLog log = new OptLog();
					log.setBeginState(MessageState.SEND.code());
					log.setEndState(MessageState.SEND.code());
					log.setOptionLog("send");
					log.setOptionMethod("send");
					log.setOptionTime(new Date());
					log.setTransactionId(transactionId);
					log.setWorkerId(transactionState.getWorkerId());
					tmmLogService.writeLog(log);
				}
			}
		});
	}


	@Override
	public void updateMessageToDiscard(Long messageId, MessageIdAck messageIdAck) {

		TransactionState transactionState = transactionStateDao.findByTransactionId(messageId);

		Preconditions.checkNotNull(transactionState);

		if (MessageState.DISCARD.code() == transactionState.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		if (messageIdAck != null) {
			TransactionMessage transactionMessage = NomalProcessMessageServiceHelper.messageState2MessageManage(transactionState, messageIdAck);
			transactionMessageDao.insert(transactionMessage);
		}

		transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				// 删除废弃的消息
				transactionStateDao.delete(messageId);
				// 操作信息
				OptLog log = new OptLog();
				log.setBeginState(transactionState.getMessageState());
				log.setEndState(MessageState.DISCARD.code());
				log.setOptionLog("discard");
				log.setOptionMethod("updateMessageToDiscard");
				log.setOptionTime(new Date());
				log.setTransactionId(messageId);
				log.setWorkerId(transactionState.getWorkerId());
				tmmLogService.writeLog(log);
			}
		});
	}

	@Override
	public TransactionMessage getTransactionMessageById(Long transactionId) throws ServiceException {

		TransactionMessage transactionMessage = transactionMessageDao.findByTransactionId(transactionId);

		return transactionMessage;
	}

	@Override
	public TransactionState getTransactionStateById(Long messageId) throws ServiceException {
		return transactionStateDao.findByTransactionId(messageId);
	}

	@Override
	@Transactional
	public void updateMessageToPreSend(Long transactionId) throws ServiceException {

		TransactionState transactionState = transactionStateDao.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionState);

		if (MessageState.ABNORMAL.code() != transactionState.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		// 操作日志
		OptLog log = new OptLog();
		log.setBeginState(transactionState.getMessageState());
		log.setEndState(MessageState.PRESEND.code());
		log.setOptionLog("presend");
		log.setOptionMethod("updateMessageToPreSend");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionId);
		log.setWorkerId(transactionState.getWorkerId());

		TransactionState updateTransactionState = new TransactionState();
		updateTransactionState.setMessageState(MessageState.PRESEND.code());
		updateTransactionState.setPresendBackThreshold(Thresholds.MAX_PRESENDBACK.code());
		updateTransactionState.setPresendBackNextSendTime(
				thresholdsTimeManage.createPreSendBackTime(Thresholds.MAX_PRESENDBACK.code()));
		updateTransactionState.setTransactionId(transactionId);
		updateTransactionState.setUpdateTime(new Date());

		transactionStateDao.update(updateTransactionState);
		// 操作信息
		tmmLogService.writeLog(log);
	}

	@Override
	@Transactional
	public void updateMessageToAbnormal(Long transactionId) throws ServiceException {

		TransactionState transactionState = transactionStateDao.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionState);

		if (MessageState.PRESEND.code() != transactionState.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		OptLog log = new OptLog();
		log.setBeginState(transactionState.getMessageState());
		log.setEndState(MessageState.ABNORMAL.code());
		log.setOptionLog("abnormal");
		log.setOptionMethod("updateMessageToAbnormal");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionId);
		log.setWorkerId(transactionState.getWorkerId());
		

		TransactionState updateTransactionState = new TransactionState();
		updateTransactionState.setMessageState(MessageState.ABNORMAL.code());
		updateTransactionState.setUpdateTime(new Date());
		updateTransactionState.setTransactionId(transactionId);

		transactionStateDao.update(updateTransactionState);
		// 操作信息
		tmmLogService.writeLog(log);
	}

	@Override
	@Transactional
	public void updateMessageToDied(Long transactionId) throws ServiceException {

		TransactionState transactionState = transactionStateDao.findByTransactionId(transactionId);

		Preconditions.checkNotNull(transactionState);

		if (MessageState.SEND.code() != transactionState.getMessageState()) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		OptLog log = new OptLog();
		log.setBeginState(transactionState.getMessageState());
		log.setEndState(MessageState.DIED.code());
		log.setOptionLog("died");
		log.setOptionMethod("updateMessageToDied");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionId);
		log.setWorkerId(transactionState.getWorkerId());

		TransactionState updateTransactionState = new TransactionState();
		updateTransactionState.setMessageState(MessageState.DIED.code());
		updateTransactionState.setTransactionId(transactionId);
		updateTransactionState.setUpdateTime(new Date());

		transactionStateDao.update(updateTransactionState);
		// 操作信息
		tmmLogService.writeLog(log);

	}

	@Override
	public Integer getMessageStateCount(Integer messageState) throws ServiceException {
		return transactionStateDao.messageStateCount(messageState);
	}

	@Override
	public List<TransactionState> queryTransactionMessageByState(Integer messageState) throws ServiceException {
		TransactionStateFilter filter = new TransactionStateFilter();
		filter.setMessageState(messageState);
		return transactionStateDao.findTransactionStateListByFilter(filter, new Limiter(0,100,
				"transaction_id DESC"));
	}

	@Override
	public List<OptLog> queryOptLogByTransactionId(Long messageId) throws ServiceException {
		return null;
	}

}
