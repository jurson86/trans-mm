package com.tuandai.transaction.domain.filter;

import java.util.List;

public class TransactionMessageFilter {

    private List<Long> transactionIds;

    public List<Long> getTransactionIds() {
        return transactionIds;
    }

    public void setTransactionIds(List<Long> transactionIds) {
        this.transactionIds = transactionIds;
    }


}
