package com.tuandai.transaction.service;

import com.tuandai.transaction.domain.OptLog;

public interface TmmLogService {
	
	void writeLog(OptLog log);
	
}
