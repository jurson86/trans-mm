package com.tuandai.transaction.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public final class OptLog  {

	private Long optId;

	private Long workerId;

	private Long transactionId;

	private Integer beginState;

	private Integer endState;

	private String optionLog;

	private String optionMethod;

	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date optionTime;

	public Long getOptId() {
		return optId;
	}

	public void setOptId(Long optId) {
		this.optId = optId;
	}

	public Long getWorkerId() {
		return workerId;
	}

	public void setWorkerId(Long workerId) {
		this.workerId = workerId;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Integer getBeginState() {
		return beginState;
	}

	public void setBeginState(Integer beginState) {
		this.beginState = beginState;
	}

	public Integer getEndState() {
		return endState;
	}

	public void setEndState(Integer endState) {
		this.endState = endState;
	}

	public String getOptionLog() {
		return optionLog;
	}

	public void setOptionLog(String optionLog) {
		this.optionLog = optionLog;
	}

	public String getOptionMethod() {
		return optionMethod;
	}

	public void setOptionMethod(String optionMethod) {
		this.optionMethod = optionMethod;
	}

	public Date getOptionTime() {
		return optionTime;
	}

	public void setOptionTime(Date optionTime) {
		this.optionTime = optionTime;
	}

	@Override
	public String toString() {
		return String.format(
				"{'transactionId':'%s', 'workerId':'%s', 'beginState':'%s', 'endState':'%s', 'optionLog':'%s', 'optionMethod':'%s', 'optionTime':'%s' }",
				transactionId, workerId, beginState, endState, optionLog, optionMethod, optionTime.toString());
	}

}