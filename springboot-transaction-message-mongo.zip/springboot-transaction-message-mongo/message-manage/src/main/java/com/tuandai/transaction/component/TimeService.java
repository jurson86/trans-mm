package com.tuandai.transaction.component;
public class TimeService {
    
    /**
     * Get current millis.
     * 
     * @return current millis
     */
    public long getCurrentMillis() {
        return System.currentTimeMillis();
    }
}