package com.tuandai.transaction.service.impl;

import java.util.Date;
import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.component.ThresholdsTimeManage;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;
import com.tuandai.transaction.domain.OptLog;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.model.constants.LocalTransactionState;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.model.constants.Thresholds;
import com.tuandai.transaction.model.request.MessageIdAck;
import com.tuandai.transaction.mq.MqSendHelper;
import com.tuandai.transaction.service.TmmLogService;
import com.tuandai.transaction.service.util.NomalProcessMessageServiceHelper;

@Service
public class AbnomalThreadCallService {

	@Resource
	private TransactionMessageDao transactionMessageDao;

	@Autowired
	private TransactionStateDao transactionStateDao;

	@Autowired
	private ThresholdsTimeManage thresholdsTimeManage;

	@Autowired
	private RestTemplate restTemplate;     // 负载均衡

	@Autowired
	private MqSendHelper mqSendHelper;
	
	@Autowired
	private TmmLogService tmmLogService;

	private static final Logger logger = LoggerFactory.getLogger(AbnomalThreadCallService.class);

	public Boolean presendCallback(TransactionState transactionState) {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("messageId", transactionState.getWorkerId() + Constants.MESSAGE_ID_SPLIT + transactionState.getTransactionId());

		try {
			ResponseEntity<String> response = restTemplate.exchange(transactionState.getPresendBackUrl(),
					HttpMethod.POST, new HttpEntity<HashMap<String, Object>>(httpbodyMap, Constants.header), String.class);

			logger.debug("PreSend Callback response: {} ", response.toString());

			if (response.getStatusCode().equals(HttpStatus.OK)) {
				JSONObject jo = JSONObject.parseObject(response.getBody());
				// 回调的时候需要提供消息的一些信息
				MessageIdAck ack = jo.getObject("messageIdAck", MessageIdAck.class);
				if (ack != null && ack.getState() != null) {
					if (LocalTransactionState.COMMIT_MESSAGE.equals(ack.getState())) { // 提交事务
						logger.debug("{} PreSend Callback success!", transactionState.getTransactionId());
						presendCallbackSuccess(transactionState, ack);
					} else { // 废弃事务
						logger.debug("{} PreSend Callback discard!", transactionState.getTransactionId());
						changeToDiscard(transactionState, ack);
					}
					return true;
				}
				logger.error("业务方未按要求实现需要的回调接口 [" + transactionState.getPresendBackUrl() + "]," +
						"[transactionId:" + transactionState.getTransactionId() + "]");
			}
		} catch (Exception e) {
			logger.error("PreSend Callback Exception : {}", e.getMessage());
		}

		logger.debug("{} PreSend Callback failed!", transactionState.getTransactionId());
		presendCallbackFailed(transactionState); // 回调异常
		return false;
	}

	private void presendCallbackSuccess(TransactionState transactionState, MessageIdAck ack) {
		// 操作信息
		OptLog log = new OptLog();
		log.setBeginState(transactionState.getMessageState());
		log.setEndState(MessageState.SEND.code());
		log.setOptionLog("Presend callback success!");
		log.setOptionMethod("presendCallbackSuccess");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionState.getTransactionId());
		log.setWorkerId(transactionState.getWorkerId());
		
		// 先查询消息是否已经被插入到message表中，如果已经存在则不需要再次插入
		TransactionMessage transactionMessage = transactionMessageDao.findByTransactionId(transactionState.getTransactionId());
		if (transactionMessage == null) {
			transactionMessage = NomalProcessMessageServiceHelper.messageState2MessageManage(transactionState, ack);
			// 插入汇总表
			transactionMessageDao.insert(transactionMessage);
		}

		Boolean isSend = false;
		try {
			// 消息发送
			mqSendHelper.sendTranTopicMsg(transactionMessage);
			
			log.setEndState(MessageState.DONE.code());
			log.setOptionLog("Presend callback success!");
			log.setOptionMethod("presendCallbackSuccess");
			// 发送成功，直接删除消息
			transactionStateDao.delete(transactionMessage.getTransactionId());
			isSend = true;
		} catch (Exception e) {
			logger.error("=================send exception============= {}", e.getMessage());
		}

		if (!isSend) { // 如果发送失败，则更新原来的记录
			TransactionState updateTransactionState = new TransactionState();
			updateTransactionState.setTransactionId(transactionState.getTransactionId());
			updateTransactionState.setUpdateTime(new Date());
			updateTransactionState.setMessageState(MessageState.SEND.code());

			updateTransactionState.setMessageSendThreshold(Thresholds.MAX_SEND.code());
			int sendTimes = transactionState.getMessageSendTimes() + 1;
			updateTransactionState.setMessageSendTimes(sendTimes);
			updateTransactionState.setMessageNextSendTime(thresholdsTimeManage.createSendNextTime(Thresholds.MAX_SEND.code()));
			transactionStateDao.update(updateTransactionState);
		}

		tmmLogService.writeLog(log);
	}

	private void presendCallbackFailed(TransactionState transactionState) {
		// 操作信息
		OptLog log = new OptLog();
		log.setBeginState(transactionState.getMessageState());
		log.setEndState(transactionState.getMessageState());
		log.setOptionLog("Presend callback failed!");
		log.setOptionMethod("presendCallbackFailed");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionState.getTransactionId());
		log.setWorkerId(transactionState.getWorkerId());

		TransactionState updateTransactionState = new TransactionState();
		updateTransactionState.setTransactionId(transactionState.getTransactionId());
		updateTransactionState.setUpdateTime(new Date());
		updateTransactionState.setPresendBackSendTimes(transactionState.getPresendBackSendTimes() + 1);

		int thresholdTmp = transactionState.getPresendBackThreshold();
		if (thresholdTmp <= 0) {
			// 异常
			updateTransactionState.setMessageState(MessageState.ABNORMAL.code());
			log.setEndState(MessageState.ABNORMAL.code());
		} else {
			updateTransactionState.setPresendBackNextSendTime(thresholdsTimeManage.createPreSendBackTime(thresholdTmp));
			updateTransactionState.setPresendBackThreshold(thresholdTmp - 1);
		}
		transactionStateDao.update(updateTransactionState);
		tmmLogService.writeLog(log);
	}

	private void changeToDiscard(TransactionState transactionState, MessageIdAck ack) {
		// 操作信息
		OptLog log = new OptLog();
		log.setBeginState(transactionState.getMessageState());
		log.setEndState(MessageState.DISCARD.code());
		log.setOptionLog("Change to discard!");
		log.setOptionMethod("changeToDiscard");
		log.setOptionTime(new Date());
		log.setTransactionId(transactionState.getTransactionId());
		log.setWorkerId(transactionState.getWorkerId());
		
		// 先查询消息是否已经被插入到message表中，如果已经存在则不需要再次插入
		TransactionMessage transactionMessage = transactionMessageDao.findByTransactionId(transactionState.getTransactionId());
		if (transactionMessage == null) {
			transactionMessage = NomalProcessMessageServiceHelper.messageState2MessageManage(transactionState, ack);
			// 插入汇总表
			transactionMessageDao.insert(transactionMessage);
		}
		// 删除废弃消息
		transactionStateDao.delete(transactionState.getTransactionId());
		tmmLogService.writeLog(log);
	}

}
