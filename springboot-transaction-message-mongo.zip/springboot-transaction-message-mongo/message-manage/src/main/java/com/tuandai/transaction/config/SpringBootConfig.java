package com.tuandai.transaction.config;

import com.tuandai.transaction.model.constants.MqType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.netflix.config.ConfigurationManager;

@Component
public class SpringBootConfig implements InitializingBean {
	private static final Logger logger = LoggerFactory.getLogger(SpringBootConfig.class);

	@Value("${presend.back.thresholds}")
	String preSendBackThresholdstr;

	@Value("${result.back.thresholds}")
	String resultBackThresholdstr;

	@Value("${send.thresholds}")
	String sendThresholdstr;

	@Value("${HystrixTimeoutTransactionMessageRepositoryCmd:100}")
	int hystrixTimeoutTransactionMessageRepositoryCmd;

	@Value("${CoreSizeTransactionMessageRepositoryPool:100}")
	int coreSizeTransactionMessageRepositoryPool;

	@Value("${mq.type}")
	String myType;

	public static MqType getMqType() {
		return MqType.findByDes(_myType);
	}

	public String getPreSendBackThresholdstr() {	
		return preSendBackThresholdstr;
	}


	public String getResultBackThresholdstr() {
		return resultBackThresholdstr;
	}

	public String getSendThresholdstr() {
		return sendThresholdstr;
	}
	
	//断路器配置
	public void initalNetflixConfig()
	{
		// fallback make default to 200
		ConfigurationManager.getConfigInstance().setProperty("hystrix.command.default.fallback.isolation.semaphore.maxConcurrentRequests", 200);
		
		logger.debug("========= hystrixTimeoutTransactionMessageRepositoryCmd =========: {}",hystrixTimeoutTransactionMessageRepositoryCmd);
	    ConfigurationManager.getConfigInstance().setProperty("hystrix.command.TransactionMessageRepositoryCmd.execution.isolation.thread.timeoutInMilliseconds", hystrixTimeoutTransactionMessageRepositoryCmd);

		logger.debug("========= coreSizeTransactionMessageRepositoryPool =========: {}",coreSizeTransactionMessageRepositoryPool);
	    ConfigurationManager.getConfigInstance().setProperty("hystrix.threadpool.TransactionMessageRepositoryPool.coreSize", coreSizeTransactionMessageRepositoryPool);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		_myType = myType;
	}

	static String  _myType;
}
