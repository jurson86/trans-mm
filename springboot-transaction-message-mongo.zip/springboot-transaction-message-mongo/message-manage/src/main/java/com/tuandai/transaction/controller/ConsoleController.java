package com.tuandai.transaction.controller;

import java.util.List;
import java.util.regex.Pattern;

import com.tuandai.transaction.domain.OptLog;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.constant.BZStatusCode;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.service.AbnomalProcessMessageService;
import com.tuandai.transaction.service.NomalProcessMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.util.Result;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
public class ConsoleController {

	private static final Logger logger = LoggerFactory.getLogger(ConsoleController.class);

	@Autowired
	NomalProcessMessageService nomalProcessMessageService;

	@Autowired
	AbnomalProcessMessageService abnomalProcessMessageService;



	@ApiOperation(value = "各状态消息数查询", notes = "各状态每秒消息数监控")
	@ApiImplicitParam(name = "state", value = "消息状态", paramType = "path", required = true, dataType = "int")
	@RequestMapping(value = "/message/monitor/{state}", method = RequestMethod.POST)
	public ResponseEntity<Result<Integer>> messageStateCount(@PathVariable int state) {

		logger.debug("messageStateCount  state: {}", state);

		Integer counts = nomalProcessMessageService.getMessageStateCount(state);

		return new ResponseEntity<Result<Integer>>(new Result<Integer>(counts), HttpStatus.OK);
	}

	@ApiOperation(value = "消息列表查询", notes = "按照消息状态查询消息列表")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "state", value = "消息状态", paramType = "path", required = true, dataType = "int") })
	@RequestMapping(value = "/message/query/{state}", method = RequestMethod.POST)
	public Object queryMessageListByState(@PathVariable int state) {

		logger.debug("queryMessageListByState: {} ", state);

		List<TransactionState> pts = nomalProcessMessageService.queryTransactionMessageByState(state);

		return new ResponseEntity<Result<List<TransactionState>>>(new Result<List<TransactionState>>(pts),
				HttpStatus.OK);
	}

	@ApiOperation(value = "消息详情查询", notes = "按照消息ID查询消息详情")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "id", value = "消息ID", paramType = "path", required = true, dataType = "string") })
	@RequestMapping(value = "/message/get/{id}", method = RequestMethod.POST)
	public Object queryMessageByTransactionId(@PathVariable String id) {

		logger.debug("queryMessageByTransactionId: {} ", id);

		TransactionMessage tm = nomalProcessMessageService.getTransactionMessageById(Long.valueOf(id));

		return new ResponseEntity<Result<TransactionMessage>>(new Result<TransactionMessage>(tm),
				HttpStatus.OK);
	}

	@ApiOperation(value = "消息中间状态查询", notes = "按照消息ID查询消息中间状态信息")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "id", value = "消息ID", paramType = "path", required = true, dataType = "string") })
	@RequestMapping(value = "/state/get/{id}", method = RequestMethod.POST)
	public Object queryMessageStateByTransactionId(@PathVariable String id) {

		logger.debug("queryMessageStateByTransactionId: {} ", id);

		TransactionState tm = nomalProcessMessageService.getTransactionStateById(Long.valueOf(id));

		return new ResponseEntity<Result<TransactionState>>(new Result<TransactionState>(tm),
				HttpStatus.OK);
	}


	@ApiOperation(value = "人工干预-异常消息", notes = "人工干预-异常消息【预发送、废弃】")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "transactionIds", value = "事务消息ID集【id1,id2,id3,...】", paramType = "body", required = true, dataType = "string"),
			@ApiImplicitParam(name = "state", value = "确认状态", paramType = "path", required = true, dataType = "int") })
	@RequestMapping(value = "/message/change/abnormal/{state}", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> changeAbnormal(@RequestBody String transactionIds, @PathVariable int state) {
		if (transactionIds.isEmpty() || !Pattern.matches("[0-9,-]+$", transactionIds)) {
			logger.error("invalid  parameter, messageIds: {}", transactionIds);
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}

		logger.debug("changeAbnormal: {} , {}", transactionIds, state);

		String[] idArray = transactionIds.split(",");
		StringBuilder sb = new StringBuilder();
		for (String id : idArray) {
			try {
				if (state == MessageState.PRESEND.code()) {
					nomalProcessMessageService.updateMessageToPreSend(Long.valueOf(id));
				} else if (state == MessageState.DISCARD.code()) {
					nomalProcessMessageService.updateMessageToDiscard(Long.valueOf(id), null);
				} else {
					sb.append(",");
					sb.append(id);
				}
			} catch (RuntimeException e) {
				logger.error("changeAbnormal: id = {} , err = {}", id, e.getMessage());
				sb.append(",");
				sb.append(id);
			}
		}

		return new ResponseEntity<Result<String>>(new Result<String>(sb.toString()), HttpStatus.OK);
	}

	@ApiOperation(value = "人工干预-死亡消息", notes = "人工干预-死亡消息【发送、废弃】")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "transactionIds", value = "消息ID集【id1,id2,id3,...】", paramType = "body", required = true, dataType = "string"),
			@ApiImplicitParam(name = "state", value = "确认状态", paramType = "path", required = true, dataType = "int") })
	@RequestMapping(value = "/message/change/died/{state}", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> changeDied(@RequestBody String transactionIds, @PathVariable int state) {
		if (transactionIds.isEmpty() || !Pattern.matches("[0-9,-]+$", transactionIds)) {
			logger.error("invalid  parameter, messageIds: {}", transactionIds);
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}

		logger.debug("changeDied: {} , {}", transactionIds, state);

		String[] idArray = transactionIds.split(",");
		StringBuilder sb = new StringBuilder();
		for (String id : idArray) {
			try {
				if (state == MessageState.SEND.code()) {
					nomalProcessMessageService.updateMessageToSend(Long.valueOf(id), null);
				} else if (state == MessageState.DISCARD.code()) {
					nomalProcessMessageService.updateMessageToDiscard(Long.valueOf(id), null);
				} else {
					sb.append(",");
					sb.append(id);
				}

			} catch (RuntimeException e) {
				logger.error("changeDied: id = {} , err = {}", id, e.getMessage());
				sb.append(",");
				sb.append(id);
			}
		}

		return new ResponseEntity<Result<String>>(new Result<String>(sb.toString()), HttpStatus.OK);
	}

	@ApiOperation(value = "消息重发", notes = "按照消息ID重发")
	@ApiImplicitParam(name = "transactionIds", value = "消息ID集【id1,id2,id3,...】", paramType = "body", required = true, dataType = "string")
	@RequestMapping(value = "/message/resend", method = RequestMethod.POST)
	public Object messageResend(@RequestBody String transactionIds) {
		if (transactionIds.isEmpty() || !Pattern.matches("[0-9,-]+$", transactionIds)) {
			logger.error("invalid  parameter, messageIds: {}", transactionIds);
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}

		logger.debug("messageResend: {} ", transactionIds);

		String[] idArray = transactionIds.split(",");
		StringBuilder sb = new StringBuilder();
		for (String id : idArray) {
			try {
				abnomalProcessMessageService.resendMessageByTransactionId(Long.valueOf(id));
			} catch (RuntimeException e) {
				logger.error("Resend err: id = {} , err = {}", id, e.getMessage());
				sb.append(",");
				sb.append(id);
			}
		}

		return new ResponseEntity<Result<String>>(new Result<String>(sb.toString()), HttpStatus.OK);
	}



	@ApiOperation(value = "消息废弃", notes = "按照消息ID废弃")
	@ApiImplicitParam(name = "transactionIds", value = "消息ID集【id1,id2,id3,...】", paramType = "body", required = true, dataType = "string")
	@RequestMapping(value = "/message/discard", method = RequestMethod.POST)
	public Object messageToDiscard(@RequestBody String transactionIds) {
		if (transactionIds.isEmpty() || !Pattern.matches("[0-9,-]+$", transactionIds)) {
			logger.error("invalid  parameter, messageIds: {}", transactionIds);
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}

		logger.debug("messageResend: {} ", transactionIds);

		String[] idArray = transactionIds.split(",");
		StringBuilder sb = new StringBuilder();
		for (String id : idArray) {
			try {
				nomalProcessMessageService.updateMessageToDiscard(Long.valueOf(id), null);
			} catch (RuntimeException e) {
				logger.error("Discard err: id = {} , err = {}", id, e.getMessage());
				sb.append(",");
				sb.append(id);
			}
		}

		return new ResponseEntity<Result<String>>(new Result<String>(sb.toString()), HttpStatus.OK);
	}

	@ApiOperation(value = "操作日志", notes = "按照消息ID查询消息的操作日志")
	@ApiImplicitParam(name = "transactionId", value = "消息ID", paramType = "path", required = true, dataType = "string")
	@RequestMapping(value = "/message/optlog/{transactionId}", method = RequestMethod.POST)
	public Object queryOptLogByTransactionId(@PathVariable String transactionId) {

		logger.debug("messageToDiscard, transactionId{}", transactionId);
		if (StringUtils.isEmpty(transactionId)) {
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}

		List<OptLog> optList = nomalProcessMessageService.queryOptLogByTransactionId(Long.valueOf(transactionId));
		return new ResponseEntity<Result<List<OptLog>>>(new Result<List<OptLog>>(optList), HttpStatus.OK);
	}

}