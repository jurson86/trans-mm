package com.tuandai.transaction.repository;

import java.util.List;

import com.tuandai.transaction.domain.filter.Limiter;
import com.tuandai.transaction.domain.filter.TransactionMessageFilter;
import com.tuandai.transaction.domain.TransactionMessage;
import org.apache.ibatis.annotations.Mapper;

import org.apache.ibatis.annotations.Param;

@Mapper
public interface TransactionMessageRepository {

	void createIfNotExistsTable();

	void truncateTable();

	void delete(Long transactionId);

	void dropTable();

	void insert(TransactionMessage transactionMessage);

	List<TransactionMessage> findTransactionMessageListByFilter(@Param("filter") TransactionMessageFilter filter,
																@Param("limiter") Limiter limiter);

	Integer messageStateCount(Integer messageState);

}
