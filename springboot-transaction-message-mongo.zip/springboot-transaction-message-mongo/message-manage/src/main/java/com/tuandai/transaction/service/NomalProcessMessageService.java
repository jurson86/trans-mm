package com.tuandai.transaction.service;

import java.util.List;

import com.tuandai.transaction.domain.OptLog;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.request.MessageIdAck;
import com.tuandai.transaction.model.request.MessageIdCreator;

public interface NomalProcessMessageService {

	/**
	 * 创建消息
	 */
	Long createMessage(MessageIdCreator messageIdCreator);

	/**
	 * 更新消息为预发送状态
	 */
	void updateMessageToPreSend(Long messageId) throws ServiceException;


	/**
	 * 更新消息为发送状态
	 */
	void updateMessageToSend(Long messageId, MessageIdAck messageIdAck);



	/**
	 * 更新消息为异常状态
	 */
	void updateMessageToAbnormal(Long messageId) throws ServiceException;


	/**
	 * 更新消息为死亡状态
	 */
	void updateMessageToDied(Long messageId) throws ServiceException;


	/**
	 * 更新消息为废弃状态
	 */
	void updateMessageToDiscard(Long messageId, MessageIdAck messageIdAck);


	/**
	 * 根据ID获取消息信息
	 */
	TransactionMessage  getTransactionMessageById(Long messageId) throws ServiceException;

	/**
	 * 根据ID获取消息状态信息
	 */
	TransactionState getTransactionStateById(Long messageId) throws ServiceException;


	/**
	 * 查询各状态当前消息数
	 */
	Integer getMessageStateCount(Integer messageState) throws ServiceException;


	/**
	 * 根据状态获取消息列表
	 */
	List<TransactionState>  queryTransactionMessageByState(Integer messageState) throws ServiceException;


	/**
	 * 根据消息id查询消息的操作列表
	 */
	List<OptLog> queryOptLogByTransactionId(Long messageId) throws ServiceException;
}
