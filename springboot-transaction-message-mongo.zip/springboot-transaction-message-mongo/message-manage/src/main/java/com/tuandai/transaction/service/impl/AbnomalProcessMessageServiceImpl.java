package com.tuandai.transaction.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.common.base.Preconditions;
import com.tuandai.transaction.component.ThreadPoolExecutorUtils;
import com.tuandai.transaction.component.ThresholdsTimeManage;
import com.tuandai.transaction.constant.BZStatusCode;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;
import com.tuandai.transaction.domain.OptLog;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.domain.filter.Limiter;
import com.tuandai.transaction.domain.filter.TransactionStateFilter;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.mq.MqSendHelper;
import com.tuandai.transaction.service.AbnomalProcessMessageService;
import com.tuandai.transaction.service.TmmLogService;

@Service
public class AbnomalProcessMessageServiceImpl implements AbnomalProcessMessageService {

	private static final Logger logger = LoggerFactory.getLogger(AbnomalProcessMessageServiceImpl.class);

	@Resource
	private TransactionMessageDao transactionMessageDao;

	@Autowired
	private TransactionStateDao transactionStateDao;

	@Autowired
	private TmmLogService tmmLogService;

	@Autowired
	private ThresholdsTimeManage thresholdsTimeManage;

	@Autowired
	private AbnomalThreadCallService abnomalThreadCallService;

	@Autowired
	private MqSendHelper mqSendHelper;

	private static Date PRESEND_CALLBACK_BYTASK_TIME = null;

	/**
	 * 预发送回调确认
	 */
	@Override
	public void preSendCallbackByTask() throws ServiceException {

		// 任务执行中不可重复调用
		if (isPreSendCallbackRuning()) { // TODO 采用分布式锁的方式来控制任务
			return;
		}
		Calendar calendar = Calendar.getInstance();

		TransactionStateFilter filter = new TransactionStateFilter();
		filter.setMessageState(MessageState.PRESEND.code());
		filter.setEndPresendBackNextSendTime(calendar.getTime());
		// TODO 采用分段锁的思想来取数据库里面的数据
		List<TransactionState> transactionStateList = transactionStateDao.
				findTransactionStateListByFilter(filter, new Limiter(0, 1000, "transaction_id ASC"));

		// 操作数据，直接返回
		if (CollectionUtils.isEmpty(transactionStateList)) {
			logger.debug("PresendCallback list is null....");
			return;
		}

		logger.debug("PresendCallback running....");
		ExecutorService taskPoll = ThreadPoolExecutorUtils.getTaskThreadPoolExecutorUtils();
		ExecutorService resultPoll = ThreadPoolExecutorUtils.getTaskThreadPoolExecutorUtils();

		List<Future<Boolean>> futureList = new ArrayList<>();
		for (TransactionState transactionState : transactionStateList) {
			Future<Boolean> future = taskPoll.submit(() -> abnomalThreadCallService.presendCallback(transactionState));
			futureList.add(future);
		}

		for (Future<Boolean> future : futureList) {
			resultPoll.execute(() -> {
				try {
					// 设置超时
					future.get(Constants.RESTFUL_MAX_TIMEOUT_SECONDS, TimeUnit.SECONDS);
				} catch (InterruptedException e) {
					logger.error("PresendCallback 任务异常中止 : {}", e.getMessage());
				} catch (ExecutionException e) {
					logger.error("PresendCallback 计算出现异常: {}", e.getMessage());
				} catch (TimeoutException e) {
					logger.error("PresendCallback 超时异常: {}", e.getMessage());
					// 超时后取消任务
					future.cancel(true);
				}
			});
		}
	}

	//TODO 此方法太长，需要优化
	@Override
	public void sendToMQByTask() throws ServiceException {
		Calendar calendar = Calendar.getInstance();

		TransactionStateFilter filter = new TransactionStateFilter();
		filter.setEndMessageNextSendTime(calendar.getTime());
		filter.setMessageState(MessageState.SEND.code());
		List<TransactionState> transactionStateList = transactionStateDao.findTransactionStateListByFilter(filter,
				new Limiter(0, 1000, "transaction_id ASC"));

		// 操作数据，直接返回
		if (CollectionUtils.isEmpty(transactionStateList)) {
			logger.debug("sendToMQByTask list is null....");
			return;
		}

		logger.debug("sendToMQByTask running....");

		// 批量查询消息汇总表
		Map<Long, TransactionMessage> messageMap = transactionMessageDao.findByTransactionMessageMapByIds(
				transactionStateList.stream().map(o -> o.getTransactionId()).collect(Collectors.toList()));

		List<Long> deletedIds = new ArrayList<>();

		ExecutorService poll = ThreadPoolExecutorUtils.getTaskThreadPoolExecutorUtils();

		// 线程安全存储mq的发送状态
		final ConcurrentHashMap<Long, Boolean> isSendMap = new ConcurrentHashMap<>();
		final CountDownLatch latch = new CountDownLatch(transactionStateList.size());

		for (TransactionState transactionState : transactionStateList) {
			poll.execute(() -> {
				TransactionMessage message = messageMap.get(transactionState.getTransactionId());
				Boolean isSend = isSendRocketMQ(message);
				isSendMap.put(transactionState.getTransactionId(), isSend);
				latch.countDown();
			});
		}

		try {
			// 这里必须等待所有的mq都执行完才能执行下面的批量插入数据库操作，和上面preSendCallbackByTask()的场景不一样，
			// preSendCallbackByTask是不必等待所有的任务都执行完成，所以不需要用countDownLatch
			latch.await(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			logger.error("=================countDownLatch exception============= {}", e.getMessage());
		}

		for (TransactionState transactionState : transactionStateList) {
			Boolean isSend = isSendMap.get(transactionState.getTransactionId());
			if (isSend != null && isSend) { // 发送成功
				OptLog log = new OptLog();
				log.setBeginState(transactionState.getMessageState());
				log.setEndState(MessageState.DONE.code());
				log.setOptionLog("done");
				log.setOptionMethod("sendToMQByTask");
				log.setOptionTime(new Date());
				log.setTransactionId(transactionState.getTransactionId());
				log.setWorkerId(transactionState.getWorkerId());
				// 删除中间状态
				deletedIds.add(transactionState.getTransactionId());
				// 操作信息
				tmmLogService.writeLog(log);
			} else { // 发送异常

				int timesTmp = transactionState.getMessageSendTimes();
				int thresholdTmp = transactionState.getMessageSendThreshold();

				TransactionState updateTransactionState = new TransactionState();
				updateTransactionState.setMessageSendTimes(timesTmp + 1);
				updateTransactionState.setUpdateTime(new Date());
				updateTransactionState.setTransactionId(transactionState.getTransactionId());

				if (thresholdTmp <= 0) {
					OptLog log = new OptLog();
					log.setBeginState(transactionState.getMessageState());
					log.setEndState(MessageState.DIED.code());
					log.setOptionLog("SendToMQ  Died");
					log.setOptionMethod("sendToMQByTask");
					log.setOptionTime(new Date());
					log.setTransactionId(transactionState.getTransactionId());
					log.setWorkerId(transactionState.getWorkerId());
					
					updateTransactionState.setMessageState(MessageState.DIED.code());
					// 一直发送失败，消息死亡
					transactionStateDao.update(updateTransactionState);
					// 操作信息
					tmmLogService.writeLog(log);
				} else {
					OptLog log = new OptLog();
					log.setBeginState(transactionState.getMessageState());
					log.setEndState(transactionState.getMessageState());
					log.setOptionLog("SendToMQ  ...");
					log.setOptionMethod("sendToMQByTask");
					log.setOptionTime(new Date());
					log.setTransactionId(transactionState.getTransactionId());
					log.setWorkerId(transactionState.getWorkerId());
					
					updateTransactionState.setMessageNextSendTime(thresholdsTimeManage.createSendNextTime(thresholdTmp));
					updateTransactionState.setMessageSendThreshold(thresholdTmp - 1);
					// 阈值内发送死亡则配置下次重试的时间
					transactionStateDao.update(updateTransactionState);
					// 操作信息
					tmmLogService.writeLog(log);
				}
			}
		}

		// 批量删除消息
		transactionStateDao.deleteBatch(deletedIds);

		// 批量更新 TODO 待优化...

	}

	private Boolean isSendRocketMQ(TransactionMessage message) {
		Boolean isSend = false;
		if (message != null) {
			try {
				mqSendHelper.sendTranTopicMsg(message);
				//rocketMQHelper.sendTranTopicMsg(message);
				isSend = true;
			} catch (Exception e) {
				logger.error("=================send exception============= {}", e.getMessage());
			}
		}
		return isSend;
	}

	private boolean isPreSendCallbackRuning() {
		if (null == PRESEND_CALLBACK_BYTASK_TIME) {
			PRESEND_CALLBACK_BYTASK_TIME = new Date();
			return false;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.SECOND, -1 * (Constants.RESTFUL_MAX_TIMEOUT_SECONDS + 2));
		if (calendar.getTime().before(PRESEND_CALLBACK_BYTASK_TIME)) {
			logger.debug("PresendCallback 正在执行中，任务不可重复调用 ......!");
			return true;
		}
		return false;
	}

	@Override
	public void resendMessageByTransactionId(Long transactionId) throws ServiceException {

		TransactionState transactionState = transactionStateDao.findByTransactionId(transactionId);
		// Preconditions.checkNotNull(transactionState);

		TransactionMessage transactionMessage = transactionMessageDao.findByTransactionId(transactionId);
		Preconditions.checkNotNull(transactionMessage);

		if (transactionState != null && (MessageState.PRESEND.code() == transactionState.getMessageState()
				|| MessageState.DISCARD.code() == transactionState.getMessageState())) {
			throw new ServiceException(BZStatusCode.INVALID_STATE_OPTION);
		}

		try {
			// 消息发送
			mqSendHelper.sendTranTopicMsg(transactionMessage);
		} catch (Exception e) {
			logger.error("=================send exception============= {}", e.getMessage());
			throw new ServiceException(BZStatusCode.SERVER_UNKNOWN_ERROR);
		}
	}

}
