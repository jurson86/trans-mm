package com.tuandai.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ApplicationContext;

import com.tuandai.transaction.component.InitailDBTables;
import com.tuandai.transaction.config.SpringBootConfig;
import com.tuandai.transaction.constant.Constants;

@EnableCircuitBreaker
@SpringBootApplication
@EnableEurekaClient
@EnableDiscoveryClient
public class TransactionApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(TransactionApplication.class, args);
		//设置 DefaultKeyGenerator WorkerId  消息ID偏移量  路由键 ；
		if (0 == args.length) {
			//DefineKeyGenerator.initPropertiesWorkerId("1");
			Constants.setRouteKey(1L);
		} else {
			//DefineKeyGenerator.initPropertiesWorkerId(args[0]);
			Constants.setRouteKey(Long.valueOf(args[0]));
		}
		//初始化数据库表
		applicationContext.getBean(InitailDBTables.class).createTables();		
		//初始化配置
		applicationContext.getBean(SpringBootConfig.class).initalNetflixConfig();
	}

}
