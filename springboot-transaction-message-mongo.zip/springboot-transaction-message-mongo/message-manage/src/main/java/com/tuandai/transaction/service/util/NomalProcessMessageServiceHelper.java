package com.tuandai.transaction.service.util;

import com.tuandai.transaction.constant.BZStatusCode;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.model.constants.Thresholds;
import com.tuandai.transaction.model.request.MessageIdAck;
import com.tuandai.transaction.model.request.MessageIdCreator;
import org.springframework.http.HttpMethod;

import java.util.Date;

public class NomalProcessMessageServiceHelper {

    public static TransactionState messageIdCreator2TransactionState(MessageIdCreator mc, Long workerId) {
        Date date = new Date();
        TransactionState transactionState = new TransactionState();
        transactionState.setWorkerId(workerId);
        transactionState.setServiceName(mc.getServiceName());
        transactionState.setCreateTime(date);
        transactionState.setUpdateTime(date);
        transactionState.setMessageState(MessageState.PRESEND.code());
        transactionState.setMessageSendThreshold(Thresholds.MAX_SEND.code());
        transactionState.setMessageSendTimes(0);
        transactionState.setMessageNextSendTime(date);
        transactionState.setPresendBackUrl(mc.getPresendBackUrl());
        transactionState.setPresendBackMethod(HttpMethod.POST.toString());
        transactionState.setPresendBackThreshold(Thresholds.MAX_PRESENDBACK.code());
        transactionState.setPresendBackSendTimes(0);
        return transactionState;
    }

    public static TransactionMessage messageState2MessageManage(TransactionState transactionState,
                                                                MessageIdAck messageIdAck) {
        Date time = new Date();
        TransactionMessage transactionMessage = new TransactionMessage();
        transactionMessage.setServiceName(transactionState.getServiceName());
        transactionMessage.setWorkerId(transactionState.getWorkerId());
        transactionMessage.setTransactionId(transactionState.getTransactionId());
        transactionMessage.setPresendBackUrl(transactionState.getPresendBackUrl());
        transactionMessage.setMessage(messageIdAck.getMessage());
        transactionMessage.setMessageType(messageIdAck.getMessageType());
        transactionMessage.setMessageTopic(messageIdAck.getMessageTopic());
        transactionMessage.setCreateTime(time);
        transactionMessage.setUpdateTime(time);
        return transactionMessage;
    }

    public static TransactionMessage buildTransactionMessage(MessageIdAck messageIdAck) {

		String[] msgid = messageIdAck.getMessageId().split(Constants.MESSAGE_ID_SPLIT);
		if(2 != msgid.length){
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}

		Long workerId = Long.valueOf(msgid[0]);
		Long transactionId = Long.valueOf(msgid[1]);
		
        TransactionMessage transactionMessage = new TransactionMessage();
        transactionMessage.setWorkerId(workerId);
        transactionMessage.setTransactionId(transactionId);
        transactionMessage.setMessageTopic(messageIdAck.getMessageTopic());
        transactionMessage.setMessage(messageIdAck.getMessage());
        transactionMessage.setMessageType(messageIdAck.getMessageType());
        return transactionMessage;
    }

    public static TransactionState buildUpdateTransactionState(TransactionState transactionState, MessageIdAck messageIdAck,
                                                               Date sendNextTime) {
        TransactionState updateTransactionState = new TransactionState();
        updateTransactionState.setUpdateTime(new Date());
        updateTransactionState.setTransactionId(transactionState.getTransactionId());
        updateTransactionState.setMessageState(MessageState.SEND.code());
        updateTransactionState.setMessageSendThreshold(Thresholds.MAX_SEND.code());
        updateTransactionState.setMessageSendTimes(transactionState.getMessageSendTimes() + 1);
        updateTransactionState.setMessageNextSendTime(sendNextTime);
        updateTransactionState.setMessageTopic(messageIdAck == null ? transactionState.getMessageTopic() :
                messageIdAck.getMessageTopic());
        return updateTransactionState;
    }

}
