package com.tuandai.transaction.domain.filter;

import java.util.Date;
import java.util.List;

public class TransactionStateFilter {

    private List<Long> transactionIds;

    private Integer messageState;

    private Date endPresendBackNextSendTime;

    private Date endMessageNextSendTime;

    public Date getEndMessageNextSendTime() {
        return endMessageNextSendTime;
    }

    public List<Long> getTransactionIds() {
        return transactionIds;
    }

    public void setTransactionIds(List<Long> transactionIds) {
        this.transactionIds = transactionIds;
    }

    public void setEndMessageNextSendTime(Date endMessageNextSendTime) {
        this.endMessageNextSendTime = endMessageNextSendTime;
    }

    public Date getEndPresendBackNextSendTime() {
        return endPresendBackNextSendTime;
    }

    public void setEndPresendBackNextSendTime(Date endPresendBackNextSendTime) {
        this.endPresendBackNextSendTime = endPresendBackNextSendTime;
    }

    public Integer getMessageState() {
        return messageState;
    }

    public void setMessageState(Integer messageState) {
        this.messageState = messageState;
    }
}
