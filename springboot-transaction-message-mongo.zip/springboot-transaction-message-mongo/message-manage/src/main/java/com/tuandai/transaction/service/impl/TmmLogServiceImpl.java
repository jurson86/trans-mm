package com.tuandai.transaction.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.tuandai.transaction.domain.OptLog;
import com.tuandai.transaction.service.TmmLogService;

@Service
public class TmmLogServiceImpl implements TmmLogService {

	private static final Logger logger = LoggerFactory.getLogger(TmmLogServiceImpl.class);

	@Override
	public void writeLog(OptLog log) {
		logger.info("TMMLOG: " + log.toString());
	}

}
