package com.tuandai.transaction.mq.inf;

import com.tuandai.transaction.domain.TransactionMessage;

/**
 * Mq相关的服务
 */
public interface MqService {

    void sendMessage(TransactionMessage transactionMessage);

}
