package com.tuandai.transaction.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Preconditions;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.tuandai.transaction.constant.BZStatusCode;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.LocalTransactionState;
import com.tuandai.transaction.model.request.MessageIdAck;
import com.tuandai.transaction.model.request.MessageIdCreator;
import com.tuandai.transaction.service.NomalProcessMessageService;
import com.tuandai.transaction.util.Result;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@RestController
public class NomalController {

	private static final Logger logger = LoggerFactory.getLogger(NomalController.class);

	@Autowired
	private NomalProcessMessageService preSendMessageService;

	@HystrixCommand(commandKey = "TransactionMessageRepositoryCmd", fallbackMethod = "createMessageFallback",
			threadPoolKey = "TransactionMessageRepositoryPool")
	@ApiOperation(value = "消息ID获取", notes = "消息ID获取")
	@ApiImplicitParam(name = "messageIdCreator", value = "创建消息ID基础信息", paramType = "body", required = true, dataType = "MessageIdCreator")
	@RequestMapping(value = "/message/creator", method = RequestMethod.POST)
	public ResponseEntity<Result<JSONObject>> createMessage(@Valid @RequestBody MessageIdCreator messageIdCreator) {
		Preconditions.checkNotNull(messageIdCreator);
		
		long transactionId = preSendMessageService.createMessage(messageIdCreator);

		JSONObject jo = new JSONObject();
		jo.put("messageId", Constants.getRouteKey() + Constants.MESSAGE_ID_SPLIT + transactionId);
		jo.put("routeKey", Constants.getRouteKey());
		return new ResponseEntity<Result<JSONObject>>(new Result<JSONObject>(jo), HttpStatus.OK);
	}

	public ResponseEntity<Result<JSONObject>> createMessageFallback(@Valid @RequestBody MessageIdCreator messageIdCreator) {
		logger.error("[fallback] Create Message fallback !");
		return new ResponseEntity<Result<JSONObject>>(new Result<JSONObject>(null), HttpStatus.METHOD_NOT_ALLOWED);
	}
	

	@HystrixCommand(commandKey = "TransactionMessageRepositoryCmd", fallbackMethod = "putMessageToSendFallback",
			threadPoolKey = "TransactionMessageRepositoryPool")
	@ApiOperation(value = "预发送消息确认发送状态", notes = "预发送消息确认发送状态【发送、废弃】")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "routeKey", value = "路由键", paramType = "path", required = true, dataType = "Long"),
			@ApiImplicitParam(name = "messageIdAck", value = "消息", paramType = "body", required = true, dataType = "MessageIdAck") })
	@RequestMapping(value = "/message/send/{routeKey}", method = RequestMethod.POST)
	public ResponseEntity<Result<String>> putMessageToSend(@PathVariable Long routeKey,@Valid @RequestBody MessageIdAck messageIdAck) {
		long time = System.currentTimeMillis();
		logger.debug("messageidSend: {} , {}", messageIdAck.getMessageId(),messageIdAck.getMessage());
		
		String[] msgid = messageIdAck.getMessageId().split(Constants.MESSAGE_ID_SPLIT);
		if(2 != msgid.length){
			logger.error("putMessageToSend invalid message id: {}",messageIdAck.getMessageId());
			throw new ServiceException(BZStatusCode.INVALID_MODEL_FIELDS);
		}
		
		Long transactionId = Long.valueOf(msgid[1]);

		if (LocalTransactionState.COMMIT_MESSAGE.equals(messageIdAck.getState())) {
			preSendMessageService.updateMessageToSend(transactionId, messageIdAck);
		} else {
			preSendMessageService.updateMessageToDiscard(transactionId, messageIdAck);
		}
		logger.debug("putMessageToSend NoSharding, time:[" + (System.currentTimeMillis() - time) + "ms]");
		return new ResponseEntity<Result<String>>(new Result<String>(""), HttpStatus.OK);
	}

	public ResponseEntity<Result<String>> putMessageToSendFallback(@PathVariable Long routeKey,@Valid @RequestBody MessageIdAck messageIdAck) {

		logger.error("[fallback] Put message to send fallback ============= {} ",  messageIdAck.getMessageId());
		return new ResponseEntity<Result<String>>(new Result<String>("{}"), HttpStatus.METHOD_NOT_ALLOWED);
	}

}