package com.tuandai.transaction.repository;

import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.domain.filter.Limiter;
import com.tuandai.transaction.domain.filter.TransactionStateFilter;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TransactionStateRepository {

    void createIfNotExistsTable();

    void insertBatch(List<TransactionState> transactionStates);

    void truncateTable();

    void deleteBatch(List<Long> transactionIds);

    void dropTable();

    void update(TransactionState transactionState);

    List<TransactionState> findTransactionStateListByFilter(@Param("filter") TransactionStateFilter filter,
                                                            @Param("limiter")Limiter limiter);

    Integer messageStateCount(Integer messageState);

}
