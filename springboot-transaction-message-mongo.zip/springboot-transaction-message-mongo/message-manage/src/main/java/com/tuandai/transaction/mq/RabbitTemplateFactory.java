package com.tuandai.transaction.mq;

import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class RabbitTemplateFactory implements InitializingBean {

    @Value("${spring.rabbitmq.host}")
    private String ip;

    @Value("${spring.rabbitmq.port}")
    private Integer port;

    @Value("${spring.rabbitmq.username}")
    private String name;

    @Value("${spring.rabbitmq.password}")
    private String key;

    private static String s_ip;

    private static Integer s_port;

    private static String s_name;

    private static String s_key;

    // 缓存连接池  vhost -> 连接池
    private static Map<String, CachingConnectionFactory> connectionFactoryMap = new ConcurrentHashMap<>();

    // 缓存RabbitTemplate
    private static Map<String, RabbitTemplate> rabbitTemplateMap = new ConcurrentHashMap<>();

    public static RabbitTemplate getRabbitTemplate(String vHost) {
        return getRabbitTemplate(vHost, false);
    }

    public static RabbitTemplate getRabbitTemplate(String vHost, boolean isPublisherConfirms) {
        CachingConnectionFactory connectionFactory = null;
        if (connectionFactoryMap.containsKey(vHost)) {
            connectionFactory = connectionFactoryMap.get(vHost);
        } else {
            connectionFactory = new CachingConnectionFactory(s_ip, s_port);
            connectionFactory.setUsername(s_name);
            connectionFactory.setPassword(s_key);
            connectionFactory.setVirtualHost(vHost);
            connectionFactory.setPublisherConfirms(true); // 必须要设置,生产者发送消息后的回调，这里RabbitTemplate必须是多例子模式的
            connectionFactoryMap.put(vHost, connectionFactory);
        }

        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        if (!rabbitTemplateMap.containsKey(vHost)) {
            rabbitTemplateMap.put(vHost, rabbitTemplate);
        }

        // 必须要设置,生产者发送消息后的回调，这里RabbitTemplate必须是多例子模式的
        return isPublisherConfirms ? rabbitTemplate : rabbitTemplateMap.get(vHost);
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        s_ip = ip;
        s_port = port;
        s_name = name;
        s_key = key;
    }

}
