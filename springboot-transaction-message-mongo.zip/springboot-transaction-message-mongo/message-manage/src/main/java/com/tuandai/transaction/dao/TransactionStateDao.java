package com.tuandai.transaction.dao;

import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.domain.filter.Limiter;
import com.tuandai.transaction.domain.filter.TransactionStateFilter;
import com.tuandai.transaction.repository.TransactionStateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@Component
public class TransactionStateDao {


    @Autowired
    private TransactionStateRepository transactionStateRepository;

    public void createIfNotExistsTable() {
        transactionStateRepository.createIfNotExistsTable();
    }

    public void insert(TransactionState transactionState) {
        if (transactionState == null) {
            return;
        }
        List<TransactionState> transactionStates = new ArrayList<>();
        transactionStates.add(transactionState);
        transactionStateRepository.insertBatch(transactionStates);
    }

    public void insertBatch(List<TransactionState> transactionStates) {
        if (CollectionUtils.isEmpty(transactionStates)) {
            return;
        }
        transactionStateRepository.insertBatch(transactionStates);
    }

    public void update(TransactionState transactionState) {
        transactionStateRepository.update(transactionState);
    }

    public void delete(Long transactionId) {
        if (transactionId == null) {
            return;
        }
        List<Long> transactionIds = new ArrayList<>();
        transactionIds.add(transactionId);
        transactionStateRepository.deleteBatch(transactionIds);
    }

    public void deleteBatch(List<Long> transactionIds) {
        if (CollectionUtils.isEmpty(transactionIds)) {
            return;
        }
        transactionStateRepository.deleteBatch(transactionIds);
    }


    public TransactionState findByTransactionId(Long transactionId) {
        if (transactionId == null) {
            return null;
        }
        TransactionStateFilter filter = new TransactionStateFilter();
        List<Long> transactionIds = new ArrayList<>();
        transactionIds.add(transactionId);
        filter.setTransactionIds(transactionIds);
        List<TransactionState> list = transactionStateRepository.findTransactionStateListByFilter(filter,
                new Limiter(0, 1, "transaction_id DESC"));
        return CollectionUtils.isEmpty(list) ? null : list.get(0);
    }

    public List<TransactionState> findTransactionStateListByFilter(TransactionStateFilter filter, Limiter limiter) {
        if (filter == null) {
            return null;
        }
        return transactionStateRepository.findTransactionStateListByFilter(filter, limiter);
    }


    public Integer messageStateCount(Integer messageState) {
        return transactionStateRepository.messageStateCount(messageState);
    }

}
