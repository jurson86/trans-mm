package com.tuandai.transaction.repository;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.tuandai.transaction.domain.OptLog;

@Mapper
public interface OptLogRepository {

    void createIfNotExistsTable();

    void truncateTable();

    void delete(Long transactionId);

    List<OptLog> selectAll();

    List<OptLog> findOptLogByTransactionId(Long transactionId);

    void dropTable();

    void insertBatch(List<OptLog> optlogs);
}
