package com.tuandai.transaction.mq;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.constant.BZStatusCode;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.ExchangeType;
import com.tuandai.transaction.model.message.RabbitTopic;
import com.tuandai.transaction.mq.inf.MqService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

public class RabbitMqServiceImpl implements MqService {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqServiceImpl.class);

    @Override
    public void sendMessage(TransactionMessage transactionMessage) {

        if (transactionMessage == null || transactionMessage.getMessageTopic() == null) {
            logger.error("transactionMessage or transactionMessage.getMessageTopic() is not null...");
            throw new ServiceException(BZStatusCode.INVALID_PARAMS_IS_NULL);
        }

        RabbitTopic rabbitTopic = JSONObject.parseObject(transactionMessage.getMessageTopic(), RabbitTopic.class);

        if (rabbitTopic == null || rabbitTopic.getvHost() == null || rabbitTopic.getExchange() == null || rabbitTopic.getExchangeType() == null) {
            logger.error("rabbitTopic or properties is not null...");
            throw new ServiceException(BZStatusCode.INVALID_PARAMS_IS_NULL);
        }

        RabbitTemplate rabbitTemplate = RabbitTemplateFactory.getRabbitTemplate(rabbitTopic.getvHost());
        ConnectionFactory connectionFactory = rabbitTemplate.getConnectionFactory();
        RabbitAdmin rabbitAdmin = new RabbitAdmin(connectionFactory);
        // 根据不同类型生成交换机
        rabbitAdmin.declareExchange(getExchangeByType(rabbitTopic));
        RabbitMqMessage message = new RabbitMqMessage();
        message.setMessage(transactionMessage.getMessage());
        message.setMessageId(String.valueOf(transactionMessage.getWorkerId()) + Constants.MESSAGE_ID_SPLIT + transactionMessage.getTransactionId());
        rabbitTemplate.convertAndSend(rabbitTopic.getExchange(), rabbitTopic.getRouteKey(), JSONObject.toJSONString(message));
    }

    private Exchange getExchangeByType(RabbitTopic rabbitTopic) {
        String type = rabbitTopic.getExchangeType();
        if (type == null) {
            return new FanoutExchange(rabbitTopic.getExchange());
        }
        ExchangeType exchangeType = ExchangeType.findByDes(type);
        if (exchangeType == null) {
            logger.error("not ExchangeType.....");
            throw new ServiceException(BZStatusCode.INVALID_PARAMS_CONVERSION);
        }
        
        if (exchangeType == ExchangeType.FANOUT) {
            return new FanoutExchange(rabbitTopic.getExchange());
        } else if (exchangeType == ExchangeType.HEADRES) {
            return new HeadersExchange(rabbitTopic.getExchange());
        } else if (exchangeType == ExchangeType.DIRECT) {
            return new DirectExchange(rabbitTopic.getExchange());
        } else if (exchangeType == ExchangeType.TOPIC) {
            return new TopicExchange(rabbitTopic.getExchange());
        }
        return null;
    }


    class RabbitMqMessage {
        private String messageId;

        private String message;

        public String getMessageId() {
            return messageId;
        }

        public void setMessageId(String messageId) {
            this.messageId = messageId;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

}
