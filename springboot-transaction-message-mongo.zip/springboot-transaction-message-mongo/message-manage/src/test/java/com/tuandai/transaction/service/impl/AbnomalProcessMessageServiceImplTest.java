package com.tuandai.transaction.service.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.powermock.api.mockito.PowerMockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.tuandai.transaction.component.ThresholdsTimeManage;
import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.mq.MqSendHelper;
import com.tuandai.transaction.service.TmmLogService;

public class AbnomalProcessMessageServiceImplTest {

	@InjectMocks
	private AbnomalProcessMessageServiceImpl abnomalProcessMessageService;

	@Mock
	private TransactionStateDao transactionStateDao;

	@Mock
	private TransactionMessageDao transactionMessageDao;
	
	@Mock
	private TmmLogService tmmLogService;
	
	@Mock
	private AbnomalThreadCallService abnomalThreadCallService;
	
	@Mock
	private MqSendHelper mqSendHelper;
	
	@Mock
	private ThresholdsTimeManage thresholdsTimeManage;

	// 预发送回调 TransactionMessage 列表
	TransactionState transactionState = new TransactionState();
	TransactionMessage transactionMessage = new TransactionMessage();
	List<TransactionState> findForPresendBackList = new ArrayList<TransactionState>();
	List<TransactionMessage> findForSendMQList = new ArrayList<TransactionMessage>();
	List<TransactionMessage> findForDoneBackList = new ArrayList<TransactionMessage>();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟

	ResponseEntity<String> responseOk = new ResponseEntity<String>("{'status':200}", HttpStatus.OK);

	@Before
	public void setUp() throws ParseException {
//		// 初始化 findForPresendBackList 数据；
		transactionState.setWorkerId(81L);
		transactionState.setTransactionId(1000000001L);
		transactionState.setServiceName("mokeTest");
		transactionState.setCreateTime(new Date());
		transactionState.setMessageState(21);
		transactionState.setMessageSendThreshold(10);
		transactionState.setMessageSendTimes(0);
		transactionState.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionState.setPresendBackUrl("http://127.0.0.1:8090/");
		transactionState.setPresendBackMethod("POST");
		transactionState.setPresendBackThreshold(6);
		transactionState.setPresendBackSendTimes(0);
		transactionState.setPresendBackNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		findForPresendBackList.add(transactionState);

		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setWorkerId(81L);
		transactionMessage.setMessage("hello");
		transactionMessage.setTransactionId(1000000001L);
		transactionMessage.setPresendBackUrl("http://127.120.0.1:8090/");
		transactionMessage.setMessageType(1);
		findForSendMQList.add(transactionMessage);


//
//
//
//		transactionMessage = new TransactionMessage();
//		transactionMessage.setServiceName("test");
//		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
//		transactionMessage.setExpectResult("a");
//		transactionMessage.setMessage("hello");
//		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
//		transactionMessage.setMessageSendThreshold(10);
//		transactionMessage.setMessageState(20);
//		transactionMessage.setTransactionId(1000000003L);
//		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
//		transactionMessage.setMessageSendTimes(0);
//		transactionMessage.setPresendBackSendTimes(0);
//		transactionMessage.setMessageType(1);
//		findForSendMQList.add(transactionMessage);
//
//		transactionMessage = new TransactionMessage();
//		transactionMessage.setServiceName("test");
//		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
//		transactionMessage.setExpectResult("a");
//		transactionMessage.setMessage("hello");
//		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
//		transactionMessage.setMessageSendThreshold(0);
//		transactionMessage.setMessageState(20);
//		transactionMessage.setTransactionId(1000000004L);
//		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
//		transactionMessage.setMessageSendTimes(0);
//		transactionMessage.setPresendBackSendTimes(0);
//		transactionMessage.setMessageType(1);
//		findForSendMQList.add(transactionMessage);
//
//
//		transactionMessage = new TransactionMessage();
//		transactionMessage.setServiceName("test");
//		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
//		transactionMessage.setExpectResult("a");
//		transactionMessage.setMessage("hello");
//		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
//		transactionMessage.setMessageSendThreshold(10);
//		transactionMessage.setMessageState(30);
//		transactionMessage.setTransactionId(1000000005L);
//		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
//		transactionMessage.setMessageType(0);
//		transactionMessage.setMessageSendTimes(0);
//		transactionMessage.setPresendBackSendTimes(0);
//		findForDoneBackList.add(transactionMessage);
//
//		transactionMessage = new TransactionMessage();
//		transactionMessage.setServiceName("test");
//		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
//		transactionMessage.setExpectResult("a");
//		transactionMessage.setMessage("hello");
//		transactionMessage.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
//		transactionMessage.setMessageSendThreshold(10);
//		transactionMessage.setMessageState(30);
//		transactionMessage.setTransactionId(1000000006L);
//		transactionMessage.setPresendBackUrl("http://1.0.0.1:0000/");
//		transactionMessage.setMessageType(1);
//		transactionMessage.setMessageSendTimes(0);
//		transactionMessage.setPresendBackSendTimes(0);
//		findForDoneBackList.add(transactionMessage);
//
		abnomalProcessMessageService = new AbnomalProcessMessageServiceImpl();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(transactionStateDao);
		reset(abnomalThreadCallService);
		reset(tmmLogService);
		reset(mqSendHelper);
		reset(thresholdsTimeManage);
	}

	/**
	 * [预发送回调]请求多线程调启
	 * 
	 * @throws Exception
	 */
	@Test
	public void preSendCallbackByTask_CallbackTrue() throws Exception {
		// stubbing
		when(transactionStateDao.findTransactionStateListByFilter(any(), any())).thenReturn(findForPresendBackList);

		when(abnomalThreadCallService.presendCallback(anyObject())).thenReturn(true);

		abnomalProcessMessageService.preSendCallbackByTask();

	}

	/**
	 * [发送消息]消息发送，成功
	 */
	@Test
	public void sendToMQByTask_success() throws InterruptedException {
		when(transactionStateDao.findTransactionStateListByFilter(any(), any())).thenReturn(findForPresendBackList);
		abnomalProcessMessageService.sendToMQByTask();
		//verify(rocketMQHelper).sendTranTopicMsg(findForSendMQList.get(0));
	}

	/**
	 * [发送消息]消息发送，异常
	 */
	@Test
	public void sendToMQByTask_exception() throws InterruptedException {

		when(transactionStateDao.findTransactionStateListByFilter(any(), any())).thenReturn(findForPresendBackList);

		doThrow(new RuntimeException("error")).when(mqSendHelper).sendTranTopicMsg(anyObject());

		abnomalProcessMessageService.sendToMQByTask();
	}

	/**
	 * [发送消息]消息重新发送 成功
	 */
	@Test
	public void resendMessageByTransactionId_success() throws InterruptedException {
		transactionState.setMessageState(30);
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);

		abnomalProcessMessageService.resendMessageByTransactionId(10001L);
	}

	/**
	 * [发送消息]消息重新发送 INVALID_STATE_OPTION
	 */
	@Test(expected=ServiceException.class)
	public void resendMessageByTransactionId_invalid() throws InterruptedException {
		transactionState.setMessageState(100);
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);

		abnomalProcessMessageService.resendMessageByTransactionId(10001L);

	}

	/**
	 * [发送消息]消息重新发送  rocketMQHelper Exception
	 */
	@Test
	public void resendMessageByTransactionId_exception() throws InterruptedException {
		transactionState.setMessageState(30);
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		abnomalProcessMessageService.resendMessageByTransactionId(10001L);
	}

}
