package com.tuandai.transaction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.client.RestTemplate;

import com.tuandai.transaction.component.RocketMQHelper;
import com.tuandai.transaction.component.ThresholdsTimeManage;
import com.tuandai.transaction.constant.Constants;
import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.exception.ServiceException;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.model.request.MessageIdCreator;
import com.tuandai.transaction.service.TmmLogService;

@RunWith(PowerMockRunner.class)  //1.
@PrepareForTest({Constants.class })
public class NomalProcessMessageServiceTest {

	@InjectMocks
	private NomalProcessMessageServiceImpl nomalProcessMessageServiceImpl;

	@Mock
	private TransactionMessageDao transactionMessageDao;

	@Mock
	private TransactionStateDao transactionStateDao;

	@Mock
	private TmmLogService tmmLogService;

	@Mock
	private RocketMQHelper rocketMQHelper;

	@Mock
	private ThresholdsTimeManage thresholdsTimeManage;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private TransactionTemplate transactionTemplate;

	// 预发送回调 TransactionMessage 列表
	MessageIdCreator messageIdCreator = new MessageIdCreator();
	TransactionMessage transactionMessage = new TransactionMessage();
	TransactionState transactionState = new TransactionState();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟

	ResponseEntity<String> responseOk = new ResponseEntity<String>("{'status':200}", HttpStatus.OK);

	@Before
	public void setUp() throws ParseException {
        // 初始化 transactionMessage 数据;
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setWorkerId(81L);
		transactionMessage.setMessage("hello");
		transactionMessage.setTransactionId(1000000001L);
		transactionMessage.setPresendBackUrl("http://127.120.0.1:8090/");
		transactionMessage.setMessageType(1);

		transactionState.setWorkerId(81L);
		transactionState.setTransactionId(1000000001L);
		transactionState.setServiceName("mokeTest");
		transactionState.setCreateTime(new Date());
		transactionState.setMessageState(21);
		transactionState.setMessageSendThreshold(10);
		transactionState.setMessageSendTimes(0);
		transactionState.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionState.setPresendBackUrl("http://127.0.0.1:8090/");
		transactionState.setPresendBackMethod("POST");
		transactionState.setPresendBackThreshold(6);
		transactionState.setPresendBackSendTimes(0);
		transactionState.setPresendBackNextSendTime(sdf.parse("2017-10-13 16:55:11"));

		nomalProcessMessageServiceImpl = new NomalProcessMessageServiceImpl();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(transactionStateDao);
		reset(tmmLogService);
		reset(rocketMQHelper);
		reset(thresholdsTimeManage);
	}

	@Test(expected=ServiceException.class)
	public void createMessage_success() throws Exception {
		messageIdCreator.setPresendBackUrl("127.0.0.1");
		messageIdCreator.setServiceName("mockTest");

		PowerMockito.spy(Constants.class);
		PowerMockito.when(Constants.getRouteKey()).thenReturn(81L);

		nomalProcessMessageServiceImpl.createMessage(messageIdCreator);
	}
	

	@Test
	public void updateMessageToSend_success() throws Exception {
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());

		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);

		nomalProcessMessageServiceImpl.updateMessageToSend(10001L,null);

	}

	@Test
	public void updateMessageToSend_sendFailed() throws Exception {
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		doThrow(new RuntimeException("test exception ")).when(rocketMQHelper).sendTranTopicMsg(anyObject());
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		nomalProcessMessageServiceImpl.updateMessageToSend(10001L,null);

	}


	@Test
	public void updateMessageToDiscard_success() throws Exception {
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		doThrow(new RuntimeException("test exception ")).when(rocketMQHelper).sendTranTopicMsg(anyObject());

		nomalProcessMessageServiceImpl.updateMessageToDiscard(10001L, null);

	}


	@Test
	public void getTransactionMessageById_success() throws Exception {
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);

		TransactionMessage result = nomalProcessMessageServiceImpl.getTransactionMessageById(10001L);

        assertThat(result).as("判断是否成功").isNotNull();
	}


	@Test
	public void updateMessageToPreSend_success() throws Exception {
		transactionState.setMessageState(MessageState.ABNORMAL.code());
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);
		nomalProcessMessageServiceImpl.updateMessageToPreSend(10001L);
	}

	@Test(expected=ServiceException.class)
	public void updateMessageToPreSend_failed() throws Exception {
		transactionState.setMessageState(MessageState.SEND.code());
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);

		nomalProcessMessageServiceImpl.updateMessageToPreSend(10001L);
	}


	@Test
	public void updateMessageToAbnormal_success() throws Exception {
		transactionState.setMessageState(MessageState.PRESEND.code());
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);

		nomalProcessMessageServiceImpl.updateMessageToAbnormal(10001L);

	}


	@Test(expected=ServiceException.class)
	public void updateMessageToAbnormal_failed() throws Exception {
		transactionState.setMessageState(MessageState.SEND.code());
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);

		nomalProcessMessageServiceImpl.updateMessageToAbnormal(10001L);
	}


	@Test
	public void updateMessageToDied_success() throws Exception {
		transactionState.setMessageState(MessageState.SEND.code());
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);

		nomalProcessMessageServiceImpl.updateMessageToDied(10001L);

	}


	@Test(expected=ServiceException.class)
	public void updateMessageToDied_failed() throws Exception {
		transactionState.setMessageState(MessageState.PRESEND.code());
		when(transactionStateDao.findByTransactionId(anyLong())).thenReturn(transactionState);

		nomalProcessMessageServiceImpl.updateMessageToDied(10001L);
	}



	@Test
	public void getMessageStateCount_success() throws Exception {
		when(transactionStateDao.messageStateCount(anyInt())).thenReturn(10);

		int result = nomalProcessMessageServiceImpl.getMessageStateCount(10);

        assertThat(result).as("判断是否成功").isEqualTo(10);
	}

	@Test
	public void queryTransactionMessageByState_success() throws Exception {
		when(transactionStateDao.findTransactionStateListByFilter(any(), any())).thenReturn(new ArrayList<TransactionState>());

		List<TransactionState> result = nomalProcessMessageServiceImpl.queryTransactionMessageByState(10);

        assertThat(result).as("判断是否成功").isNotNull();
	}
	
}
