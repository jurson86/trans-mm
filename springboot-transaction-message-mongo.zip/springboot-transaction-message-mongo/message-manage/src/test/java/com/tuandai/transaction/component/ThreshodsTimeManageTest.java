package com.tuandai.transaction.component;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tuandai.transaction.config.SpringBootConfig;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ThresholdsTimeManage.class,String.class})
public class ThreshodsTimeManageTest {

	private static final Logger logger = LoggerFactory.getLogger(ThreshodsTimeManageTest.class);

	@InjectMocks
	private ThresholdsTimeManage thresholdsTimeManage;
	@Mock
	SpringBootConfig springBootConfig;

	@Before
	public void setUp() throws ParseException {
		thresholdsTimeManage = new ThresholdsTimeManage();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(springBootConfig);
	}
	

	/**
	 * 检测创建预发送时间，是否符合期望
	 */
	@SuppressWarnings("deprecation")
	@Test
	public void createPreSendBackTime_success10() {
		when(springBootConfig.getPreSendBackThresholdstr()).thenReturn("1200,600,60,30,10,8");
		Date pdt = new Date();
		Date dt = thresholdsTimeManage.createPreSendBackTime(10);
		logger.info("=========> : {}", dt.toGMTString());
		assertThat((dt.getTime() - pdt.getTime()) / 1000).as("判断是否成功").isGreaterThan(6);
	}
	/**
	 * 检测创建预发送时间，是否符合期望
	 */
	@Test
	public void createPreSendBackTime_success3() {
		when(springBootConfig.getPreSendBackThresholdstr()).thenReturn("1200,600,60,30,10,8");
		Date pdt = new Date();
		Date dt = thresholdsTimeManage.createPreSendBackTime(3);
		assertThat((dt.getTime() - pdt.getTime()) / 1000).as("判断是否成功").isGreaterThan(58);
	}

	/**
	 * 检测创建结果回调时间，是否符合期望
	 */
	@Test
	public void createResultBackTime() {
		when(springBootConfig.getResultBackThresholdstr()).thenReturn("30");
		Date pdt = new Date();
		Date dt = thresholdsTimeManage.createResultBackTime();
		assertThat((dt.getTime() - pdt.getTime()) / 1000).as("判断是否成功").isGreaterThan(28);

	}

	/**
	 * 检测获取发送MQ，调用时间，是否符合期望
	 */
	@Test
	public void createSendNextTime_success10() {
		when(springBootConfig.getSendThresholdstr()).thenReturn("120,60,30,20,20,10,60,8,8,8");
		Date pdt = new Date();
		Date dt = thresholdsTimeManage.createSendNextTime(10);
		assertThat((dt.getTime() - pdt.getTime()) / 1000).as("判断是否成功").isGreaterThan(6);

	}
	/**
	 * 检测获取发送MQ，调用时间，是否符合期望
	 */
	@Test
	public void createSendNextTime_success2() {
		when(springBootConfig.getSendThresholdstr()).thenReturn("120,60,30,20,20,10,60,8,8,8");
		Date pdt = new Date();
		Date dt = thresholdsTimeManage.createSendNextTime(2);
		assertThat((dt.getTime() - pdt.getTime()) / 1000).as("判断是否成功").isGreaterThan(58);

	}
	/**
	 * 检测获取发送MQ，调用时间，是否符合期望
	 */
	@Test
	public void createSendNextTime_success0() {
		when(springBootConfig.getSendThresholdstr()).thenReturn("120,60,30,20,20,10,60,8,8,8");
		Date dt = thresholdsTimeManage.createSendNextTime(0);
		assertThat(dt).as("判断是否成功").isNull();

	}

}
