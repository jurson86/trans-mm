package com.tuandai.transaction.service.impl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.tuandai.transaction.component.RocketMQHelper;
import com.tuandai.transaction.component.ThresholdsTimeManage;
import com.tuandai.transaction.dao.TransactionMessageDao;
import com.tuandai.transaction.dao.TransactionStateDao;
import com.tuandai.transaction.domain.TransactionMessage;
import com.tuandai.transaction.domain.TransactionState;
import com.tuandai.transaction.service.TmmLogService;

public class AbnomalThreadCallServiceTest {

	@InjectMocks
	private AbnomalThreadCallService abnomalThreadCallService;

	@Mock
	private TransactionMessageDao transactionMessageDao;

	@Mock
	private TransactionStateDao transactionStateDao;

	@Mock
	private TmmLogService tmmLogService;

	@Mock
	private RestTemplate thRestTemplate ;

	@Mock
	private ThresholdsTimeManage thresholdsTimeManage;

	@Mock
	private RocketMQHelper rocketMQHelper;

	// 预发送回调 TransactionMessage 列表
	TransactionMessage transactionMessage = new TransactionMessage();
	TransactionState transactionState = new TransactionState();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 小写的mm表示的是分钟

	ResponseEntity<String> responseOk = null;

	@Before
	public void setUp() throws ParseException {
		// 初始化 transactionMessage 数据;
		transactionMessage.setCreateTime(sdf.parse("2017-10-13 16:55:01"));
		transactionMessage.setWorkerId(81L);
		transactionMessage.setMessage("hello");
		transactionMessage.setTransactionId(1000000001L);
		transactionMessage.setPresendBackUrl("http://127.120.0.1:8090/");
		transactionMessage.setMessageType(1);

		transactionState.setWorkerId(81L);
		transactionState.setTransactionId(1000000001L);
		transactionState.setServiceName("mokeTest");
		transactionState.setCreateTime(new Date());
		transactionState.setMessageState(21);
		transactionState.setMessageSendThreshold(10);
		transactionState.setMessageSendTimes(0);
		transactionState.setMessageNextSendTime(sdf.parse("2017-10-13 16:55:11"));
		transactionState.setPresendBackUrl("http://127.0.0.1:8090/");
		transactionState.setPresendBackMethod("POST");
		transactionState.setPresendBackThreshold(6);
		transactionState.setPresendBackSendTimes(0);
		transactionState.setPresendBackNextSendTime(sdf.parse("2017-10-13 16:55:11"));


		abnomalThreadCallService = new AbnomalThreadCallService();
		MockitoAnnotations.initMocks(this);

	}

	@After
	public void tearDown() throws Exception {
		reset(transactionMessageDao);
		reset(tmmLogService);
	}

	/**
	 * [人工干预-预发送回调]请求 success
	 *
	 * @throws Exception
	 */
	@Test
	public void presendCallback_success_task() throws Exception {
		// stubbing
		responseOk = new ResponseEntity<String>("{'status':200, 'messageIdAck': {'transactionId':1, 'state':'COMMIT_MESSAGE', 'messageTopic':'mokeTest', 'messageType':'0', 'message':'hello!!'}}", HttpStatus.OK);

		when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(transactionMessage);
		//doNothing().when(transactionMessageRepository).update(anyObject());
		//doNothing().when(optLogRepository).save(anyObject());
		//doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());

		boolean result = abnomalThreadCallService.presendCallback(transactionState);

		assertThat(result).as("判断是否成功").isTrue();
	}

	/**
	 * [定时任务-预发送回调]请求 success
	 *
	 * @throws Exception
	 */
	@Test
	public void presendCallback_success() throws Exception {
		responseOk = new ResponseEntity<String>("{'status':200, 'messageIdAck': {'transactionId':1, 'state':'COMMIT_MESSAGE', 'messageTopic':'mokeTest', 'messageType':'0', 'message':'hello!!'}}", HttpStatus.OK);

		when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);
		when(transactionMessageDao.findByTransactionId(anyLong())).thenReturn(null);

		boolean result = abnomalThreadCallService.presendCallback(transactionState);

		assertThat(result).as("判断是否成功").isTrue();
	}


	/**
	 * [人工干预-预发送回调]请求 discard
	 *
	 * @throws Exception
	 */
	@Test
	public void presendCallback_discard() throws Exception {
		// stubbing
		responseOk = new ResponseEntity<String>("{'status':200, 'messageIdAck': {'transactionId':1, 'state':'COMMIT_MESSAGE', 'messageTopic':'mokeTest', 'messageType':'0', 'message':'hello!!'}}", HttpStatus.OK);

		when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenReturn(responseOk);

		boolean result = abnomalThreadCallService.presendCallback(transactionState);

		assertThat(result).as("判断是否成功").isTrue();
	}

	/**
	 * [预发送回调]请求 failed
	 *
	 * @throws Exception
	 */
	@Test
	public void presendCallback_failed() throws Exception {
		when(thRestTemplate.exchange(anyString(), any(), any(), Matchers.eq(String.class))).thenThrow(new RuntimeException());

		//doNothing().when(transactionMessageRepository).update(anyObject());
		//doNothing().when(optLogRepository).save(anyObject());
		doNothing().when(rocketMQHelper).sendTranTopicMsg(anyObject());

		boolean result = abnomalThreadCallService.presendCallback(transactionState);

		assertThat(result).as("判断回调异常是否正确").isFalse();
	}

}
