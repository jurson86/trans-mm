package com.tuandai.transaction.bo;

public enum JobState {

    PAUSE(1, "暂停"),

    RESUME(0, "恢复");

    private final int code;

    private final String state;

    JobState(int code, String state) {
        this.code = code;
        this.state = state;
    }

    public int code() {
        return code;
    }

    public String state() {
        return state;
    }



}
