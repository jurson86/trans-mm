package com.tuandai.transaction.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class HttpUrlPool {

    @Autowired
    private Setting setting;

    public String getMessageStateUrl(int state) {
        return "http://"+ setting.getCurrentMessageHost() +  "/message/monitor/" + state;
    }

    public String getMessageStateUrl(int state, String ip) {
        return "http://"+ ip +  "/message/monitor/" + state;
    }

    public String getMsgListUrl(int state) {
        return "http://" + setting.getCurrentMessageHost() +  "/message/query/" + (state == 0 ? 10 : state);
    }

    public String getMsgDiscardUrl() {
        return  "http://"+ setting.getCurrentMessageHost() +  "/message/discard";
    }

    public String getMsgDiedUrl(String state) {
        return "http://"+ setting.getCurrentMessageHost() +  "/message/change/died/"+state;
    }

    public String getMsgDetailUrl(String msgId) {
        return "http://" + setting.getCurrentMessageHost() +  "/message/get/"+msgId;
    }

    public String getMsgStateUrl(String msgId) {
        return "http://" + setting.getCurrentMessageHost() +  "/state/get/"+msgId;
    }

    public String getMsgAbnormalUrl(String state) {
        return "http://"+ setting.getCurrentMessageHost() +  "/message/change/abnormal/"+state;
    }

    public String getMsgResendUrl() {
        return "http://"+ setting.getCurrentMessageHost() +"/message/resend";
    }
}
