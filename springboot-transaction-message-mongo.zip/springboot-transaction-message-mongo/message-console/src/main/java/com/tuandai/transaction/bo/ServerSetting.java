package com.tuandai.transaction.bo;

import javax.persistence.*;

@Entity
public class ServerSetting {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String serverIp;

    @Column
    private Integer isDefault;

    public ServerSetting() {}

    public ServerSetting(String serverIp, Integer isDefault) {
        this.serverIp = serverIp;
        this.isDefault = isDefault;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Integer getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Integer isDefault) {
        this.isDefault = isDefault;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
