package com.tuandai.transaction.mapper;

import com.tuandai.transaction.bo.ServerCount;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;

public interface ServerCountMapper  extends JpaRepository<ServerCount, Long> {

//    @Query(value = "select u from ServerCount u where u.state=:state and u.serverIp=:serverIp  ORDER BY ?#{#pageable}",
//            countQuery = "SELECT count(*) FROM ServerCount u WHERE u.state=:state and u.serverIp=:serverIp", nativeQuery =true)
    Page<ServerCount> queryServerCountsByStateAndServerIp(int state,  String serverIp, Pageable pageable);


    @Modifying
    @Query("delete from ServerCount where time < :beginTime")
    void deletedByTime(@Param("beginTime")Date beginTime);

}
