package com.tuandai.transaction.common;

import com.alibaba.fastjson.JSON;
import org.springframework.util.StringUtils;


import java.io.*;
import java.net.*;
import java.util.*;
import java.util.Map.Entry;
/**
 * Http请求工具类
 *
 *
 * @author zhangweirui
 */
public class HttpUtils {

    private static final String DEFAULT_CHARSET = "UTF-8";
    private static final String METHOD_POST = "POST";
    private static final String METHOD_GET = "GET";
    private static final String METHOD_PUT = "PUT";
    private static final String METHOD_DELETE = "DELETE";

    /**
     * time out setting
     */
    private static final int DEFAULT_TIMEOUT = 30000;

    /**
     * 当前本机的网络IP
     */
    private static String localIp;

    /**
     * 获取本机的网络IP
     */
    public static String getLocalNetWorkIp() {
        if (localIp != null) {
            return localIp;
        }
        try {
            Enumeration<NetworkInterface> netInterfaces = NetworkInterface.getNetworkInterfaces();
            InetAddress ip = null;
            while (netInterfaces.hasMoreElements()) {// 遍历所有的网卡
                NetworkInterface ni = netInterfaces.nextElement();
                if (!ni.isUp() || ni.isLoopback() || ni.isVirtual() || ni.isPointToPoint()) {
                    continue;
                }
                Enumeration<InetAddress> addresss = ni.getInetAddresses();
                while (addresss.hasMoreElements()) {
                    InetAddress address = addresss.nextElement();
                    if (address instanceof Inet4Address) {// 这里暂时只获取ipv4地址
                        ip = address;
                        break;
                    }
                }
                if (ip != null) {
                    break;
                }
            }
            if (ip != null) {
                localIp = ip.getHostAddress();
            } else {
                localIp = "127.0.0.1";
            }
        } catch (Exception e) {
            localIp = "127.0.0.1";
        }
        return localIp;
    }

    /*
     * 执行PUT请求
     */
    public static String doPut(String url, Map<String, Object> params, int connectTimeout,
            int readTimeout) throws IOException {
        return doMethod(url, params, DEFAULT_CHARSET, connectTimeout, readTimeout, METHOD_PUT, null);
    }

    public static String doPut(String url, Map<String, Object> params) throws IOException {
        return doMethod(url, params, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT, METHOD_PUT,
                null);
    }

    public static String doPut(String url, String strContent) throws IOException {
        return doMethod(url, strContent, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT,
                METHOD_PUT);
    }

    public static String doPut(String url, Map<String, Object> params, Map<String, String> headers,
            String cType) throws IOException {
        return doMethod(url, params, headers, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT,
                METHOD_PUT, cType);
    }

    public static String doPost(String url, Map<String, Object> params,
            Map<String, String> headers, String cType) throws IOException {
        return doMethod(url, params, headers, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT,
                METHOD_POST, cType);
    }

    public static String doDelete(String url, Map<String, Object> params,
            Map<String, String> headers, String cType) throws IOException {
        return doMethod(url, params, headers, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT,
                METHOD_DELETE, cType);
    }

    public static String doMethod(String url, String paramStrContent, String charset,
            int connectTimeout, int readTimeout, String method) throws IOException {

        String ctype = "application/x-www-form-urlencoded;charset=" + charset;
        byte[] content = {};
        if (paramStrContent != null) {
            content = paramStrContent.getBytes(charset);
        }

        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            try {
                conn = getConnection(new URL(url), method, ctype);

                conn.setConnectTimeout(connectTimeout);
                conn.setReadTimeout(readTimeout);
            } catch (IOException e) {
                throw e;
            }
            try {
                out = conn.getOutputStream();
                out.write(content);
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }



    /**
     * 执行HTTP POST请求。
     *
     * @param url 请求地址
     * @param params 请求参数
     * @return 响应字符串
     * @throws IOException
     */
    public static String doPost(String url, Map<String, String> params, int connectTimeout,
            int readTimeout) throws IOException {
        return doPost(url, params, DEFAULT_CHARSET, connectTimeout, readTimeout);
    }

    public static String doPost(String url, Map<String, String> params) throws IOException {
        return doPost(url, params, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT);
    }

    /**
     * 执行HTTP POST请求。
     *
     * @param url 请求地址
     * @param params 请求参数
     * @param charset 字符集，如UTF-8, GBK, GB2312
     * @return 响应字符串
     * @throws IOException
     */
    public static String doJsonPost(String url, Map<String, String> params, String charset,
            int connectTimeout, int readTimeout) throws IOException {

        String ctype = "application/json;charset=" + charset;
        String query = JSON.toJSONString(params);
        byte[] content = {};
        if (query != null) {
            content = query.getBytes(charset);
        }

        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            try {
                conn = getConnection(new URL(url), METHOD_POST, ctype);

                conn.setConnectTimeout(connectTimeout);
                conn.setReadTimeout(readTimeout);
            } catch (IOException e) {
                throw e;
            }
            try {
                out = conn.getOutputStream();
                out.write(content);
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }

    public static String doJsonPost(String url, Map<String, String> params, int connectTimeout,
            int readTimeout) throws IOException {
        return doPost(url, params, DEFAULT_CHARSET, connectTimeout, readTimeout);
    }

    public static String doJsonPost(String url, Map<String, String> params) throws IOException {
        return doJsonPost(url, params, DEFAULT_CHARSET, DEFAULT_TIMEOUT, DEFAULT_TIMEOUT);
    }



    /**
     * 执行HTTP POST请求。
     *
     * @param url 请求地址
     * @param charset 字符集，如UTF-8, GBK, GB2312
     * @return 响应字符串
     * @throws IOException
     */
    public static String doMethod(String url, Map<String, Object> params, String charset,
            int connectTimeout, int readTimeout, String method, String cType) throws IOException {

        return doMethod(url, params, null, charset, connectTimeout, readTimeout, method, cType);

    }



    /**
     * 执行HTTP POST请求。
     *
     * @param url 请求地址
     * @param charset 字符集，如UTF-8, GBK, GB2312
     * @return 响应字符串
     * @throws IOException
     */
    public static String doMethod(String url, Map<String, Object> params,
            Map<String, String> headers, String charset, int connectTimeout, int readTimeout,
            String method, String ctype) throws IOException {
        byte[] content = {};
        if (!StringUtils.isEmpty(ctype) && "application/json".equals(ctype)) {
            ctype = ctype + ";charset=" + charset;
            content = JSON.toJSONString(params).getBytes();
        }

        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            try {
                conn = getConnection(new URL(url), method, ctype);
                if (headers != null) {
                    for (Entry<String, String> hdr : headers.entrySet()) {
                        conn.setRequestProperty(hdr.getKey(), hdr.getValue());
                    }
                }
                conn.setConnectTimeout(connectTimeout);
                conn.setReadTimeout(readTimeout);
            } catch (IOException e) {
                throw e;
            }
            try {
                out = conn.getOutputStream();
                out.write(content);
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }

    public static String doPost(String url, String params, String charset, int connectTimeout,
            int readTimeout) throws IOException {

        String ctype = "application/x-www-form-urlencoded;charset=" + charset;
        // String query = buildQuery(params, charset);
        byte[] content = {};
        // if (query != null) {
        // content = query.getBytes(charset);
        // }
        URL callUrl = new URL(url + params);
        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            try {
                conn = getConnection(callUrl, METHOD_POST, ctype);

                conn.setConnectTimeout(connectTimeout);
                conn.setReadTimeout(readTimeout);
            } catch (IOException e) {
                throw e;
            }
            try {
                out = conn.getOutputStream();
                out.write(content);
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }

    /**
     * 执行HTTP POST请求。
     *
     * @param url 请求地址
     * @param params 请求参数
     * @param charset 字符集，如UTF-8, GBK, GB2312
     * @return 响应字符串
     * @throws IOException
     */
    public static String doPost(String url, Map<String, String> params, String charset,
            int connectTimeout, int readTimeout) throws IOException {

        String ctype = "application/x-www-form-urlencoded;charset=" + charset;
        String query = buildQuery(params, charset);
        byte[] content = {};
        if (query != null) {
            content = query.getBytes(charset);
        }

        HttpURLConnection conn = null;
        OutputStream out = null;
        String rsp = null;
        try {
            try {
                conn = getConnection(new URL(url), METHOD_POST, ctype);

                conn.setConnectTimeout(connectTimeout);
                conn.setReadTimeout(readTimeout);
            } catch (IOException e) {
                throw e;
            }
            try {
                out = conn.getOutputStream();
                out.write(content);
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (out != null) {
                out.close();
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }

    /**
     * 从URL中获取请求参数Map
     */
    public static Map<String, String> getParamsFromUrl(String url) {
        Map<String, String> map = new HashMap<String, String>();
        if (url != null && url.indexOf('?') != -1) {
            String query = url.substring(url.indexOf('?') + 1);

            String[] pairs = query.split("&");
            if (pairs != null && pairs.length > 0) {
                for (String pair : pairs) {
                    String[] param = pair.split("=", 2);
                    if (param != null && param.length == 2) {
                        map.put(param[0], param[1]);
                    }
                }
            }
        }

        return map;
    }

    /**
     * 执行HTTP GET请求。
     *
     * @param url 请求地址
     * @param params 请求参数
     * @return 响应字符串
     * @throws IOException
     */
    public static String doGet(String url, Map<String, String> params) throws IOException {
        return doGet(url, params, DEFAULT_CHARSET);
    }

    /**
     * 执行HTTP GET请求。
     *
     * @param url 请求地址
     * @param params 请求参数
     * @param charset 字符集，如UTF-8, GBK, GB2312
     * @return 响应字符串
     * @throws IOException
     */
    public static String doGet(String url, Map<String, String> params, String charset)
            throws IOException {
        HttpURLConnection conn = null;
        String rsp = null;

        try {
            String ctype = "application/json;charset=" + charset;
            String query = buildQuery(params, charset);
            try {
                conn = getConnection(buildGetUrl(url, query), METHOD_GET, ctype);
            } catch (IOException e) {
                throw e;
            }

            try {
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }



    public static String doGet(String url, Map<String, String> params, Map<String, String> headers,
            String charset) throws IOException {
        HttpURLConnection conn = null;
        String rsp = null;

        try {
            String ctype = "application/json;charset=" + charset;
            String query = buildQuery(params, charset);
            try {
                conn = getConnection(buildGetUrl(url, query), METHOD_GET, ctype);
                if (headers != null) {
                    for (Entry<String, String> hdr : headers.entrySet()) {
                        conn.setRequestProperty(hdr.getKey(), hdr.getValue());
                    }
                }
            } catch (IOException e) {
                throw e;
            }

            try {
                rsp = getResponseAsString(conn);
            } catch (IOException e) {
                throw e;
            }

        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        return rsp;
    }

    private static HttpURLConnection getConnection(URL url, String method, String ctype)
            throws IOException {
        HttpURLConnection conn = null;
        conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod(method);
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setRequestProperty("Accept", "*/*");
        conn.setRequestProperty("User-Agent", "top-sdk-java");
        conn.setRequestProperty("Content-Type", ctype);

        return conn;
    }

    private static URL buildGetUrl(String strUrl, String query) throws IOException {
        URL url = new URL(strUrl);
        if (StringUtils.isEmpty(query)) {
            return url;
        }

        if (StringUtils.isEmpty(url.getQuery())) {
            if (strUrl.endsWith("?")) {
                strUrl = strUrl + query;
            } else {
                strUrl = strUrl + "?" + query;
            }
        } else {
            if (strUrl.endsWith("&")) {
                strUrl = strUrl + query;
            } else {
                strUrl = strUrl + "&" + query;
            }
        }

        return new URL(strUrl);
    }

    public static String buildQuery(Map<String, String> params, String charset) throws IOException {
        if (params == null || params.isEmpty()) {
            return null;
        }

        StringBuilder query = new StringBuilder();
        Set<Entry<String, String>> entries = params.entrySet();
        boolean hasParam = false;

        for (Entry<String, String> entry : entries) {
            String name = entry.getKey();
            String value = entry.getValue() == null ? "" : entry.getValue();
            // 忽略参数名为空的参数，参数值为空需要传递EmptyString
            if (!StringUtils.isEmpty(name)) {
                if (hasParam) {
                    query.append("&");
                } else {
                    hasParam = true;
                }

                query.append(name).append("=").append(URLEncoder.encode(value, charset));
            }
        }

        return query.toString();
    }

    protected static String getResponseAsString(HttpURLConnection conn) throws IOException {
        String charset = getResponseCharset(conn.getContentType());
        InputStream es = conn.getErrorStream();
        if (es == null) {
            return getStreamAsString(conn.getInputStream(), charset);
        } else {
            String msg = getStreamAsString(es, charset);
            if (StringUtils.isEmpty(msg)) {
                throw new IOException(conn.getResponseCode() + ":" + conn.getResponseMessage());
            } else {
                throw new IOException(msg);
            }
        }
    }

    private static String getStreamAsString(InputStream stream, String charset) throws IOException {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, charset));
            StringWriter writer = new StringWriter();

            char[] chars = new char[256];
            int count = 0;
            while ((count = reader.read(chars)) > 0) {
                writer.write(chars, 0, count);
            }

            return writer.toString();
        } finally {
            if (stream != null) {
                stream.close();
            }
        }
    }

    private static String getResponseCharset(String ctype) {
        String charset = DEFAULT_CHARSET;

        if (!StringUtils.isEmpty(ctype)) {
            String[] params = ctype.split(";");
            for (String param : params) {
                param = param.trim();
                if (param.startsWith("charset")) {
                    String[] pair = param.split("=", 2);
                    if (pair.length == 2) {
                        if (!StringUtils.isEmpty(pair[1])) {
                            charset = pair[1].trim();
                        }
                    }
                    break;
                }
            }
        }

        return charset;
    }



    /**
     * 获得http相对路径
     *
     * @param urlString
     * @return
     */
    public static String getRelativeUrl(String urlString) {

        URL url = null;
        String path = null;
        try {
            url = new URL(urlString);
            // 获取路径
            path = url.getPath();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }

        return path;
    }




    /**
     * 测试 POST 请求
     *
     * @param args
     */
//    public static void main(String[] args) throws IOException {
//        // 调用目标URL地址,建议直接配置在配置文件当中,可能是域名或者IP地址,端口号也要单独配置
//        String url = "http://10.100.11.74:8081/message/query/0";
//        Map<String, String> map = new HashMap<>();
//        System.out.println(doPost(url, map));
//
//    }

}
