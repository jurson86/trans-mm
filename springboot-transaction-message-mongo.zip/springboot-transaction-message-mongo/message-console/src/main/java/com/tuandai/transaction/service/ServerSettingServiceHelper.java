package com.tuandai.transaction.service;

import com.alibaba.fastjson.JSON;
import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.bo.ServerCount;

import java.util.*;

public class ServerSettingServiceHelper {


    public static String serverCountMap2Json(Map<MessageState, List<ServerCount>> map) {

        Map<String, List<ServerCount>> resultMap = new HashMap<>();
        // 为了保证数据的准确展示，将不足size的对象回填进map
        for (Map.Entry<MessageState, List<ServerCount>> entity : map.entrySet()) {
            List<ServerCount> list = entity.getValue();
            resultMap.put(String.valueOf(entity.getKey().code()), list);
        }
        return JSON.toJSONString(resultMap);
    }

    public static String serverCountList2Json(List<ServerCount> list) {
        return JSON.toJSONString(list);
    }

}
