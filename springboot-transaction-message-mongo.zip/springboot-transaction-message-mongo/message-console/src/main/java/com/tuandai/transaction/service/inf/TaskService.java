package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.bo.Task;

public interface TaskService {

    void addTaskJob(Task tasks);

    void updateTaskJob(Task task);

    void deleteTaskJob(Long taskId);

    Iterable<Task> queryTaskList();

}
