package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.bo.MessageView;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.common.protocol.body.TopicList;
import org.apache.rocketmq.remoting.exception.RemotingException;

import java.util.List;

public interface RocketService {

    TopicList fetchAllTopicList() throws MQClientException, RemotingException, InterruptedException;

    List<String> fetchDLQTopicList();

    List<MessageView> queryMessageByTopic(final String topic, final long begin, final long end,  int size);


    List<MessageView> queryAllDLQMessage(final long begin, final long end, int size);

    /**
     * 消费消息
     */
    List<MessageView>  consumerMessage(String consumerGroup, String topic, int size);

    /**
     * 修改队列的权限
     */
    void updateTopicPre(String topic);


}
