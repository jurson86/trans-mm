package com.tuandai.transaction.bo;


public class Message {
    private Long transactionId;
    private String serviceName;
    private String createTime;
    private Integer messageType;
    private String messageTopic;
    private String message;
    private Integer messageState;
    private Integer messageSendThreshold;
    private Integer messageSendTimes;
    private String messageNextSendTime;
    private String presendBackUrl;
    private String presendBackMethod;
    private Integer presendBackThreshold;
    private Integer presendBackSendTimes;
    private String presendBackNextSendTime;

    public Long getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(Long transactionId) {
        this.transactionId = transactionId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public Integer getMessageType() {
        return messageType;
    }

    public void setMessageType(Integer messageType) {
        this.messageType = messageType;
    }

    public String getMessageTopic() {
        return messageTopic;
    }

    public void setMessageTopic(String messageTopic) {
        this.messageTopic = messageTopic;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getMessageState() {
        return messageState;
    }

    public void setMessageState(Integer messageState) {
        this.messageState = messageState;
    }

    public Integer getMessageSendThreshold() {
        return messageSendThreshold;
    }

    public void setMessageSendThreshold(Integer messageSendThreshold) {
        this.messageSendThreshold = messageSendThreshold;
    }

    public Integer getMessageSendTimes() {
        return messageSendTimes;
    }

    public void setMessageSendTimes(Integer messageSendTimes) {
        this.messageSendTimes = messageSendTimes;
    }

    public String getMessageNextSendTime() {
        return messageNextSendTime;
    }

    public void setMessageNextSendTime(String messageNextSendTime) {
        this.messageNextSendTime = messageNextSendTime;
    }

    public String getPresendBackUrl() {
        return presendBackUrl;
    }

    public void setPresendBackUrl(String presendBackUrl) {
        this.presendBackUrl = presendBackUrl;
    }

    public String getPresendBackMethod() {
        return presendBackMethod;
    }

    public void setPresendBackMethod(String presendBackMethod) {
        this.presendBackMethod = presendBackMethod;
    }

    public Integer getPresendBackThreshold() {
        return presendBackThreshold;
    }

    public void setPresendBackThreshold(Integer presendBackThreshold) {
        this.presendBackThreshold = presendBackThreshold;
    }

    public Integer getPresendBackSendTimes() {
        return presendBackSendTimes;
    }

    public void setPresendBackSendTimes(Integer presendBackSendTimes) {
        this.presendBackSendTimes = presendBackSendTimes;
    }

    public String getPresendBackNextSendTime() {
        return presendBackNextSendTime;
    }

    public void setPresendBackNextSendTime(String presendBackNextSendTime) {
        this.presendBackNextSendTime = presendBackNextSendTime;
    }
}
