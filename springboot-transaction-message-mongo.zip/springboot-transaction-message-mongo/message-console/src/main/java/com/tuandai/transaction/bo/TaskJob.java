package com.tuandai.transaction.bo;

import com.tuandai.transaction.common.DateUtils;
import com.tuandai.transaction.common.HttpUtils;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import java.io.IOException;
import java.util.Date;

public class TaskJob implements Job {

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        JobDataMap dataMap = jobExecutionContext.getJobDetail().getJobDataMap();
        String jobUrl = dataMap.getString("jobUrl");
        System.out.println("定时任务[time]：" + DateUtils.date2String(new Date()) + ",[URL]:" + jobUrl);
        try {
            String detailResp = HttpUtils.doPost(jobUrl, null);
            System.out.println("定时任务执行的结果是："+ detailResp);
        } catch (IOException e) {
             System.out.println("执行定时任务未知异常");
        }

    }
}
