package com.tuandai.transaction.dao;

import com.tuandai.transaction.bo.ServerCount;
import com.tuandai.transaction.mapper.ServerCountMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
public class ServerCountDao {

    @Autowired
    private ServerCountMapper serverCountMapper;

    @RequestMapping("/save/serverCounts")
    public void save(@RequestParam Iterable<ServerCount> serverCounts){
        // 内存数据库操作
        serverCountMapper.save(serverCounts);
    }


    @RequestMapping("/query/last/list")
    public List<ServerCount> selectLastList(@RequestParam Integer state, @RequestParam String serverIp, @RequestParam Integer limit) {
//        Page<ServerCount> result = serverCountMapper.findByState(state, serverIp,
//                new PageRequest(0, limit, Sort.Direction.DESC, "id"));
        Page<ServerCount> result = serverCountMapper.queryServerCountsByStateAndServerIp(state, serverIp,
                new PageRequest(0, limit, Sort.Direction.DESC, "id"));
        return result.getContent();
    }

    @Transactional
    public void deletedByTime(Date beginTime) {
        serverCountMapper.deletedByTime(beginTime);
    }


}
