package com.tuandai.transaction.dao;

import com.tuandai.transaction.bo.ServerSetting;
import com.tuandai.transaction.mapper.ServerSettingMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;

@RestController
public class ServerSettingDao {

    @Autowired
    private ServerSettingMapper serverSettingMapper;

    @RequestMapping("/findAll")
    public Iterable<ServerSetting> findAll() {
        return this.serverSettingMapper.findAll();
    }

    @RequestMapping("/save/serverSetting")
    public void save(ServerSetting serverSetting){
        // 内存数据库操作
        serverSettingMapper.save(serverSetting);
    }

    @RequestMapping("/set/default")
    @Transactional
    public void setIsDefault(String serverIp) {
        serverSettingMapper.updateServerSetting(serverIp);
    }

    @RequestMapping("/clean/default")
    @Transactional
    public void cleanDefault() {
        serverSettingMapper.cleanDefault();
    }


}
