package com.tuandai.transaction.common;

import com.tuandai.transaction.bo.ServerSetting;
import com.tuandai.transaction.dao.ServerSettingDao;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

@Component
public class Setting implements InitializingBean {

    private Set<String> allServerSettingList = new HashSet<>();

    @Autowired
    private ServerSettingDao serverSettingDao;

    @Value("${current.ip}")
    private String current_port_host;

    public void setCurrentPortHost(String ip) {
        this.current_port_host = ip;
        // 将所有的状态设置为非默认
        serverSettingDao.cleanDefault();
        // 设置为默认
        serverSettingDao.setIsDefault(ip);
    }

    public String getCurrentMessageHost() {
        return current_port_host;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        allServerSettingList.add(current_port_host);
        // 启动的时候加载数据库的配置数据
        Iterable<ServerSetting> list = serverSettingDao.findAll();
        Iterator<ServerSetting> it = list.iterator();
        boolean isExist = false;
        while (it.hasNext()) {
            // 先检查默认数据是否在数据库内
            ServerSetting next = it.next();
            allServerSettingList.add(next.getServerIp());
            if (next.getIsDefault() == 1) {
                current_port_host = next.getServerIp();
            }
            if (current_port_host != null && current_port_host.equals(next.getServerIp())) {
                isExist = true;
            }
        }
        if (!isExist) {
            // 将所有的状态设置为非默认
            serverSettingDao.cleanDefault();
            serverSettingDao.save(new ServerSetting(current_port_host, 1));
        }

    }

    // 获取服务器的所有ip地址配置
    public Set<String> getAllServerSettingList() {
        return allServerSettingList;
    }

    // 刷新缓存
    public void fushSettingList() throws Exception {
        allServerSettingList = new HashSet<>();
        afterPropertiesSet();
    }

    // 检查服务配置是否存在
    public boolean checkServer(String ip) {
       return allServerSettingList.contains(ip);
    }

    // 添加服务配置
    public boolean addSettingServer(String ip) {
        boolean result = allServerSettingList.add(ip);
        // 写到数据库
        serverSettingDao.save(new ServerSetting(ip, 0));
        return result;
    }

}
