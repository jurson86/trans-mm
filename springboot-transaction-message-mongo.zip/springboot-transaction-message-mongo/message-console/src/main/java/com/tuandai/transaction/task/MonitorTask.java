package com.tuandai.transaction.task;

import java.util.Calendar;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.bo.ServerCount;
import com.tuandai.transaction.common.HttpUrlPool;
import com.tuandai.transaction.common.HttpUtils;
import com.tuandai.transaction.common.Setting;
import com.tuandai.transaction.dao.ServerCountDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 监控服务的定时任务
 */
@Component
public class MonitorTask {

    private static final Logger logger = LoggerFactory.getLogger(MonitorTask.class);

    @Autowired
    private Setting setting;

    @Autowired
    private HttpUrlPool httpUrlPool;

    @Autowired
    private ServerCountDao serverCountDao;

    @Scheduled(cron="0/5 * *  * * ? ") // 每5秒钟执行一次
    public void loadMonitorJob() {
        Set<String> serverIpList = setting.getAllServerSettingList();
        final List<ServerCount> serverCounts = new ArrayList<>();
        for (String ip : serverIpList) {
            // 预发送
            String presemdUrl = httpUrlPool.getMessageStateUrl(MessageState.PRESEND.code(), ip);
            // 异常
            String abnormalUrl = httpUrlPool.getMessageStateUrl(MessageState.ABNORMAL.code(), ip);
            // 发送
            String sendUrl = httpUrlPool.getMessageStateUrl(MessageState.SEND.code(), ip);
            // 死亡
            String died = httpUrlPool.getMessageStateUrl(MessageState.DIED.code(), ip);

            Date time = new Date();
            // 请求数据
            try {
                String presemdUrlResp = HttpUtils.doPost(presemdUrl, null);
                Long presemdUrlCount = JSONObject.parseObject(presemdUrlResp).getLong("data");

                String abnormalUrlResp = HttpUtils.doPost(abnormalUrl, null);
                Long abnormalUrlCount = JSONObject.parseObject(abnormalUrlResp).getLong("data");

                String sendUrlResp = HttpUtils.doPost(sendUrl, null);
                Long sendUrlCount = JSONObject.parseObject(sendUrlResp).getLong("data");

                String diedResp = HttpUtils.doPost(died, null);
                Long diedCount = JSONObject.parseObject(diedResp).getLong("data");

                serverCounts.add(new ServerCount(time, presemdUrlCount, MessageState.PRESEND.code(), ip));
                serverCounts.add(new ServerCount(time, abnormalUrlCount, MessageState.ABNORMAL.code(), ip));
                serverCounts.add(new ServerCount(time, sendUrlCount, MessageState.SEND.code(), ip));
                serverCounts.add(new ServerCount(time, diedCount, MessageState.DIED.code(), ip));
            } catch (IOException e) {
                logger.error("调用查询状态数量未知异常", e);
            }

        }
        if (!CollectionUtils.isEmpty(serverCounts)) {
            System.out.println("本次查询的数量是："+serverCounts);
            // 入库
            serverCountDao.save(new Iterable<ServerCount>() {
                @Override
                public Iterator<ServerCount> iterator() {
                    return serverCounts.iterator();
                }
            } );
            // 清空数据
            serverCounts.clear();
        }

    }

    // 每两个小时删除一次
    @Scheduled(cron=" 0 0 0/2 * * ? ") // 每2小时执行一次
   // @Scheduled(cron=" 0 0/1 * * * ? ") // 每2小时执行一次
    public void deletedData() {
        System.out.println("执行删除2小时数据任务");
        Calendar cal = Calendar. getInstance ();
        cal.set(Calendar.HOUR , cal.get(Calendar.HOUR) - 2 ) ; //把时间设置为当前时间-1小时，同理，也可以设置其他时间
        //cal.set(Calendar.MINUTE , cal.get(Calendar.MINUTE) - 2 ) ;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        System.out.println("当前时间:"+ dateFormat.format(new Date()) +
        "beginTime:" + dateFormat.format(cal.getTime()));
        serverCountDao.deletedByTime(cal.getTime());
    }

}
