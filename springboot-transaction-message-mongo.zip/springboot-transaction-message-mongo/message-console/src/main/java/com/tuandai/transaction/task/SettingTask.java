package com.tuandai.transaction.task;


import com.tuandai.transaction.common.Setting;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SettingTask {

    private static final Logger logger = LoggerFactory.getLogger(MonitorTask.class);

    @Autowired
    private Setting setting;


    @Scheduled(cron="0/5 * *  * * ? ") // 每5秒钟执行一次
    public void loadMonitorJob() throws Exception {
        setting.fushSettingList();
    }

}
