package com.tuandai.transaction.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {

    private final static SimpleDateFormat SIMPLE_DATE_FORMAT =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    public static String date2String(Date date) {
        return SIMPLE_DATE_FORMAT.format(date);
    }

    // 当前时间相隔多少day， hour， minute， second （可以为负数）
    public static Date dateGap(int day, int hour, int minute, int second) {
        Calendar cal = Calendar. getInstance ();
        cal.set(Calendar.DATE, cal.get(Calendar.DATE) + day) ; //把时间设置为当前时间-1小时，同理，也可以设置其他时间
        cal.set(Calendar.HOUR , cal.get(Calendar.HOUR) + hour) ;
        cal.set(Calendar.MINUTE , cal.get(Calendar.MINUTE) + minute) ;
        cal.set(Calendar.SECOND , cal.get(Calendar.SECOND) + second) ;
        return cal.getTime();
    }

}
