package com.tuandai.transaction.bo;

public class MessageResp {

    private Integer status;

    private Message data;

    public MessageResp(Integer status, Message data) {
        this.status = status;
        this.data = data;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Message getData() {
        return data;
    }

    public void setData(Message data) {
        this.data = data;
    }
}
