package com.tuandai.transaction.viewAndController;

import com.tuandai.transaction.common.HttpUrlPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

@Controller
public class WelcomeController {

    private static final Logger logger = LoggerFactory.getLogger(WelcomeController.class);

    @Value("${ws:weqw}")
    private String message1;

    @Autowired
    private HttpUrlPool httpUrlPool;



    @RequestMapping("/")
    public String welcome(Map<String, Object> modle) {

        modle.put("message", message1);

        return "swagger-ui";
    }

    @RequestMapping(value = "/query/message/list")
    public String queryTables() {
        return "message-list2";
    }


    @RequestMapping(value="/task/setting")
    public String taskSetting() {

        return "task-setting";
    }

    @RequestMapping(value = "/rocket/message")
    public String message() {
        return "rocket-queue";
    }





}
