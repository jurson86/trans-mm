package com.tuandai.transaction.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.bo.*;
import com.tuandai.transaction.common.HttpUrlPool;
import com.tuandai.transaction.common.HttpUtils;
import com.tuandai.transaction.common.Setting;
import com.tuandai.transaction.service.ServerSettingServiceHelper;
import com.tuandai.transaction.service.inf.ServerSettingService;
import com.tuandai.transaction.service.inf.TaskService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;


@RestController
@RequestMapping(value = "/api")
public class ApiController {

	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);

	@Autowired
	private HttpUrlPool httpUrlPool;

	@Autowired
	private Setting setting;

	@Autowired
	private ServerSettingService serverSettingService;

	@Autowired
	private TaskService taskService;

	// 通过http的方法调用对应的服务
	@RequestMapping(value = "/message/monitor/", method = RequestMethod.POST)
	public String queryMessageByState(@RequestParam int state, @RequestParam String ip) {
		String url = httpUrlPool.getMessageStateUrl(state, ip);

		String resp = null;
		try {
			resp = HttpUtils.doPost(url, null);
			System.out.println("返回结果"+resp);
		} catch (IOException e) {
			logger.error("调用" + url + "未知异常", e);
		}
		return resp;
	}


	@RequestMapping(value = "/message/query/", method = RequestMethod.POST)
	public String queryMessageListByState(HttpServletRequest request, HttpServletResponse response) {
		String stateStr = request.getParameter("state");
		String searchString = request.getParameter("searchString");
		Integer state = Integer.valueOf(searchString != null ? searchString : stateStr);
		String url = httpUrlPool.getMsgListUrl(state);
		String resp = null;
		try {
			resp = HttpUtils.doPost(url, null);
		} catch (IOException e) {
			logger.error("调用" + url + "未知异常", e);
		}
		if (resp == null) {
			if (state == 10) {
				// 测试数据
				resp = "{\"status\": 200,\"data\":[ { \"transactionId\": \"138033665468080128\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 11,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}, {\"transactionId\": \"136617105297838082\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 30,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}, { \"transactionId\": \"136617105297838083\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 21,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}]}";

			} else if (state == 11) {
				// 测试数据
				resp = "{\"status\": 200,\"data\":[ { \"transactionId\": \"111111111\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 11,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}, {\"transactionId\": \"222222222\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 30,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}, { \"transactionId\": \"333333333333333\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 30,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}]}";
			}
		}
		return resp;
	}

	@RequestMapping(value = "/save/edit", method = RequestMethod.POST)
	public String edit(HttpServletRequest request, HttpServletResponse response) {
		String oper = request.getParameter("oper");
		String transactionIds = request.getParameter("transactionId"); // transactionId
		if (oper.equals("edit")) {
			// 更改消息
			String stateStr = request.getParameter("messageState");
			// 查询消息详情查到老状态
			String url = httpUrlPool.getMsgStateUrl(transactionIds);
			MessageState state = MessageState.findByDes(stateStr);
			String doUrl = null;
			String deilResp = null;
			String resp = null;
			try {
				deilResp = HttpUtils.doPost(url, null);
				JSONObject jsonObject = JSONObject.parseObject(deilResp);
				int oldMessageState = jsonObject.getJSONObject("data").getInteger("messageState");
				if (oldMessageState == MessageState.ABNORMAL.code()) { // 异常消息
					doUrl = httpUrlPool.getMsgAbnormalUrl(String.valueOf(state.code()));
				} else if (oldMessageState == MessageState.DIED.code()) { // 死亡消息
					doUrl = httpUrlPool.getMsgDiedUrl(String.valueOf(state.code()));
				} else {
					return  "fail";
				}

				DefaultHttpClient httpClient = new DefaultHttpClient();
				HttpPost post = new HttpPost(doUrl);
				StringEntity postingString = new StringEntity(transactionIds);// json传递
				post.setEntity(postingString);
					post.setHeader("Content-type", "application/json");
				CloseableHttpResponse responseww = httpClient.execute(post);
				logger.info("人工干预接口返回值："+responseww.getEntity());
				logger.info("人工干预接口返回值2："+responseww.getStatusLine());
				if (responseww.getEntity() != null) {
					System.out.println("Response content length: " + responseww.getEntity().getContentLength());
					System.out.println(EntityUtils.toString(responseww.getEntity()));
					EntityUtils.consume(responseww.getEntity());
				}
			} catch (IOException e) {
				logger.error("调用[ " + url + " ]/[ " + doUrl+" ]未知异常", e);
			}
			return "success";
		} else if (oper.equals("del")) {
			transactionIds = request.getParameter("id");
			return discardMsgByIds(transactionIds);
		}
		return "success";
	}

	private String discardMsgByIds(String transactionIds) {
		// 废弃消息
		String url = httpUrlPool.getMsgDiscardUrl();
		String resp = null;
		try {
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost post = new HttpPost(url);
			// json化
			StringEntity postingString =  new StringEntity(transactionIds);// json传递
			post.setEntity(postingString);
			post.setHeader("Content-type", "application/json");
			try {
				CloseableHttpResponse responseww = httpClient.execute(post);
			} catch (IOException e) {
				logger.error("调用[ " + url + " ]未知异常", e);
			}
			return "success";
		} catch (IOException e) {
			logger.error("调用" + url + "未知异常", e);
		}
		return "error";
	}


	@RequestMapping(value = "/resend/",method = RequestMethod.POST)
	public String resendMsg(@RequestParam String transactionIds) {
		if (StringUtils.isEmpty(transactionIds)) {
			return "fail";
		}
		String url = httpUrlPool.getMsgResendUrl();
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost post = new HttpPost(url);
		// json化
		try {
			StringEntity postingString =  new StringEntity("\""+ transactionIds+"\"");// json传递
			post.setEntity(postingString);
			post.setHeader("Content-type", "application/json");
			CloseableHttpResponse responseww = httpClient.execute(post);
			logger.info("重发消息返回结果：" + responseww);
		} catch (IOException e) {
			logger.error("调用" + url + "未知异常", e);
		}
		return "success";
	}

	@RequestMapping(value = "/detail/", method = RequestMethod.POST)
	public String getMsgDetail(@RequestParam String transactionId) {
        String url = httpUrlPool.getMsgDetailUrl(transactionId);
		String stateUrl = httpUrlPool.getMsgStateUrl(transactionId);
        try {
        	// 查询消息详情，只有发送及以后的状态才能查到
            String detailResp = HttpUtils.doPost(url, null);
            // 查询消息状态
			String stateResp = HttpUtils.doPost(stateUrl, null);

			JSONObject stateRespObject = JSONObject.parseObject(stateResp);
			Message stateMessage  = stateRespObject.getObject("data", Message.class); //.getInteger("messageState")

			JSONObject detailRespObject = JSONObject.parseObject(detailResp);
			Message detailMessage = detailRespObject.getObject("data", Message.class); //.getInteger("messageState")

			if (stateMessage != null) {
				// 如果查询到状态那么是非完成和废弃的
				if (detailMessage == null) { // 如果是预发送那么直接返回
					return stateResp;
				} else {
					// 如果是其他状态则平凑
					stateMessage.setMessage(detailMessage.getMessage());
					return JSON.toJSONString(new MessageResp(200, stateMessage));
				}
			} else {
				return detailResp;
			}
            //String detailResp = "{\"status\": 200,\"data\":{ \"transactionId\": \"138033665468080128\",\"serviceName\": \"pro\",\"createTime\": \"2017-11-13 11:47:36\",\"messageType\": 0,\"messageTopic\": \"ProducerTestTopic\",\"message\": {\"name\":\"test producer!\",\"title\":\"hello world\"},\"messageState\": 11,\"messageSendThreshold\": 10,\"messageSendTimes\": 1,\"messageNextSendTime\": \"2017-11-13 11:47:45\",\"presendBackUrl\": \"http://10.100.12.82:8093/msg/messageid/check\",\"presendBackMethod\": \"POST\",\"presendBackThreshold\": 6,\"presendBackSendTimes\": 0,\"presendBackNextSendTime\": \"2017-11-13 11:47:44\",\"resultBackUrl\": \"\",\"resultBackMethod\": \"POST\",\"resultBackThreshod\": 3,\"resultBackNextSendTime\": \"2017-11-13 11:47:36\",\"result\": \"\",\"expectResult\": \"a\",\"over\": true}}";
        } catch (Exception e) {
            logger.error("调用" + url + "未知异常", e);
        }
        return "fail";
    }

	@RequestMapping(value = "/setting/check/", method = RequestMethod.POST)
	public String setServerSettingCheck(@RequestParam String ip) {
		if (!setting.checkServer(ip)) {
			return "success";
		} else {
			return "fail";
		}
	}


	@RequestMapping(value = "/setting/server/", method = RequestMethod.POST)
    public String setServerSetting(@RequestParam String ip) {
    	return setting.addSettingServer(ip) ? "success":"fail";
	}


	@RequestMapping(value = "/select", method = RequestMethod.GET)
	public String getSelectList(@RequestParam String messageState) {
		if (messageState.equals(String.valueOf(MessageState.ABNORMAL.code()))) { // 异常->预发送，废弃
			return  "<select><option value=\"10\">预发送</option><option value=\"100\">废弃</option></select>";
		} else if (messageState.equals(String.valueOf(MessageState.DIED.code()))) { // 死亡->发送，废弃
			return  "<select><option value=\"30\">完成</option><option value=\"100\">废弃</option></select>";
		}
		return "fail";
	}

	@RequestMapping(value = "/setting/select/", method = RequestMethod.GET)
	public String getAllServerSettingList() {
		Set<String> set = setting.getAllServerSettingList();
		String currentIp = setting.getCurrentMessageHost();

		if (!CollectionUtils.isEmpty(set)) {
			String result = "[";
			for (String  ip : set) {
				result = result + "{\"key\":\""+ ip + "\", \"isDefault\":" + ip.equals(currentIp) + "},";
			}
			result = result.substring(0, result.length() -1);
			result = result + "]";
			return  result;
		} else {
			return "[]";
		}
	}

	@RequestMapping(value = "/setting/default/get", method = RequestMethod.GET)
	public String getCurrentServer() {
		String ip = setting.getCurrentMessageHost();
		return "{" + "\"data\":{ \"server\":" + ip + "}}";
	}

	@RequestMapping(value = "/setting/default/set", method = RequestMethod.POST)
	public String setCurrentServer(@RequestParam String ip) {
		setting.setCurrentPortHost(ip);
		return "success";
	}

	@RequestMapping(value = "/select/initData/list", method = RequestMethod.GET)
	public String getInitData(@RequestParam String ip, @RequestParam int size) {
		Map<MessageState, List<ServerCount>> map = serverSettingService.queryLastServerCountList(ip, size);
		return ServerSettingServiceHelper.serverCountMap2Json(map);
	}

	@RequestMapping(value = "/select/lastData/list", method = RequestMethod.GET)
	public String getServerCountByIpAndStateAndSize(@RequestParam String ip, @RequestParam int size, @RequestParam int state) {
		List<ServerCount> list = serverSettingService.queryLastServerCountList(ip, size, state);
		return ServerSettingServiceHelper.serverCountList2Json(list);
	}

	@RequestMapping(value = "/save/task", method = RequestMethod.POST)
	public String addTask(HttpServletRequest request, HttpServletResponse response) {
		String oper = request.getParameter("oper");

		if (oper.equals("del")) {
			String taskIdStr = request.getParameter("id").trim();
			Long taskId = Long.valueOf(taskIdStr);
			taskService.deleteTaskJob(taskId);
		} else {
			String pauseStr = request.getParameter("pause").trim();
			String cron = request.getParameter("cron").trim();
			String taskUrl = request.getParameter("taskUrl").trim();


			if (oper.equals("edit")) { // 如果是编辑模式
				String taskIdStr = request.getParameter("id").trim();
				Long taskId = Long.valueOf(taskIdStr);
				Task task = new Task(Integer.valueOf(pauseStr), cron, new Date(), taskUrl);
				task.setId(taskId);
				taskService.updateTaskJob(task);
			} else { // 如果是add模式
				taskService.addTaskJob(new Task(Integer.valueOf(pauseStr), cron, new Date(), taskUrl));
			}
		}

		return "success";
	}

	@RequestMapping(value = "/query/task/list", method = RequestMethod.GET)
	public String queryTaskList() {
		Iterable<Task> taskList = taskService.queryTaskList();
		Iterator<Task> it = taskList.iterator();
		List<Task> list = new ArrayList<>();
		while (it.hasNext()) {
			Task next = it.next();
			list.add(next);
		}
		return JSON.toJSONString(list);
	}


    @ApiOperation(value = "測試", notes = "hello world")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "name", value = "名字", paramType = "query", dataType = "string")
    })
	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public HashMap<String, Object> get(@RequestParam String name) {
		
    	logger.info("get: {}",name);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("title", "hello world");
		map.put("name", name);
		
		return map;
	}
	
}