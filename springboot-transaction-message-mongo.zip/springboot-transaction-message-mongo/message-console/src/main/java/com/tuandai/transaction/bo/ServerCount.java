package com.tuandai.transaction.bo;


import io.swagger.models.auth.In;

import javax.persistence.*;
import java.util.Date;

@Entity
public class ServerCount {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(name = "time")
    private Date time;

    @Column(name = "COUNT")
    private Long count;

    @Column(name="state")
    private Integer state;

    @Column(name = "server_Ip")
    private String serverIp;

    public ServerCount() {
    }

    public ServerCount(Date time, Long count, Integer state, String serverIp) {
        this.time = time;
        this.count = count;
        this.state = state;
        this.serverIp = serverIp;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "ServerCount{" +
                "id=" + id +
                ", time=" + time +
                ", count=" + count +
                ", state=" + state +
                ", serverIp='" + serverIp + '\'' +
                '}';
    }
}
