package com.tuandai.transaction.service;

import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.bo.ServerCount;
import com.tuandai.transaction.dao.ServerCountDao;
import com.tuandai.transaction.dao.ServerSettingDao;
import com.tuandai.transaction.service.inf.ServerSettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ServerSettingServiceImpl implements ServerSettingService {

    @Autowired
    private ServerSettingDao serverSettingDao;

    @Autowired
    private ServerCountDao serverCountDao;

    @Override
    public Map<MessageState, List<ServerCount>> queryLastServerCountList(String serverIp, Integer size) {
        // 只查询 预发送， 异常，发送，死亡的
        List<ServerCount> presendList = serverCountDao.selectLastList(MessageState.PRESEND.code(), serverIp, size);
        List<ServerCount> abnormalList = serverCountDao.selectLastList(MessageState.ABNORMAL.code(), serverIp, size);
        List<ServerCount> sendList = serverCountDao.selectLastList(MessageState.SEND.code(), serverIp, size);
        List<ServerCount> diedList = serverCountDao.selectLastList(MessageState.DIED.code(), serverIp, size);

        Map<MessageState, List<ServerCount>> map = new HashMap<>();

        map.put(MessageState.PRESEND, presendList);
        map.put(MessageState.ABNORMAL, abnormalList);
        map.put(MessageState.SEND, sendList);
        map.put(MessageState.DIED, diedList);

        return map;
    }

    @Override
    public List<ServerCount> queryLastServerCountList(String serverIp, Integer size, int state) {
        List<ServerCount> presendList = serverCountDao.selectLastList(state, serverIp, size);
        return presendList;
    }
}
