package com.tuandai.transaction.bo;

import javax.persistence.*;
import java.util.Date;

@Entity(name = "task")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    private String taskUrl;

    @Column
    private int parse;

    @Column
    private String cron;

    @Column
    private Date createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTaskUrl() {
        return taskUrl;
    }

    public void setTaskUrl(String taskUrl) {
        this.taskUrl = taskUrl;
    }

    public int getParse() {
        return parse;
    }

    public void setParse(int parse) {
        this.parse = parse;
    }

    public String getCron() {
        return cron;
    }

    public void setCron(String cron) {
        this.cron = cron;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Task() {
    }

    public Task(int parse, String cron, Date createTime, String taskUrl) {
        this.parse = parse;
        this.cron = cron;
        this.createTime = createTime;
        this.taskUrl = taskUrl;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", taskUrl='" + taskUrl + '\'' +
                ", parse=" + parse +
                ", cron='" + cron + '\'' +
                ", createTime=" + createTime +
                '}';
    }
}
