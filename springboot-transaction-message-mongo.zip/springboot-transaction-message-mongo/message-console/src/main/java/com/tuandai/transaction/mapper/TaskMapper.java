package com.tuandai.transaction.mapper;

import com.tuandai.transaction.bo.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TaskMapper extends JpaRepository<Task, Long> {

    @Modifying
    @Query("update task set taskUrl=:taskUrl, parse=:parse, cron=:cron where id=:id")
    void updateTask(@Param("id") Long id, @Param("taskUrl") String taskUrl,
                    @Param("parse") int parse, @Param("cron") String cron);
}
