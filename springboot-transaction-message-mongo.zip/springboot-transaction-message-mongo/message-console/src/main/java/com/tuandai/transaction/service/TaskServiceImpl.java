package com.tuandai.transaction.service;

import com.alibaba.fastjson.JSON;
import com.tuandai.transaction.bo.JobState;
import com.tuandai.transaction.bo.Task;
import com.tuandai.transaction.bo.TaskJob;
import com.tuandai.transaction.common.QuartzManager;
import com.tuandai.transaction.dao.TaskDao;
import com.tuandai.transaction.service.inf.TaskService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


@Service
public class TaskServiceImpl implements TaskService, InitializingBean {

    private Map<Long, Task> map = new HashMap<>();

    private Map<Long, String> mapJob = new HashMap<>();

    @Autowired
    private TaskDao taskDao;


    @Override
    public void addTaskJob(Task task){
        taskDao.save(task);
        map.put(task.getId(), task);
        // 启动一个job
        addJob(task);
    }


    public void addJob(Task task) {
        // 判断当前任务的执行时间，创建定时任务开始执行
        String jobName = "task_" + task.getId();
        String groupName = "task_group_" + task.getId();
        String triggerName = "task_trigger_name_" +  task.getId();
        String triggerGroupName = "triggerGroupName_" +  task.getId();
        QuartzManager.addJob(jobName, groupName, triggerName, triggerGroupName, TaskJob.class, task.getCron(), task.getTaskUrl());
        if (task.getParse() == JobState.PAUSE.code()) { // 如果是暂停任务则暂停任务
            QuartzManager.pauseJob(jobName, groupName);
        }

        HashMap<String, String> tmp  = new HashMap<>();
        tmp.put("jobName", jobName);
        tmp.put("groupName", groupName);
        tmp.put("triggerName", triggerName);
        tmp.put("triggerGroupName", triggerGroupName);
        // 记录taskId和job的相关信息，以方便后面的操作
        mapJob.put(task.getId(), JSON.toJSONString(tmp));
    }

    @Override
    public void updateTaskJob(Task task) {
        Task oldTask = taskDao.queryTaskById(task.getId());
        taskDao.updateTask(task);
        map.put(task.getId(), task);

        // 修改相应的定时任务

        boolean ismodify = false;
        // 比较表达式字段
        String cron = task.getCron();
        String oldCron = oldTask.getCron();
        if (!cron.equals(oldCron)) {
            ismodify = true;
        }
        // 比较url字段
        String url = task.getTaskUrl().trim();
        String oldUrl = oldTask.getTaskUrl().trim();
        if (!url.equals(oldUrl)) {
            ismodify = true;
        }

        String taskJson = mapJob.get(task.getId());
        HashMap<String, String> tmp = JSON.parseObject(taskJson, HashMap.class);
        String jobName = tmp.get("jobName");
        String groupName = tmp.get("groupName");
        String triggerName = tmp.get("triggerName");
        String triggerGroupName = tmp.get("triggerGroupName");

        // 如果被修改了那么删除一个任务重新创建一个任务
        if (ismodify) {
            QuartzManager.removeJob(jobName, groupName, triggerName, triggerGroupName);
            QuartzManager.addJob(jobName, groupName, triggerName, triggerGroupName, TaskJob.class, cron, url);
        }

        // 比较暂停字段
        if (task.getParse() != oldTask.getParse()) {
            if (task.getParse() == JobState.PAUSE.code()) {
                QuartzManager.pauseJob(jobName, groupName);
            } else {
                QuartzManager.resumeJob(jobName, groupName);
            }
        }
    }

    @Override
    public void deleteTaskJob(Long taskId) {
        map.remove(taskId);
        // 删除表中的数据
        taskDao.deleteTaskById(taskId);

        String taskJson = mapJob.get(taskId);
        HashMap<String, String> tmp = JSON.parseObject(taskJson, HashMap.class);
        String jobName = tmp.get("jobName");
        String groupName = tmp.get("groupName");
        String triggerName = tmp.get("triggerName");
        String triggerGroupName = tmp.get("triggerGroupName");

        QuartzManager.removeJob(jobName, groupName, triggerName,  triggerGroupName);

    }

    @Override
    public Iterable<Task> queryTaskList() {
        return taskDao.queryTaskList();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        Iterable<Task> its = taskDao.queryTaskList();
        Iterator<Task> it = its.iterator();
        // 启动的时候将数组添加到内存中
        while (it.hasNext()) {
            Task task = it.next();
            map.put(task.getId(), task);
            // 启动所以的任务
            addJob(task);
        }
    }

    public Map<Long, Task> getTaskMap() {
        return map;
    }
}
