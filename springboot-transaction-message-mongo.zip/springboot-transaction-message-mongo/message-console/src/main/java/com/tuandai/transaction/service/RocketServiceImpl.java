package com.tuandai.transaction.service;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.tuandai.transaction.bo.MessageView;
import com.tuandai.transaction.service.inf.RocketService;
import org.apache.rocketmq.client.ClientConfig;
import org.apache.rocketmq.client.consumer.DefaultMQPullConsumer;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.PullResult;
import org.apache.rocketmq.client.consumer.PullStatus;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.client.consumer.store.RemoteBrokerOffsetStore;
import org.apache.rocketmq.client.exception.MQBrokerException;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.impl.MQClientManager;
import org.apache.rocketmq.client.impl.factory.MQClientInstance;
import org.apache.rocketmq.common.MixAll;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.common.message.MessageQueue;
import org.apache.rocketmq.common.protocol.body.TopicList;
import org.apache.rocketmq.remoting.exception.RemotingException;
import org.apache.rocketmq.tools.admin.DefaultMQAdminExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.Max;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class RocketServiceImpl implements RocketService, InitializingBean {

    private static final Logger logger = LoggerFactory.getLogger(RocketServiceImpl.class);

    Pattern pattern = Pattern.compile("^%DLQ%");


    RemoteBrokerOffsetStore remoteBrokerOffsetStore;

    @Value("${rocketmq.config.namesrvAddr}")
    private String addr;

    @Override
    public TopicList fetchAllTopicList() {
        DefaultMQAdminExt defaultMQAdminExt = new DefaultMQAdminExt();
        TopicList list = null;
        try {
            defaultMQAdminExt.start();
            list = defaultMQAdminExt.fetchAllTopicList();
        } catch (Exception e) {
            logger.error("rocketMq fetchAllTopicList 查询未知异常", e);
        } finally {
            defaultMQAdminExt.shutdown();
        }
        return list;
    }

    @Override
    public List<String> fetchDLQTopicList() {
        TopicList result = fetchAllTopicList();
        if (result == null || CollectionUtils.isEmpty(result.getTopicList())) {
            return null;
        }

        List<String> list = new ArrayList<>();
        for (String topic : result.getTopicList()) {
            Matcher matcher = pattern.matcher(topic);
            if(matcher.find()) {
                list.add(topic);
            }
        }

        return list;
    }



    @Override
    public List<MessageView> queryMessageByTopic(String topic, long begin, long end, int size) {
        List<MessageView> messageViewList = Lists.newArrayList();
        DefaultMQPullConsumer consumer = null;
        try {
            consumer = new DefaultMQPullConsumer(MixAll.TOOLS_CONSUMER_GROUP, null);
            consumer.start();
            Set<MessageQueue> mqs = consumer.fetchSubscribeMessageQueues(topic);
            for (MessageQueue mq : mqs) {
                List<MessageView> list = getMessageByQueue(consumer, mq, begin, end, size);
                messageViewList.addAll(list);
                size = size - list.size();
                if (size <= 0) {
                   return  messageViewList;
                }
            }
        }catch (Exception e) {
            logger.error("rocketMq queryMessageByTopic 查询未知异常");
        } finally {
            consumer.shutdown();
        }
        System.out.print("================================== " + messageViewList.size());
        return messageViewList;
    }


    private List<MessageView> getMessageByQueue(DefaultMQPullConsumer consumer, MessageQueue messageQueue, long begin, long end , int size) {
        List<MessageView> list = new ArrayList<>();
        try {
            long minOffset = consumer.searchOffset(messageQueue, begin);
            long maxOffset = consumer.searchOffset(messageQueue, end);
            //MQClientInstance fax = MQClientManager.getInstance().getAndCreateMQClientInstance(consumer, null);
            //RemoteBrokerOffsetStore offsetStore = new RemoteBrokerOffsetStore(fax, MixAll.TOOLS_CONSUMER_GROUP);
            //RemoteBrokerOffsetStore s = new RemoteBrokerOffsetStore();
            //consumer.updateConsumeOffset(messageQueue, 2);
            //offsetStore.updateConsumeOffsetToBroker(messageQueue, 2, false);

            // 读取远程的消费 偏移量
            long remoteOffset = consumer.fetchConsumeOffset(messageQueue, true);
            minOffset = minOffset < remoteOffset ? remoteOffset : minOffset;
            if (remoteOffset > maxOffset) {
                 return list;
            }

            String subExpression = "*";
            for (long offset = minOffset; offset <= maxOffset;) {
                int count = (size - list.size()) > 32 ? 32 : (size - list.size());
                if (count == 0) {
                    return list;
                }
                // 每次最多拉32条
                PullResult pullResult = consumer.pull(messageQueue, subExpression, offset, count);
                offset = pullResult.getNextBeginOffset();
                switch (pullResult.getPullStatus()) {
                    case FOUND:
                        List<MessageView> messageViewListByQuery = Lists.transform(pullResult.getMsgFoundList(), new Function<MessageExt, MessageView>() {
                            @Override
                            public MessageView apply(MessageExt messageExt) {
                                messageExt.setBody(null);
                                return MessageView.fromMessageExt(messageExt);
                            }
                        });
                        List<MessageView> filteredList = Lists.newArrayList(Iterables.filter(messageViewListByQuery, new Predicate<MessageView>() {
                            @Override
                            public boolean apply(MessageView messageView) {
                                if (messageView.getStoreTimestamp() < begin || messageView.getStoreTimestamp() > end) {
                                    logger.info("begin={} end={} time not in range {} {}", begin, end, messageView.getStoreTimestamp(), new Date(messageView.getStoreTimestamp()).toString());
                                }
                                return messageView.getStoreTimestamp() >= begin && messageView.getStoreTimestamp() <= end;
                            }
                        }));
                        list.addAll(filteredList);
                        break;
                    case NO_MATCHED_MSG:
                    case NO_NEW_MSG:
                    case OFFSET_ILLEGAL:
                        return list;
                }
            }
        } catch (Exception e) {
            logger.error("rocketMq queryMessageByTopic 查询未知异常", e);
        }
        return list;
    }


    @Override
    public List<MessageView> queryAllDLQMessage(long begin, long end, int size) {
        List<String> topicList = fetchDLQTopicList();
        if (CollectionUtils.isEmpty(topicList)) {
            return null;
        }
        List<MessageView> result = new ArrayList<>();
        for (String topic : topicList) {
            if (result.size() >= 500) {
                break;
            }
            List<MessageView> list = queryMessageByTopic(topic, begin, end, size);
            result.addAll(list);
        }
        return result;
    }

    public List<MessageView> consumerMessageByQueue(RemoteBrokerOffsetStore remoteBrokerOffsetStore, DefaultMQPullConsumer consumer, MessageQueue messageQueue, int size) {
        List<MessageView> list = new ArrayList<>();
        String subExpression = "*";
        try {
            long remoteOffset = consumer.fetchConsumeOffset(messageQueue, true);
            LABLE:
            while (true) {
                int count = (size - list.size()) > 32 ? 32 : (size - list.size());
                if (count == 0) { // 读满，且队列还有剩余
                    // 设置坐标
                    remoteBrokerOffsetStore.updateConsumeOffsetToBroker(messageQueue, remoteOffset, false);
                    return list;
                }
                // 每次最多拉32条
                PullResult pullResult = consumer.pull(messageQueue, subExpression, remoteOffset, count);
                long preRemoteOffset = remoteOffset;
                remoteOffset = pullResult.getNextBeginOffset();
                switch (pullResult.getPullStatus()) {
                    case FOUND:
                        List<MessageView> messageViewListByQuery = Lists.transform(pullResult.getMsgFoundList(), new Function<MessageExt, MessageView>() {
                            @Override
                            public MessageView apply(MessageExt messageExt) {
                                messageExt.setBody(null);
                                return MessageView.fromMessageExt(messageExt);
                            }
                        });
                        list.addAll(messageViewListByQuery);
                        // 设置远程offset坐标
                        if (messageViewListByQuery.size() < count) { // 最后一波且不够读
                            // 设置
                            long currentOffset = preRemoteOffset + messageViewListByQuery.size();
                            remoteBrokerOffsetStore.updateConsumeOffsetToBroker(messageQueue, currentOffset, false);
                        }
                        break;
                    case NO_MATCHED_MSG:
                    case NO_NEW_MSG:
                    case OFFSET_ILLEGAL:
                        break LABLE;
                }
            }
        } catch (MQClientException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (RemotingException e) {
            e.printStackTrace();
        } catch (MQBrokerException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<MessageView>  consumerMessage(String consumerGroup, String topic, int size) {
        List<MessageView> messageViewList = Lists.newArrayList();
        DefaultMQPullConsumer consumer = null;
        try {
            consumer = new DefaultMQPullConsumer(MixAll.TOOLS_CONSUMER_GROUP, null);
            consumer.start();
            Set<MessageQueue> mqs = consumer.fetchSubscribeMessageQueues(topic);

            MQClientInstance fax = MQClientManager.getInstance().getAndCreateMQClientInstance(consumer, null);
            RemoteBrokerOffsetStore offsetStore = new RemoteBrokerOffsetStore(fax, MixAll.TOOLS_CONSUMER_GROUP);

            for (MessageQueue mq : mqs) {
                List<MessageView> list = consumerMessageByQueue(offsetStore, consumer, mq, size);
                messageViewList.addAll(list);
                size = size - list.size();
                if (size <= 0) {
                    break;
                }
            }
        }catch (Exception e) {
            logger.error("rocketMq queryMessageByTopic 查询未知异常");
        } finally {
            consumer.shutdown();
        }
        return messageViewList;
    }

    @Override
    public void updateTopicPre(String topic) {

    }



    @Override
    public void afterPropertiesSet() {

        DefaultMQPullConsumer consumer = new DefaultMQPullConsumer(MixAll.TOOLS_CONSUMER_GROUP, null);
        try {
            consumer.start();

            MQClientInstance fax = MQClientManager.getInstance().getAndCreateMQClientInstance(consumer, null);
            RemoteBrokerOffsetStore offsetStore = new RemoteBrokerOffsetStore(fax, MixAll.TOOLS_CONSUMER_GROUP);
            Set<MessageQueue> mqs = consumer.fetchSubscribeMessageQueues("%DLQ%transaction-group2");

            for (MessageQueue mq : mqs) {
                offsetStore.updateConsumeOffsetToBroker(mq, 0, false);
                long remoteOffset = consumer.fetchConsumeOffset(mq, true);
                System.out.print(remoteOffset);
            }
        } catch (MQClientException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (RemotingException e) {
            e.printStackTrace();
        } catch (MQBrokerException e) {
            e.printStackTrace();
        } finally {
            consumer.shutdown();
        }


    }
}
