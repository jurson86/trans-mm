package com.tuandai.transaction.mapper;

import com.tuandai.transaction.bo.ServerSetting;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ServerSettingMapper extends CrudRepository<ServerSetting, Long> {


    @Modifying
    @Query("update ServerSetting set isDefault = 0")
    void cleanDefault();

    @Modifying
    @Query("update ServerSetting set isDefault = 1 where serverIp=:serverIp")
    void updateServerSetting(@Param("serverIp") String serverIp);

}
