package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.bo.ServerCount;

import java.util.List;
import java.util.Map;


/**
 * 服务器配置相隔的服务
 */
public interface ServerSettingService {

    // 查询每个状态下固定size条最新的数据
    // 特定接口，专给初始化用
    Map<MessageState, List<ServerCount>> queryLastServerCountList(String serverIp, Integer size);

    List<ServerCount> queryLastServerCountList(String serverIp, Integer size, int state);

}
