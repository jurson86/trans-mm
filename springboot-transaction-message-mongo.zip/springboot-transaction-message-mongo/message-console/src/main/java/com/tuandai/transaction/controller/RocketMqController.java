package com.tuandai.transaction.controller;


import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.bo.MessageView;
import com.tuandai.transaction.common.HttpUrlPool;
import com.tuandai.transaction.service.inf.RocketService;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.rocketmq.common.protocol.body.TopicList;
import org.apache.rocketmq.tools.admin.DefaultMQAdminExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/rocket")
public class RocketMqController {

    private static final Logger logger = LoggerFactory.getLogger(ApiController.class);

    @Autowired
    private HttpUrlPool httpUrlPool;

    @Autowired
    private RocketService rocketService;

    /**
     * 死信队列查询
     * @return
     */
    @RequestMapping(value = "/topic/dlq/list", method = RequestMethod.GET)
    public String fetchDLQTopicList() {
        List<String> list = rocketService.fetchDLQTopicList();
        return JSONObject.toJSONString(list);
    }

    @RequestMapping(value = "/message/dlq/resend", method = RequestMethod.POST)
    public String resendMessage(@RequestParam String topic) throws Exception {
       String groupName = topic.replace("%DLQ%", "");
        List<MessageView> list = rocketService.consumerMessage(groupName, topic, 100);
        Map<String, String> map = new HashMap<>();
        map.put("status", "success");
        StringEntity postingString = null;// json传递

        String ids = getTransactionIds(list);
        if (StringUtils.isEmpty(ids)) {
            return JSONObject.toJSONString(map);
        }

        postingString = new StringEntity("\"" + ids + "\"");

        HttpPost post = new HttpPost(httpUrlPool.getMsgResendUrl());
        DefaultHttpClient httpClient = new DefaultHttpClient();
        post.setEntity(postingString);
        post.setHeader("Content-type", "application/json");
        CloseableHttpResponse responseww = httpClient.execute(post);

        logger.info("重发消息返回结果：" + responseww);

       return JSONObject.toJSONString(map);
    }


    private String getTransactionIds(List<MessageView> list) {
        if (CollectionUtils.isEmpty(list)) {
            return null;
        }
        String ids = "";
        for (MessageView messageView : list) {
            Map<String, String> pro = messageView.getProperties();
            String keys = pro.get("KEYS");
            if (keys == null) {
                continue;
            }
            String []tmp = keys.split(":");
            String id = tmp[1];
            ids = id + "," + ids;
        }
        return ids.equals("") ? "" : ids.substring(0, ids.length() - 1);
    }


    @RequestMapping(value = "/message/dlq/list", method = RequestMethod.GET)
    public String queryAllDLQMessage(@RequestParam String topic, @RequestParam long begin, @RequestParam long end) {
        if (end == 0) {
            end = new Date().getTime();
        }
        if (StringUtils.isEmpty(topic)) {
            return "";
        }
        int size = 1208;
        List<MessageView> list  = rocketService.queryMessageByTopic(topic, begin, end, size);

        System.out.print("========================================" + list);
        return JSONObject.toJSONString(list);
    }

}
