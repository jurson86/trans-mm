package com.tuandai.transaction.dao;

import com.tuandai.transaction.bo.Task;
import com.tuandai.transaction.mapper.TaskMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;

@RestController
public class TaskDao {

    @Autowired
    private TaskMapper taskMapper;


    public void save(Task task) {
        taskMapper.save(task);
    }

    public Iterable<Task> queryTaskList() {
       return taskMapper.findAll();
    }

    @Transactional
    public void updateTask(Task task) {
       if (taskMapper.exists(task.getId())) {
           taskMapper.updateTask(task.getId(), task.getTaskUrl(), task.getParse(),task.getCron());
       }
    }

    public Task queryTaskById(Long id) {
        return taskMapper.findOne(id);
    }

    public void deleteTaskById(Long id) {
        taskMapper.delete(id);
    }
}
