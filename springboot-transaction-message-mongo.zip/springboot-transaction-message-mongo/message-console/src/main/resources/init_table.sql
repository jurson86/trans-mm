CREATE TABLE if not exists `ServerSetting` (
`id`  int NULL AUTO_INCREMENT,
 `serverIp`  varchar(30),
 `isDefault` int
);

CREATE TABLE if not exists  `ServerCount` (
`id`  int NOT NULL AUTO_INCREMENT ,
`time`  datetime NULL ,
`count`  int NULL ,
`state` int NULL,
`serverIp` varchar(30),
PRIMARY KEY (`id`)
);

CREATE TABLE if not exists  `task` (
`id`  int NOT NULL AUTO_INCREMENT ,
`taskUrl`  varchar(225) NULL ,
`cron`  varchar(225) NULL ,
`parse`  tinyint NULL ,
`createTime`  datetime NULL ,
PRIMARY KEY (`id`)
)
;


