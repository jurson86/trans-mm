package com.tuandai.transaction.model.constants;

public class Constants {
	public static final String TRANSACTION_RESULT_TOPIC = "transaction.message.back";
}
