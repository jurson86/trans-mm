package com.tuandai.transaction.model.request;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(value = "MessageIdCreator")
public class MessageIdCreator {

	@ApiModelProperty(value = "服务名",required = true)
	@Size(max = 4)
	@NotBlank
	private String serviceName;

	@ApiModelProperty(value = "预发送确认回调URL", required = true)
	@NotBlank
	@Size(max = 256)
	private String presendBackUrl;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getPresendBackUrl() {
		return presendBackUrl;
	}

	public void setPresendBackUrl(String presendBackUrl) {
		this.presendBackUrl = presendBackUrl;
	}

	@Override
	public String toString() {
		return "MessageIdCreator{" +
				"serviceName='" + serviceName + '\'' +
				", presendBackUrl='" + presendBackUrl + '\'' +
				'}';
	}
}
