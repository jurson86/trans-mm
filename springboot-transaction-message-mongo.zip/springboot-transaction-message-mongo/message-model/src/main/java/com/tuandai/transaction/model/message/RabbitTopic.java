package com.tuandai.transaction.model.message;

/**
 *
 */
public class RabbitTopic {

    private String vHost;   // 虚拟主机

    private String exchange;    // 交换机

    private String routeKey;    // 路由键

    private String exchangeType;    // 交换机类型

    public String getRouteKey() {
        return routeKey;
    }

    public void setRouteKey(String routeKey) {
        this.routeKey = routeKey;
    }

    public String getvHost() {
        return vHost;
    }

    public void setvHost(String vHost) {
        this.vHost = vHost;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getExchangeType() {
        return exchangeType;
    }

    public void setExchangeType(String exchangeType) {
        this.exchangeType = exchangeType;
    }

    @Override
    public String toString() {
        return "RabbitTopic{" +
                "vHost='" + vHost + '\'' +
                ", exchange='" + exchange + '\'' +
                ", routeKey='" + routeKey + '\'' +
                ", exchangeType='" + exchangeType + '\'' +
                '}';
    }
}
