package com.tuandai.transaction.model.constants;
public enum LocalTransactionState {
    COMMIT_MESSAGE,
    CANCEL_MESSAGE
}
