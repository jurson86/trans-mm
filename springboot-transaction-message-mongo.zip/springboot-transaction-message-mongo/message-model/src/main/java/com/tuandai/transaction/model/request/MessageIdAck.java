package com.tuandai.transaction.model.request;

import javax.validation.constraints.NotNull;

import com.tuandai.transaction.model.constants.LocalTransactionState;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(value = "MessageIdAck")
public class MessageIdAck {

	@ApiModelProperty(value = "事物ID,生产者客户端添加", required = true)
	@NotNull
	private String messageId;

	@ApiModelProperty(value = "消息", required = true)
	@NotNull
	private String message;

	@ApiModelProperty(value = "消息类型", required = true)
	@NotNull
	private Integer messageType;

	@ApiModelProperty(value = "消息 Topic", required = true)
	@NotNull
	private String messageTopic;

	@ApiModelProperty(value = "确认状态", required = true)
	private LocalTransactionState state;

	public LocalTransactionState getState() {
		return state;
	}

	public void setState(LocalTransactionState state) {
		this.state = state;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getMessageType() {
		return messageType;
	}

	public void setMessageType(Integer messageType) {
		this.messageType = messageType;
	}

	public String getMessageTopic() {
		return messageTopic;
	}

	public void setMessageTopic(String messageTopic) {
		this.messageTopic = messageTopic;
	}

	@Override
	public String toString() {
		return "MessageIdAck{" +
				"messageId=" + messageId +
				", message='" + message + '\'' +
				", messageType=" + messageType +
				", messageTopic='" + messageTopic + '\'' +
				", state=" + state +
				'}';
	}
}
