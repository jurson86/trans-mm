package com.tuandai.transaction.client.send;

import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.tuandai.transaction.client.config.SpringBootConfig;
import com.tuandai.transaction.client.producer.LocalTransactionExecuter;
import com.tuandai.transaction.model.constants.LocalTransactionState;
import com.tuandai.transaction.model.request.MessageIdAck;
import com.tuandai.transaction.model.request.MessageIdCreator;

public class SendMassage {

	private static final Logger logger = LoggerFactory.getLogger(SendMassage.class);

	private static HttpHeaders header = new HttpHeaders();

	private RestTemplate restTemplate;

	// Timeout waiting for connection from pool
	private static HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory(
			HttpClientBuilder.create().setMaxConnTotal(200).setMaxConnPerRoute(100).build());

	static {
		header.setAccept(ImmutableList.of(MediaType.APPLICATION_JSON_UTF8));
		header.setContentType(MediaType.APPLICATION_JSON_UTF8);

		// 此处超时时长设置相对要长一点，防止并发压力导致延时
		httpRequestFactory.setConnectTimeout(1000);
		// 数据读取超时时间，即SocketTimeout
		httpRequestFactory.setReadTimeout(1000);
		// 连接不够用的等待时间，不宜过长，必须设置，比如连接不够用时，时间过长将是灾难性的
		httpRequestFactory.setConnectionRequestTimeout(1000);

	}

	private String _massageManageUrl = SpringBootConfig.SERVICE_NAME;

	// 使用默认的负载均衡
	public SendMassage() {
	}

	public SendMassage(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	// 指定IP调用
	public SendMassage(String massageManageUrl) {
		_massageManageUrl = massageManageUrl;
	}

	public LocalTransactionState preSendMassage(MessageIdCreator messageIdCreator,
			LocalTransactionExecuter localTransactionExecuter, final Object arg) {

		Preconditions.checkNotNull(messageIdCreator);

		restTemplate.setRequestFactory(httpRequestFactory);
		ResponseEntity<String> resp = null;

		try {
			resp = restTemplate.exchange(this._massageManageUrl + "/message/creator", HttpMethod.POST,
					new HttpEntity<MessageIdCreator>(messageIdCreator, header), String.class);
		} catch (Exception e) {
			logger.error("PreSendMassage 执行异常： {} , {}", e.getClass().getName(), e.getMessage());
			return LocalTransactionState.CANCEL_MESSAGE;
		}

		if (!(null != resp && HttpStatus.OK.equals(resp.getStatusCode()))) {
			return LocalTransactionState.CANCEL_MESSAGE;
		}

		logger.debug("response.getBody: {}", resp.getBody());
		JSONObject jo = JSONObject.parseObject((String) resp.getBody()).getJSONObject("data");
		String routeKey = jo.getString("routeKey");
		String msgId = jo.getString("messageId");
		MessageIdAck messageIdAck = localTransactionExecuter.executeLocalTransactionBranch(msgId, arg);

		resp = restTemplate.exchange(this._massageManageUrl + "/message/send/" + routeKey, HttpMethod.POST,
				new HttpEntity<MessageIdAck>(messageIdAck, header), String.class);
		logger.debug("确认事务消息: {}", resp.getBody());
		return messageIdAck.getState();
	}

}
