package com.tuandai.transaction.client.producer;

import com.tuandai.transaction.model.request.MessageIdAck;

public interface LocalTransactionExecuter {
	MessageIdAck executeLocalTransactionBranch(final String msgId, final Object arg);
}