package com.tuandai.transaction.client.config;


public class SpringBootConfig {

    public final static String SERVICE_NAME = "http://transaction-message";

}
