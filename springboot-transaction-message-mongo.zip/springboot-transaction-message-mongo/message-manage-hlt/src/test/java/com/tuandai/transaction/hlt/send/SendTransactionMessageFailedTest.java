package com.tuandai.transaction.hlt.send;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;

import com.alibaba.fastjson.JSONArray;
import com.tuandai.transaction.bo.OptLog;
import com.tuandai.transaction.hlt.constant.Constant;
import com.tuandai.transaction.model.constants.LocalTransactionState;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.model.constants.Thresholds;
import com.tuandai.transaction.model.request.MessageIdAck;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSONObject;

/**
 * message-manage 启动参数： java -Dsend.thresholds=1,1,1,1,1,1,1,1,1,1
 * -Dpresend.back.thresholds=1,1,1,1,1,1 -jar message-manage-0.0.1-SNAPSHOT.jar
 * 【注： 此场景需要停止 消息服务,和监控台的任务调度任务】
 * @author jianggq
 *
 */
@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@DirtiesContext
@TestPropertySource(properties = { "server.port=11011" })
public class SendTransactionMessageFailedTest {
	private static final Logger logger = LoggerFactory.getLogger(SendTransactionMessageFailedTest.class);

	@Autowired
	private TestRestTemplate restTemplate;

	private String serviceUrl;

	private String presendIp;

	@Before
	public void init() {
		serviceUrl = "http://10.100.11.74:8085/";
		presendIp = "172.22.150.36";
	}

	/**
	 * 【注： 此场景需要停止 消息服务,和监控台的任务调度任务】 场景： 提交消息创建消息成功，确认成功，消息发送失败，定时调度重发，重发失败超过阀值，人工干预，干预废弃；
	 */
	@Test
	public void sendMessageFailedStateToDied() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("presendBackUrl", "http://" + presendIp + ":11011/msg/messageid/check/success");
		httpbodyMap.put("serviceName", "hlt");

		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		String messageId = JSONObject.parseObject(response.getBody()).getJSONObject("data").getString("messageId");
		Long routeKey = JSONObject.parseObject(response.getBody()).getJSONObject("data").getLong("routeKey");
		assertThat(messageId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		MessageIdAck messageIdAck = new MessageIdAck();
		messageIdAck.setMessageId(messageId);
		messageIdAck.setState(LocalTransactionState.COMMIT_MESSAGE);
		messageIdAck.setMessageTopic("TeststringTopic");
		messageIdAck.setMessage("hello world");
		messageIdAck.setMessageType(0);
		response = restTemplate.exchange(serviceUrl + "/message/send/" + routeKey, HttpMethod.POST,
				new HttpEntity<MessageIdAck>(messageIdAck, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 确认消息成功 =======");

		String[] msgid = messageIdAck.getMessageId().split(Constant.MESSAGE_ID_SPLIT);		
		Long transactionId = Long.valueOf(msgid[1]);
		
		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isIn(MessageState.SEND.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageSendThreshold"))
				.isEqualTo(Thresholds.MAX_SEND.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getDate("messageNextSendTime"))
				.isNotNull();
		logger.info("======= 确认状态是否为： 发送 =======");

		// 触发发送
		Thread.sleep(3000);
		response = this.restTemplate.exchange(serviceUrl + "/message/task/send", HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 触发发送 =======");

		// 查询消息是否正常回调执行
		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageSendTimes"))
				.isGreaterThan(0);
		logger.info("======= 查询消息是否正常回调执行 =======");

		// 触发回调，超过阀值
		for (int i = 0; i < 15; i++) {
			Thread.sleep(3000);
			response = this.restTemplate.exchange(serviceUrl + "/message/task/send", HttpMethod.POST,
					new HttpEntity<String>(null, null), String.class);
			assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		}
		logger.info("======= 触发回调，超过阀值 =======");

		// 确认状态是否为： 死亡消息
		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.DIED.code());
		logger.info("======= 确认状态是否为： 死亡消息 =======");

		// 人工干预，废弃消息；
		response = this.restTemplate.exchange(serviceUrl + "/message/change/died/" + MessageState.DISCARD.code(),
				HttpMethod.POST, new HttpEntity<String>(String.valueOf(transactionId), null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 人工干预，废弃消息； =======");

		response = this.restTemplate.exchange(serviceUrl + "/message/optlog/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		JSONArray array = JSONObject.parseObject(response.getBody()).getJSONArray("data");
		OptLog log = array.getObject(0, OptLog.class);
		assertThat(log.getEndState().equals(MessageState.DISCARD.code()));
		logger.info("======= 确认状态是否为： 废弃消息 =======");
	}

	/**
	 * 【注： 此场景需要停止 消息服务】 场景： 提交消息创建消息成功，确认成功，消息发送失败，定时调度重发，重发失败超过阀值，人工干预，干预发送；
	 */
	@Test
	public void sendMessageFailedStateToDiedToSend() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("presendBackUrl", "http://" + presendIp + ":11011/msg/messageid/check/success");
		httpbodyMap.put("serviceName", "hlt");

		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		String messageId = JSONObject.parseObject(response.getBody()).getJSONObject("data").getString("messageId");
		Long routeKey = JSONObject.parseObject(response.getBody()).getJSONObject("data").getLong("routeKey");
		assertThat(messageId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		MessageIdAck messageIdAck = new MessageIdAck();
		messageIdAck.setMessageId(messageId);
		messageIdAck.setState(LocalTransactionState.COMMIT_MESSAGE);
		messageIdAck.setMessage("hello world");
		messageIdAck.setMessageTopic("TeststringTopic");
		messageIdAck.setMessageType(0);
		response = restTemplate.exchange(serviceUrl + "/message/send/" + routeKey, HttpMethod.POST,
				new HttpEntity<MessageIdAck>(messageIdAck, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 确认消息成功 =======");

		String[] msgid = messageIdAck.getMessageId().split(Constant.MESSAGE_ID_SPLIT);		
		Long transactionId = Long.valueOf(msgid[1]);
		
		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isIn(MessageState.SEND.code());
		logger.info("======= 确认状态是否为： 发送 =======");

		// 触发回调
		Thread.sleep(3000);
		response = this.restTemplate.exchange(serviceUrl + "/message/task/send", HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 触发回调 =======");

		// 查询消息是否正常回调执行
		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageSendTimes"))
				.isGreaterThan(0);
		logger.info("======= 查询消息是否正常回调执行 =======");

		// 触发回调，超过阀值
		for (int i = 0; i < 15; i++) {
			Thread.sleep(3000);
			response = this.restTemplate.exchange(serviceUrl + "/message/task/send", HttpMethod.POST,
					new HttpEntity<String>(null, null), String.class);
			assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		}
		logger.info("======= 触发回调，超过阀值 =======");

		// 确认状态是否为： 死亡消息
		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.DIED.code());
		logger.info("======= 确认状态是否为： 死亡消息 =======");

		// 人工干预，发送消息；
		response = this.restTemplate.exchange(serviceUrl + "/message/change/died/" + MessageState.SEND.code(),
				HttpMethod.POST, new HttpEntity<String>(String.valueOf(17061893), null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 人工干预，激活发送消息； =======");

		response = this.restTemplate.exchange(serviceUrl + "/state/get/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
				.isEqualTo(MessageState.SEND.code());
		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageSendThreshold"))
				.isEqualTo(Thresholds.MAX_SEND.code());
		logger.info("======= 确认状态是否为： 发送 =======");
	}

	
}
