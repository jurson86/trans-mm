package com.tuandai.transaction.hlt.send;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.HashMap;

import com.alibaba.fastjson.JSONArray;
import com.tuandai.transaction.bo.OptLog;
import com.tuandai.transaction.hlt.constant.Constant;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.model.constants.LocalTransactionState;
import com.tuandai.transaction.model.constants.MessageState;
import com.tuandai.transaction.model.request.MessageIdAck;

/**
 * message-manage 启动参数： java -Dsend.thresholds=1,1,1,1,1,1,1,1,1,1
 * -Dpresend.back.thresholds=1,1,1,1,1,1 -jar message-manage-0.0.1-SNAPSHOT.jar
 * 
 * @author jianggq
 *
 */
@Ignore
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT)
@DirtiesContext
@TestPropertySource(properties = { "server.port=11011" })
public class SendTransactionMessageTest {
	private static final Logger logger = LoggerFactory.getLogger(SendTransactionMessageTest.class);

	@Autowired
	private TestRestTemplate restTemplate;

	private String serviceUrl;

	private String presendIp;

	@Before
	public void init() {
		serviceUrl = "http://10.100.11.74:8085/";
		presendIp = "172.22.150.36";
	}

	/**
	 * 【注： 此场景需要正常啟動 消息服务】 场景： 提交消息创建消息成功，确认成功，消息发送成功，不需要結果稽核回調；
	 */
	@Test
	public void sendMessageSuccess() throws Exception {
		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
		httpbodyMap.put("presendBackUrl", "http://"+ presendIp + ":11011/msg/messageid/check/success");
		httpbodyMap.put("serviceName", "hlt");

		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		String messageId = JSONObject.parseObject(response.getBody()).getJSONObject("data").getString("messageId");
		Long routeKey = JSONObject.parseObject(response.getBody()).getJSONObject("data").getLong("routeKey");
		assertThat(messageId).isNotNull();
		logger.info("======= 创建消息成功 =======");

		MessageIdAck messageIdAck = new MessageIdAck();
		messageIdAck.setMessageId(messageId);
		messageIdAck.setState(LocalTransactionState.COMMIT_MESSAGE);
		messageIdAck.setMessage("hello world");
		messageIdAck.setMessageType(0);
		messageIdAck.setMessageTopic("TeststringTopic");
		response = restTemplate.exchange(serviceUrl + "/message/send/" + routeKey, HttpMethod.POST,
				new HttpEntity<MessageIdAck>(messageIdAck, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		logger.info("======= 确认消息成功 =======");

		String[] msgid = messageIdAck.getMessageId().split(Constant.MESSAGE_ID_SPLIT);		
		Long transactionId = Long.valueOf(msgid[1]);

		response = this.restTemplate.exchange(serviceUrl + "/message/optlog/" + transactionId, HttpMethod.POST,
				new HttpEntity<String>(null, null), String.class);
		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
		JSONArray array = JSONObject.parseObject(response.getBody()).getJSONArray("data");
		OptLog log = array.getObject(0, OptLog.class);
		assertThat(log.getEndState().equals(MessageState.DONE.code()));
		logger.info("======= 确认状态是否为： 完成 =======");

	}
	

	/**
	 * 【注： 此场景需要正常啟動 消息服务】 场景： 提交消息创建消息成功，确认成功，消息发送成功，需要結果稽核检测，结果稽核检测，结果确认；
	 */
//	@Test
//	public void sendMessageSuccessNeedCheckResult() throws Exception {
//		HashMap<String, Object> httpbodyMap = new HashMap<String, Object>();
//		httpbodyMap.put("expectResult", "a");
//		httpbodyMap.put("message", "hello world");
//		httpbodyMap.put("messageTopic", "TeststringTopic");
//		httpbodyMap.put("presendBackUrl", "http://127.0.0.1:11011/msg/messageid/check/success");
//		httpbodyMap.put("resultBackUrl", "http://127.0.0.1:11011/msg/messageid/check/result");
//		httpbodyMap.put("serviceName", "hlt");
//		httpbodyMap.put("expectResult", "a");
//
//		ResponseEntity<String> response = this.restTemplate.exchange(serviceUrl + "message/creator", HttpMethod.POST,
//				new HttpEntity<HashMap<String, Object>>(httpbodyMap, null), String.class);
//		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
//		Long transactionId = JSONObject.parseObject(response.getBody()).getJSONObject("data").getLong("transactionId");
//		Long routeKey = JSONObject.parseObject(response.getBody()).getJSONObject("data").getLong("routeKey");
//		assertThat(transactionId).isNotNull();
//		logger.info("======= 创建消息成功 =======");
//
//		MessageIdAck messageIdAck = new MessageIdAck();
//		messageIdAck.setTransactionId(Long.valueOf(transactionId));
//		messageIdAck.setState(true);
//		response = restTemplate.exchange(serviceUrl + "/message/send/" + routeKey, HttpMethod.POST,
//				new HttpEntity<MessageIdAck>(messageIdAck, null), String.class);
//		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
//		logger.info("======= 确认消息成功 =======");
//
//		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
//				new HttpEntity<String>(null, null), String.class);
//		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
//		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
//		.isIn(MessageState.DONE.code());
//		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
//		.isIn(OverMark.ACTIVE.code());
//		logger.info("======= 确认状态是否为： 完成 =======");
//
//
//		Thread.sleep(3000);
//		response = this.restTemplate.exchange(serviceUrl + "/message/task/done", HttpMethod.POST,
//				new HttpEntity<String>(null, null), String.class);
//		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
//		logger.info("======= 触发稽核检测 =======");
//
//		response = this.restTemplate.exchange(serviceUrl + "/message/get/" + transactionId, HttpMethod.POST,
//				new HttpEntity<String>(null, null), String.class);
//		assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
//		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getInteger("messageState"))
//		.isIn(MessageState.DONE.code());
//		assertThat(JSONObject.parseObject(response.getBody()).getJSONObject("data").getBoolean("over"))
//		.isIn(OverMark.OVER.code());
//		logger.info("======= 结果确认 =======");
//
//	}
	
}
