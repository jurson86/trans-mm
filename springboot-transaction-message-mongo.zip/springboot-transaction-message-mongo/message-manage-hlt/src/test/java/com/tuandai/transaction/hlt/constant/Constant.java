package com.tuandai.transaction.hlt.constant;

public class Constant {
	
	public static final String MESSAGE_ID_SPLIT=":";
	
}
