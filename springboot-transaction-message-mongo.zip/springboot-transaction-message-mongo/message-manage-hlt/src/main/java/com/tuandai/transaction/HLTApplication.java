package com.tuandai.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class HLTApplication {

	public static void main(String[] args) {
		SpringApplication.run(HLTApplication.class, args);
	}
}
