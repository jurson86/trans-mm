package com.tuandai.transaction.service;

import org.apache.rocketmq.common.message.MessageExt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.qianmi.ms.starter.rocketmq.annotation.RocketMQMessageListener;
import com.qianmi.ms.starter.rocketmq.core.RocketMQListener;

@Component
@RocketMQMessageListener(topic = "HLTConsumerTestTopic", consumerGroup = "transaction-group-1")
public class TransactionRocketMQConsumer implements RocketMQListener<MessageExt> {
	private static final Logger logger = LoggerFactory.getLogger(TransactionRocketMQConsumer.class);

	public static int MESSAGE_RESULT = 0;

	public void onMessage(MessageExt messageExt) {
		MESSAGE_RESULT++;
		logger.info("==========================received message========================= \n {} \n {}",
				messageExt.toString(), new String(messageExt.getBody()));
	}

}