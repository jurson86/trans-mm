package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.utils.ServiceException;

import java.util.Date;
import java.util.List;
import java.util.Map;

public interface TransactionCheckService {


    /**
     * 触发check操作
     */
    void preSendCallbackByTask()  throws ServiceException;

    /**
     * 触发Send操作
     */
    void sendTask() throws ServiceException;


    List<TransactionCheck> queryMessageByState(int state, Date startTime, Date endTime);

    Map<MessageState, Long> queryCountMessageByState();

    boolean resend(Long pid);

    boolean discard(Long pid);


    boolean delete(List<Long> pids);

}
