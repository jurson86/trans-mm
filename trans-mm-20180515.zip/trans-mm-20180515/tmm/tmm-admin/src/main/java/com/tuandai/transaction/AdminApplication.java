package com.tuandai.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ApplicationContext;

import com.tuandai.transaction.config.InitailDBTables;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableDiscoveryClient  // 消费者
@EnableEurekaClient 	// 生产者
@EnableScheduling
@ComponentScan({"com.tuandai.architecture.zabbix", "com.tuandai.transaction"})
public class AdminApplication {

	public static void main(String[] args) {		
		ApplicationContext applicationContext = SpringApplication.run(AdminApplication.class, args);

		//初始化数据库表
		applicationContext.getBean(InitailDBTables.class).createTables();

	}
}
