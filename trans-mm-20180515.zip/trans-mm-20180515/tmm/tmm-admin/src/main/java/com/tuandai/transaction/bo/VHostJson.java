package com.tuandai.transaction.bo;

public class VHostJson {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
