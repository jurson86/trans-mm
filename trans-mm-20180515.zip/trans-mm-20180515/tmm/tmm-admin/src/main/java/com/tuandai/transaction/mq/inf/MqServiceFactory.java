package com.tuandai.transaction.mq.inf;

public interface MqServiceFactory {

    MqService createMqService();
}
