package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.bo.MessageState;

import java.util.Map;

/**
 * zabbix监控类
 */
public interface ZabbixService {

    /**
     * 监控 消息各状态数
     *
     * 状态 -> 当前状态的数量
     */
     Map<MessageState, Long> messageStateMonitor();

}
