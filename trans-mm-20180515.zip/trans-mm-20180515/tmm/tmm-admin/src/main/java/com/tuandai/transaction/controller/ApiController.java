package com.tuandai.transaction.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.tuandai.transaction.bo.MessageState;
import com.tuandai.transaction.bo.QueueJson;
import com.tuandai.transaction.utils.BZStatusCode;
import com.tuandai.transaction.utils.ServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.service.inf.RabbitMqService;
import com.tuandai.transaction.service.inf.TransactionCheckService;
import com.tuandai.transaction.utils.Result;

@RestController
@RequestMapping(value = "/api")
public class ApiController {

	private static final Logger logger = LoggerFactory.getLogger(ApiController.class);

	@Autowired
	private TransactionCheckService transactionCheckService;

	@Autowired
	private RabbitMqService rabbitMqService;

	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public HashMap<String, Object> get(@RequestParam String name) {
		
    	logger.info("get: {}",name);
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("title", "hello world");
		map.put("name", name);
		
		return map;
	}

	@RequestMapping(value = "/preSendCallbackByTask", method = RequestMethod.GET)
	public void preSendCallbackByTask() {
		transactionCheckService.preSendCallbackByTask();
	}

	// 查询消息状态列表
	@RequestMapping(value = "/messageList/state", method = RequestMethod.GET)
	public Object queryMessageListByState(@RequestParam Integer state, @RequestParam(defaultValue ="0") long startTime,
										  @RequestParam(defaultValue ="-1")  long endTime) {
		logger.debug("queryMessageListByState: {} ", state);
		Date stTime = startTime == 0 ? null : new Date(startTime);
		Date edTime = endTime == -1 ? null :  new Date(endTime);
		List<TransactionCheck> list = transactionCheckService.queryMessageByState(state, stTime, edTime);
		return new ResponseEntity<Result<List<TransactionCheck>>>(new Result<List<TransactionCheck>>(list),
				HttpStatus.OK);
	}

	// 查询各个状态下的消息数量
	@RequestMapping(value = "/message/state/count", method = RequestMethod.GET)
	public Object queryCountByState() {
		logger.debug("queryCountByState: {} ");
		Map<MessageState, Long> map = transactionCheckService.queryCountMessageByState();
		return new ResponseEntity<Result<Map<MessageState, Long>>>(new Result<Map<MessageState, Long>>(map),
				HttpStatus.OK);
	}

	// 消息重发
	@RequestMapping(value = "/message/resend", method = RequestMethod.POST)
	public Object resend(@RequestParam String pids) {
		if (StringUtils.isEmpty(pids)) {
			throw  new ServiceException(BZStatusCode.INVALID_PARAMS_IS_NULL);
		}
		String res = "";
		String[] pidList = pids.split(",");
		for (String pid : pidList) {
			boolean result = false;
			try {
				result = transactionCheckService.resend(Long.valueOf(pid));
			} catch (Exception e) {
				logger.error("未知异常", e);
			}
			if (!result) {
				res = res + pid + ",";
			}
		}
		return new  ResponseEntity<Result<String>>(new Result<String>(res), HttpStatus.OK);
	}

	// 消息废弃
	@RequestMapping(value = "/message/discard", method = RequestMethod.POST)
	public Object discard(@RequestParam String pids) {

		if (StringUtils.isEmpty(pids)) {
			throw  new ServiceException(BZStatusCode.INVALID_PARAMS_IS_NULL);
		}
		String res = "";
		String[] pidList = pids.split(",");
		for (String pid : pidList) {
			boolean result = false;
			try {
				result = transactionCheckService.discard(Long.valueOf(pid));
			} catch (Exception e) {
				logger.error("未知异常", e);
			}
			if (!result) {
				res = res + pid + ",";
			}
		}
		return new  ResponseEntity<Result<String>>(new Result<String>(res), HttpStatus.OK);
	}

	// 消费者死信队列重发
	@RequestMapping(value = "/message/dlq/resend", method = RequestMethod.POST)
	public Object dlqResend(@RequestParam String queue) {
		boolean result = rabbitMqService.dlqResend(queue);
		return new  ResponseEntity<Result<Boolean>>(new Result<Boolean>(result), HttpStatus.OK);
	}

	// 消费者死信队列统计
	@RequestMapping(value = "/message/dlq/list", method = RequestMethod.GET)
	public Object dlqList() {
		List<QueueJson> result = rabbitMqService.dlqList();
		return new  ResponseEntity<Result<List<QueueJson>>>(new Result<List<QueueJson>>(result), HttpStatus.OK);
	}

	@RequestMapping(value = "/message/delete", method = RequestMethod.POST)
		public Object deleteMessage(@RequestParam String pids) {
		String[] pidList = pids.split(",");
		boolean result = transactionCheckService.delete(CollectionUtils.arrayToList(pidList));
		return new ResponseEntity<Result<Boolean>>(new Result<Boolean>(result), HttpStatus.OK);
	}

}