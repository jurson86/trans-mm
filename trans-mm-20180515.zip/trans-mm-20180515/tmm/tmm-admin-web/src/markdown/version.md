# 一、TMM版本迭代
（一） 1.1.1–SNAPSHOT

         版本说明：本版本提供基本的消息一致性功能。

          包括：消息的记录，mq服务宕机消息的存储等可靠方案。
</br>
</br>
</br>
</br>

## 二、生产者对接
    1.引入jar包       
  	<dependency>
        <groupId>com.tuandai.architecture</groupId>
        <artifactId>tmm-client</artifactId>
        <version>x.x.x-SNAPSHOT</version>
    </dependency>
    


    2. 启动的时候初始化TMMClient
          // com.tuandai.transaction.client 是TMM服务的jar地址，
           // /**** 新版本 ******/ 
          // com.tuandai.architecture.zabbix 是zabbix的jar地址， ... 是业务方   自己的jar地址（如果不配该选项，业务方可能会报注入错误）
           @ComponentScan(basePackages = {"com.tuandai.transaction.client", "  com.tuandai.architecture.zabbix", ...}) 
          public static void main(String[] args) { 
               SpringApplication.run(ProducerApplication.class,  args);
          }



    3.对接消息
      //初始化
      @Autowired
      private TMMService tMMService;
      RabbitMQTopic rabbitMQTopic = new RabbitMQTopic();
      rabbitMQTopic.setvHost("myVhost");
      rabbitMQTopic.setExchange("myExchange3");
      rabbitMQTopic.setExchangeType("direct");
      rabbitMQTopic.setRouteKey("route");
      // 以下属性选填，如果选择false则需要生产者自己去创建交换机，true则tmmService采用默认属性创建对应的交换机
      rabbitMQTopic.setCustomExchange(true);
      // 开始事务日志   
      BeginLog beginLog = new BeginLog();
      beginLog.setUid(uid);                                                             //【必填】 事务ID，必须保障唯一，业务采用UUID 生成
      beginLog.setServiceName(serviceName);                             //【必填】 服务名称
      beginLog.setMessage(null);                                                   //【选填】消息内容，【如果结束日志有采用结束日志内容，否则采用开始日志对应项】
      beginLog.setTopic(rabbitMQTopic.toJSONString());              //【选填】消息exchange (topic) ，【格式：RabbitMQTopic】【如果结束日志有采用结束日志内容，否则采用开始日志对应项】
      beginLog.setCheck("");                                                          //check接口【如果不提供，需保障通过uid可查询到事务处理结果】
      /**
        * 记录开始事务日志
         */
      tMMService.sendTransBeginToFlume(beginLog);

      // TODO 业务代码 。。。。

      //初始化结束事务日志
      EndLog endLog = new EndLog();
      endLog.setUid(uid);                                                    //【必填】 事务ID，必须保障与开始事务日志同一个值
      endLog.setServiceName(serviceName);                   //【必填】 服务名称
      endLog.setState(SendState.COMMIT);                    //【必填】消息状态： 发送 或 取消  [SendState.COMMIT | SendState.CANCEL]
      endLog.setMessage(messageModel);                      //【选填】消息内容，【如果结束日志有采用结束日志内容，否则采用开始日志对应项】
      endLog.setTopic(null);                                              //【选填】消息exchange (topic) ，【如果结束日志有采用结束日志内容，否则采用开始日志对应项】
      /**
       * 记录结束事务日志
       */
      tMMService.sendTransEndToFlume(endLog);
   
 
 
    4.添加mq配置
       # rabbitMq 配置
       spring.rabbitmq.host=10.100.11.160
       spring.rabbitmq.port=5672
       spring.rabbitmq.username=admin
       spring.rabbitmq.password=admin
       #当前数据路径，此文件记录的是事务的相关数据不能丢失，建议放到一个安全的挂载点上，默认在工程目录下
        spring.tmmService.rpcPath=....
       #spring.tmmService.batch.size=2000 # 可选 每个批次处理的条数
       #spring.tmmService.check.interval.time=10000 # 可选 在此时间内没有打印结束日志则进入check队列
       
       /**** 新版本 ******/
       #zabbix 地址
       zabbix.host=127.0.0.1
       #监控频率
       #spring.tmmService.monitor.interval.time=10000
       /**** 新版本 ******/
    
    5.回调确认接口（可选）
       请求： 
          url: post       服务名/业务名/check

       请求参数： json
          {    "uid":xxxxx }

       正常响应： 
           HttpState.OK

       json体：
           结束事务日志数据
           异常响应：
           HttpStatus.FAILED_DEPENDENCY
