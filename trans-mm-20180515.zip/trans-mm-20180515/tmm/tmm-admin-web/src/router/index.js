import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const BackStage = () => import(/* webpackChunkName: "group-backstage" */ '../pages/backstage.vue')
const Home = () => import(/* webpackChunkName: "group-backstage" */ '../pages/home.vue')
const WarnMsg = () => import(/* webpackChunkName: "group-backstage" */ '../pages/warnMsg.vue')
const DeathMsg = () => import(/* webpackChunkName: "group-backstage" */ '../pages/deathMsg.vue')
const DieMsg = () => import(/* webpackChunkName: "group-backstage" */ '../pages/dieMsg.vue')
const ClearMsg = () => import(/* webpackChunkName: "group-backstage" */ '../pages/clearMsg.vue')
const HelpCenter = () => import(/* webpackChunkName: "group-backstage" */ '../pages/helpCenter.vue')

export default new Router({
	routes: [
	    {
	        path: '/',
	        component: BackStage,
	        redirect: '/home',
	        children: [
	        	{
	        		path: '/home',
	        		name: 'home',
	        		component: Home
	        	},
	        	{
	        		path: '/warnMsg',
	        		name: 'warnMsg',
	        		component: WarnMsg
	        	},
	        	{
	        		path: '/deathMsg',
	        		name: 'deathMsg',
	        		component: DeathMsg
	        	},
	        	{
	        		path: '/dieMsg',
	        		name: 'dieMsg',
	        		component: DieMsg
	        	},
	        	{
	        		path: '/clearMsg',
	        		name: 'clearMsg',
	        		component: ClearMsg
	        	},
	        	{
	        		path: '/helpCenter',
	        		name: 'helpCenter',
	        		component: HelpCenter
	        	}
	        ]
	    }
	]
})
