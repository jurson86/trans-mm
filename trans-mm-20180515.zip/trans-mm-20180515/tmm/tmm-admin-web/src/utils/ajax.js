import axios from 'axios';
import qs from 'qs';
import Vue from 'vue';

//axios.defaults.baseURL = '/api';

export default{
	install(Vue, option){
		Vue.prototype.$post = function(url, params, sb){
			return new Promise((resolve, reject) => {
				axios.post(url, sb ? qs.stringify(params) : params).then(res => {
					resolve(res.data);
				}, err => {
					reject(err);
				}).catch(error => {
					console.info(error);
				})
			})
		}

		Vue.prototype.$get = function (url, params) {
            const newParams = Object.assign({noCache: new Date().getTime()}, params);

            return new Promise((resolve, reject) => {
                axios.get(url, {params: newParams}).then(res => {
                    resolve(res.data)
                }, err => {
                    reject(err)
                }).catch(error => {
                    console.log(error);
                })
            })
        }
	}
}