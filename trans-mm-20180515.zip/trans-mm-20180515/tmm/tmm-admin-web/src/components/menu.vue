<template>
	<Scroll class="menu">
		<Menu theme="dark" active-name="home" @on-select="linkUrl">
			<MenuItem name="home">MQ管理端</MenuItem>
			<MenuItem name="others">zabbix监控端</MenuItem>
		</Menu>
	</Scroll>
</template>

<script type="es6">
	export default{
		methods: {
			linkUrl(name){
				if(name == 'others')
					window.location.href = 'http://www.baidu.com';
			}
		}
	}
</script>