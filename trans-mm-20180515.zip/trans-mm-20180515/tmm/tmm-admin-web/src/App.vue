<template>
    <div class="manager">
      <router-view/>
    </div>
</template>

<script>
export default {
    name: 'App'
}
</script>

<style lang="scss">
    @import 'assets/css/index.scss';
</style>
