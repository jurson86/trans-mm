package com.tuandai.transaction.client.utils;

import org.junit.Test;

import java.net.InetAddress;

import static org.junit.Assert.assertNotNull;

public class NetUtilsTest {

    @Test
    public void getLocalHostLANAddressTest() {
        InetAddress ipAdderss = NetUtils.getLocalHostLANAddress();
        String ip = ipAdderss.getHostAddress();
        assertNotNull(ip);
    }
}
