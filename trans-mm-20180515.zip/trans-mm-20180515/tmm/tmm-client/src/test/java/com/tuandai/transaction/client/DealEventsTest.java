package com.tuandai.transaction.client;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class DealEventsTest {


}
