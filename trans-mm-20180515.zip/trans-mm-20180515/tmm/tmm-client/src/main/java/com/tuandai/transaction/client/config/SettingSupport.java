package com.tuandai.transaction.client.config;

import com.tuandai.transaction.client.bo.MqType;
import com.tuandai.transaction.client.bo.RabbitAddress;
import com.tuandai.transaction.client.utils.ConstantUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.File;
import java.util.Map;


@Component("setting")
public class SettingSupport {

    private static final Logger logger = LoggerFactory.getLogger(SettingSupport.class);

    public static ApplicationContext context;

    public static SettingSupport setting;

    /**
     * 需要发送mq类型
     */
    @Value("${mq.type:rabbitmq}")
    private String mqType;

    /**
     * 每批次发送处理日志条数
     */
    @Value("${spring.tmmService.batch.size:2000}")
    private int batchSize;

    /**
     * 日志文件存放路径
     */
    @Value("${spring.tmmService.rpcPath:}")
    private String rpcDirName;

    /**
     * 判定为check数据的时间间隔
     */
    @Value("${spring.tmmService.check.interval.time:60000}")
    private long checkIntervalTime;

    /**
     * rpc文件的切割大小
     */
    @Value("${rpc.size:100 * 1024 *1024L}")
    private long rpcSize;

    /**
     * 发送mq线程的核心线程数
     */
    @Value("${send.core.thread.num:5}")
    private int sendMqCorePoolThreadNum;

    /**
     * 发送mq线程的最大线程数
     */
    @Value("${send.max.thread.num:200}")
    private int sendMqMaxPoolThreadNum;

    /**
     * 发送mq线程的队列大小
     */
    @Value("${send.queue.size:5000}")
    private int sendMqQueueSize;

    @Autowired
    private TMMRabbitProperties tmmRabbitMqProperties;

    public static long getRpcSize() {
        return SettingHandler.getRpcSize();
    }

    public static long getCheckIntervalTime() {
        return SettingHandler.getCheckIntervalTime();
    }

    public static Map<String, RabbitAddress> getRabbitAddressMap() {
        return SettingHandler.getRabbitAddressMap();
    }

    public static File getRpcDir() {
        return SettingHandler.getRpcDir();
    }

    public static String getRpcDirCanonicalPath() {
        return SettingHandler.getRpcDirCanonicalPath();
    }

    public static MqType getMqType() {
        return SettingHandler.getMqType();
    }

    public static int getBatchSize() {
        return SettingHandler.getBatchSize();
    }

    public static int getSendMqCorePoolThreadNum() {
        return SettingHandler.getSendMqCorePoolThreadNum();
    }

    public static int getSendMqMaxPoolThreadNum() {
        return SettingHandler.getSendMqMaxPoolThreadNum();
    }

    public static int getSendMqQueueSize() {
        return SettingHandler.getSendMqQueueSize();
    }

    public static void init(ApplicationContext applicationContext) {
        context = applicationContext;
        setting = context.getBean(SettingSupport.class);
    }

    /**
     * Setting类的变量处理类
     */
    static class SettingHandler {

        public static MqType getMqType() {
            MqType mqType = MqType.findByDes(SettingSupport.setting.mqType);
            logger.debug("加载Mqtype:" + mqType);
            return mqType;
        }

        public static int getBatchSize() {
            int batchSize = SettingSupport.setting.batchSize;
            logger.debug("加载batchSize:" + batchSize);
            return batchSize;
        }

        public static File getRpcDir() {
            String rpcDirName = SettingSupport.setting.rpcDirName;
            if (StringUtils.isEmpty(rpcDirName)) {
                rpcDirName = ConstantUtils.DEFAULT_RPC_PATH;
            }
            logger.debug("加载rpcDir:" + rpcDirName);

            File rpcDir = new File(rpcDirName);
            // 检查目录权限
            if (! rpcDir.exists()) {
                if (! rpcDir.mkdirs()) {
                    throw new IllegalArgumentException("begin.map.directory is not a directory");
                }
            } else if (!rpcDir.canWrite()) {
                throw new IllegalArgumentException("begin.map.directory can not write");
            }
            return rpcDir;
        }

        public static Map<String, RabbitAddress> getRabbitAddressMap() {
            TMMRabbitProperties tMMRabbitProperties = SettingSupport.setting.tmmRabbitMqProperties;
            Map<String, RabbitAddress> map = tMMRabbitProperties.getRabbitAddressMap();
            logger.debug("加载rabbitmq:" + map);
            return map;
        }

        public static String getRpcDirCanonicalPath() {
            String str;
            try {
                str = getRpcDir().getCanonicalPath();
            } catch (Exception e) {
                throw new IllegalArgumentException("不能获得全路径名！");
            }
            return str;
        }

        public static long getCheckIntervalTime() {
            long time =  SettingSupport.setting.checkIntervalTime;
            logger.debug("加载CheckIntervalTime：" + time);
            return time;
        }

        public static long getRpcSize() {
            long rpcSize = SettingSupport.setting.rpcSize;
            logger.debug("加载rpcSize:" + rpcSize);
            return rpcSize;
        }

        public static int getSendMqCorePoolThreadNum() {
            int coreSize = SettingSupport.setting.sendMqCorePoolThreadNum;
            logger.debug("加载coreSize:" + coreSize);
            return coreSize;
        }

        public static int getSendMqMaxPoolThreadNum() {
            int maxSize = SettingSupport.setting.sendMqMaxPoolThreadNum;
            logger.debug("加载maxSize:" + maxSize);
            return maxSize;
        }

        public static int getSendMqQueueSize() {
            int queueSize = SettingSupport.setting.sendMqQueueSize;
            logger.debug("加载maxSize:" + queueSize);
            return queueSize;
        }
    }

}
