package com.tuandai.transaction.client.model;

import com.alibaba.fastjson.JSONObject;

public class RabbitMQTopic {

	private String ip; // 对应的集群Ip

	private String vHost;

	private String exchange;

	private String exchangeType;

	private String routeKey;

	private boolean isCustomExchange; // false 默认创建  true 消费者手动创建

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public boolean isCustomExchange() {
		return isCustomExchange;
	}

	public void setCustomExchange(boolean customExchange) {
		isCustomExchange = customExchange;
	}

	public String getRouteKey() {
		return routeKey;
	}

	public void setRouteKey(String routeKey) {
		this.routeKey = routeKey;
	}

	public String getvHost() {
		return vHost;
	}

	public void setvHost(String vHost) {
		this.vHost = vHost;
	}

	public String getExchange() {
		return exchange;
	}

	public void setExchange(String exchange) {
		this.exchange = exchange;
	}

	public String getExchangeType() {
		return exchangeType;
	}

	public void setExchangeType(String exchangeType) {
		this.exchangeType = exchangeType;
	}

	public String toJSONString() {
		return JSONObject.toJSONString(this);
	}

}
