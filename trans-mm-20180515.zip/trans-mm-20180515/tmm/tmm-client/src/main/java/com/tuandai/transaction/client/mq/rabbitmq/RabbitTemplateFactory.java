package com.tuandai.transaction.client.mq.rabbitmq;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.tuandai.transaction.client.bo.RabbitAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.util.StringUtils;

public class RabbitTemplateFactory {

    private static final Logger logger = LoggerFactory.getLogger(RabbitTemplateFactory.class);

    private static Map<String, RabbitAddress> rabbitAddressMap;

    public static void initParam(Map<String, RabbitAddress> map) {
        rabbitAddressMap = map;
    }

    // 缓存连接池  ip:vhost -> 连接池
    private static Map<String, CachingConnectionFactory> connectionFactoryCache = new ConcurrentHashMap<>();

    // 缓存RabbitTemplate
    private static Map<String, RabbitTemplate> rabbitTemplateCache = new ConcurrentHashMap<>();

    // 缓存admin
    private static Map<String, RabbitAdmin> adminCache = new ConcurrentHashMap<>();

    public static RabbitAdmin getRabbitAdmin(String vHost, String ipName) throws IllegalAccessException {
        RabbitAddress rabbitAddress = getRabbitAddress(ipName);
        String key = getKey(vHost, rabbitAddress.getIp());
        return adminCache.get(key);
    }

    private static RabbitAddress getRabbitAddress(String ipName) throws IllegalAccessException {
        RabbitAddress rabbitAddress = null;
        if (!StringUtils.isEmpty(ipName)) {
            rabbitAddress = rabbitAddressMap.get(ipName);
        }
        if (rabbitAddress == null) {
            rabbitAddress = getFirstRabbitAddress(rabbitAddressMap);
            if (rabbitAddress == null) {
                throw new IllegalAccessException("没有配置该类型的Ip集群");
            }
        }
        return rabbitAddress;
    }

    public static RabbitTemplate getRabbitTemplate(String vHost, String ipName) throws IllegalAccessException {
        return getRabbitTemplate(vHost, getRabbitAddress(ipName));
    }

    private static String getKey(String vHost, String ip) {
        return ip + ":" + vHost;
    }

    public static RabbitTemplate getRabbitTemplate(String vHost, RabbitAddress rabbitAddress) {
        long time = System.currentTimeMillis();
        String ip = rabbitAddress.getIp();
        Integer port = rabbitAddress.getPort();
        String password = rabbitAddress.getPassword();
        String username = rabbitAddress.getUserName();

        CachingConnectionFactory connectionFactory = null;
        String key = getKey(vHost, ip);
        if (connectionFactoryCache.containsKey(key)) {
            connectionFactory = connectionFactoryCache.get(key);
        } else {
            connectionFactory = new CachingConnectionFactory(ip, port);
            connectionFactory.setChannelCacheSize(100);
            connectionFactory.setUsername(username);
            connectionFactory.setPassword(password);
            connectionFactory.setVirtualHost(vHost);
            // 必须要设置,生产者发送消息后的回调，这里RabbitTemplate必须是多例子模式的
            connectionFactory.setPublisherConfirms(true);
            connectionFactoryCache.put(key, connectionFactory);
        }

        if (!adminCache.containsKey(key)) {
            adminCache.put(key, new RabbitAdmin(connectionFactory));
        }

        if (!rabbitTemplateCache.containsKey(key)) {
            RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
            rabbitTemplate.setConfirmCallback(new ConfirmCallback());
            rabbitTemplateCache.put(key, rabbitTemplate);
        }
        long now = System.currentTimeMillis();
        logger.info("RabbitTemplateFactory.getRabbitTemplate(vHost, rabbitAddress, isPublisherConfirms) 花费时间：" + (now-time) + "ms");
        // 必须要设置,生产者发送消息后的回调，这里RabbitTemplate必须是多例子模式的
        return rabbitTemplateCache.get(key);
    }

    public static RabbitTemplate updateRabbitTemplate(String vHost, String ipName) throws IllegalAccessException {

        return updateRabbitTemplate(vHost, getRabbitAddress(ipName));
    }

    public static RabbitTemplate updateRabbitTemplate(String vHost, RabbitAddress rabbitAddress) {
        String ip = rabbitAddress.getIp();
        Integer port = rabbitAddress.getPort();
        String password = rabbitAddress.getPassword();
        String username = rabbitAddress.getUserName();

        String key = getKey(vHost, ip);

        CachingConnectionFactory connectionFactory = null;
        connectionFactory = new CachingConnectionFactory(ip, port);
        connectionFactory.setUsername(password);
        connectionFactory.setPassword(username);
        connectionFactory.setVirtualHost(vHost);
        connectionFactory.setPublisherConfirms(true); // 必须要设置,生产者发送消息后的回调，这里RabbitTemplate必须是多例子模式的
        connectionFactoryCache.put(key, connectionFactory);
        RabbitTemplate rabbitTemplate = new RabbitTemplate(connectionFactory);
        rabbitTemplateCache.put(key, rabbitTemplate);
        return rabbitTemplate;
    }

    private static RabbitAddress getFirstRabbitAddress(Map<String, RabbitAddress> rabbitAddressMap) throws IllegalAccessException {
        if (rabbitAddressMap.size() == 1) {
            for (Map.Entry<String, RabbitAddress> entry : rabbitAddressMap.entrySet()) {
                return entry.getValue();
            }
        } else {
            throw new IllegalAccessException("请设置发送的mq集群IP！");
        }
        return null;
    }

}
