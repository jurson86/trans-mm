package com.tuandai.transaction.client.config;

import com.tuandai.transaction.client.service.TMMServiceImpl;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties({TMMRabbitProperties.class})
public class TMMConfiguration {

    @Bean
    public TMMServiceImpl createTMMClient() {
        return new TMMServiceImpl();
    }

}
