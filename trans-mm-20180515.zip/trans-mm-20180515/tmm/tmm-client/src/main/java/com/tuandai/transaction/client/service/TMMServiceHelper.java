package com.tuandai.transaction.client.service;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.bo.Message;
import com.tuandai.transaction.client.model.BeginLog;
import com.tuandai.transaction.client.model.EndLog;
import org.springframework.util.StringUtils;

public class TMMServiceHelper {

    public static void checkBeginLogParam(BeginLog beginlog) {
        if (beginlog == null) {
            throw new IllegalArgumentException("beginLog 不能为空！");
        }

        if (beginlog.getUid() == null) {
            throw new IllegalArgumentException("beginLog的uid不能为空！");
        }
    }

    public static void checkEndLogParam(EndLog endLog) {
        if (endLog.getUid() == null || StringUtils.isEmpty(endLog.getMessage())) {
            throw new IllegalArgumentException("endLog的uid和message不能为空！");
        }
    }

    public static EventDefinition beginLog2EventDefinition(BeginLog beginLog) {
        EventDefinition event = new EventDefinition();
        event.setTopic(beginLog.getTopic());
        event.setMessage(JSONObject.toJSONString(new Message(beginLog.getUid(), beginLog.getMessage())));
        event.setCheckUrl(beginLog.getCheck());
        event.setEventType(EventDefinition.EventType.BEGIN);
        event.setServiceName(beginLog.getServiceName());
        event.setTime(System.currentTimeMillis());
        event.setUid(beginLog.getUid());
        return event;
    }

    public static EventDefinition endLog2EventDefinition(EndLog endLog) {
        EventDefinition event = new EventDefinition();
        event.setTopic(endLog.getTopic());
        event.setMessage(JSONObject.toJSONString(new Message(endLog.getUid(), endLog.getMessage())));
        event.setEventType(EventDefinition.EventType.END);
        event.setSendState(endLog.getState());
        event.setServiceName(endLog.getServiceName());
        event.setTime(System.currentTimeMillis());
        event.setUid(endLog.getUid());
        return event;
    }
}
