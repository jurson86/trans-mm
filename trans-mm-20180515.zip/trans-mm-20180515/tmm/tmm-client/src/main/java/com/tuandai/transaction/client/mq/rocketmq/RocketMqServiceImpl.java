package com.tuandai.transaction.client.mq.rocketmq;

import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.mq.inf.MqService;

public class RocketMqServiceImpl implements MqService {

    @Override
    public void sendMessage(EventDefinition eventDefinition) throws Exception {

    }
}
