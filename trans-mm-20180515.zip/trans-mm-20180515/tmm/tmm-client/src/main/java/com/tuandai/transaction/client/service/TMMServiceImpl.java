package com.tuandai.transaction.client.service;

import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.config.SettingSupport;
import com.tuandai.transaction.client.impl.*;
import com.tuandai.transaction.client.inf.LogAnalyzerService;
import com.tuandai.transaction.client.inf.LogEventService;
import com.tuandai.transaction.client.inf.ZabbixService;
import com.tuandai.transaction.client.model.BeginLog;
import com.tuandai.transaction.client.model.EndLog;
import com.tuandai.transaction.client.model.RabbitMQTopic;
import com.tuandai.transaction.client.mq.DefaultMqServiceFactory;
import com.tuandai.transaction.client.mq.MqSender;
import com.tuandai.transaction.client.mq.rabbitmq.RabbitTemplateFactory;
import com.tuandai.transaction.client.service.inf.TMMService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * 日志事件处理器
 */
public class TMMServiceImpl extends SimpleEventDefinitionRegistry implements TMMService, ApplicationContextAware {

    private static final Logger logger = LoggerFactory.getLogger(TMMServiceImpl.class);

    private LogEventService logEventService = null;

    private LogAnalyzerService logAnalyzerService;

    private DatadirCleanupManager datadirCleanupManager;

    private TMMServiceThread tMMServiceThread;

    private ZabbixService zabbixService;

    private MqSender mqSender;

    private volatile boolean stop = false;

    public TMMServiceImpl() {
    }

    public void initTMMServiceImpl() {
        this.logEventService =  new LogEventServiceImpl();
        this.logAnalyzerService = new LogAnalyzerServiceImpl(this);
        this.datadirCleanupManager = new DatadirCleanupManager();
        this.tMMServiceThread = new TMMServiceThread();
        this.zabbixService = new ZabbixServiceImpl();
        this.mqSender = new MqSender(new DefaultMqServiceFactory());
    }

    //---------------------------------------------- TMMService 接口实现 -----------------------------------------------

    @Override
    public Boolean sendTransBeginToFlume(BeginLog beginLog) {
        logger.info("TMMServiceImpl.sendTransBeginToFlume(), beginLog:" + beginLog);
        TMMServiceHelper.checkBeginLogParam(beginLog);
        logEventService.writeLogEvent(TMMServiceHelper.beginLog2EventDefinition(beginLog));
        return true;
    }

    @Override
    public Boolean sendTransEndToFlume(EndLog endLog) {
        logger.info("TMMServiceImpl.sendTransEndToFlume(), endLog:" + endLog);
        TMMServiceHelper.checkEndLogParam(endLog);
        logEventService.writeLogEvent(TMMServiceHelper.endLog2EventDefinition(endLog));
        return true;
    }

    @Override
    public void shutdown() {
        stop = true;
    }

    @Override
    public Map<String, Integer> monitorData() {
        Map<String, Integer> result = zabbixService.allMonitor();
        int beginSize = this.getBeginMap().size();
        int endSize = this.getEndMap().size();
        int mqSize =  this.getMqMap().size();
        int checkSize = this.getCheckMap().size();
        result.put("beginMap", beginSize);
        result.put("endMap",endSize);
        result.put("mqMap", mqSize);
        result.put("checkMap", checkSize);
        return result;
    }

    // ----------------------------------------------- ApplicationContextAware 接口实现 --------------------------------

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        // 初始化配置器
        SettingSupport.init(applicationContext);
        // 初始化父类
        this.init();
        // 初始化TMMServiceImpl
        this.initTMMServiceImpl();
        // 初始化 mq
        RabbitTemplateFactory.initParam(SettingSupport.getRabbitAddressMap());
        // 启动线程
        tMMServiceThread.start();
        // 启动删除文件定时任务
        datadirCleanupManager.start();
    }

    // -----------------------------------------------------------------------------------------------------------------

    class TMMServiceThread extends Thread {
        @Override
        public void run() {
            setName("tmm-mq-service");
            executor();
        }
    }

    public void executor() {
        // 加载磁盘数据
        this.loadAllPersistentEventDefinition();
        // 加载checkpoint数据
        logEventService.loadCheckpoint();
        int batchSize = SettingSupport.getBatchSize();
        while (!stop) {
            try {
                Thread.sleep(500);

                long startTime = System.currentTimeMillis();
                // 读取数据
                List<EventDefinition> events = logEventService.readLogEvent(batchSize);
                // 分析发送mq
                mqSender.sendMq(events, new MqSender.SendMqHandler() {
                    @Override
                    public EventDefinition preProcess(EventDefinition preEventDefinition) {
                        // 发送前先分析日志
                        EventDefinition resultEventDefinition = logAnalyzerService.analysis(preEventDefinition);
                        logger.info("MqSender.sendMq().preProcess(), 分析结果为：" + resultEventDefinition);
                        return resultEventDefinition;
                    }
                });

                // 发送check数据
                List<EventDefinition> checkEvents = getCheckStr(this.getCheckDefinitionMap());
                mqSender.sendMq(checkEvents);

                // 发送确认失败的消息
                List<EventDefinition> confirmFailList = getResendMq(batchSize);
                mqSender.sendMq(confirmFailList);

                // 持久化
                this.persistentEventDefinition();
                // 更新checkPoint
                logEventService.persistentCheckpoint();
                long time = System.currentTimeMillis() - startTime;
                if (time > 100) {
                    logger.info(" write log excuse time =============>：[" + time + "ms]");
                }
            } catch (Exception e) {
                logger.warn("error: {}", e);
                // 重置checkpoint文件
                logEventService.resetCheckpoint();
            }
        }
    }

    private List<EventDefinition> getCheckStr(Map<String, EventDefinition> checkMap) {
        if (checkMap.size() <= 0) {
            return null;
        }

        Map<String, List<EventDefinition>> mapGroup = new HashMap<>();

        for (Map.Entry<String, EventDefinition> entry : checkMap.entrySet()) {
            EventDefinition event = entry.getValue();
            RabbitMQTopic rabbitMQTopic = JSONObject.parseObject(event.getTopic(), RabbitMQTopic.class);
            if (mapGroup.containsKey(rabbitMQTopic.getIp())) {
                mapGroup.get(rabbitMQTopic.getIp()).add(event);
            } else {
                List<EventDefinition> list = new ArrayList<>();
                list.add(event);
                mapGroup.put(rabbitMQTopic.getIp(), list);
            }
        }

        List<EventDefinition> resultList = new ArrayList<>();
        if (mapGroup.size() > 0) {
            for (Map.Entry<String, List<EventDefinition>> entry : mapGroup.entrySet()) {
                String result = "";
                EventDefinition eventDefinition = new EventDefinition();
                List<EventDefinition> list = entry.getValue();
                for (EventDefinition event : list) {
                    result = result + JSONObject.toJSONString(event)  + "\n";
                }
                eventDefinition.setMessage(result);

                RabbitMQTopic tmp = new RabbitMQTopic();
                tmp.setIp(entry.getKey());
                tmp.setExchangeType("fanout");
                tmp.setExchange("tmm_check");
                tmp.setvHost("/tmm_vhost");
                eventDefinition.setTopic(JSONObject.toJSONString(tmp));
                String msgId = UUID.randomUUID().toString();
                eventDefinition.setUid(msgId);
                resultList.add(eventDefinition);
            }
        }

        if (!CollectionUtils.isEmpty(resultList)) {
            logger.info("TMMServiceImpl.getCheckStr(), 需要发送check的消息为：" + resultList);
        }
        return resultList;
    }

    private List<EventDefinition> getResendMq(int batchSize) {
        long dt = System.currentTimeMillis() - 60000;
        Map<String, EventDefinition> mqMap = this.getMqMap();
        if (mqMap.size() * 2 > batchSize) {
            if (mqMap.size() > batchSize) {
                throw new IllegalArgumentException("mqMap 过大，checkpoint重置！");
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                logger.error("阻塞mqMap失败", e);
            }
        }

        List<EventDefinition> result = new ArrayList<>();
        Iterator<Map.Entry<String, EventDefinition>> iterator = mqMap.entrySet().iterator();
        while(iterator.hasNext()) {
            Map.Entry<String, EventDefinition> entry = iterator.next();
            EventDefinition value = entry.getValue();
            if (value.getGoMapTime() <  dt) {
                result.add(entry.getValue());
            }
        }
        if (!CollectionUtils.isEmpty(result)) {
            logger.info("TMMServiceImpl.getResendMq(),需要重发的消息为：" + result);
        }
        return result;
    }

}
