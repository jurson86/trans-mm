package com.tuandai.transaction.client.mq.rabbitmq;

import com.tuandai.transaction.client.bo.EventDefinition;
import com.tuandai.transaction.client.config.SettingSupport;
import com.tuandai.transaction.client.inf.EventDefinitionRegistry;
import com.tuandai.transaction.client.service.TMMServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.support.CorrelationData;

public class ConfirmCallback implements RabbitTemplate.ConfirmCallback {

    private static final Logger logger = LoggerFactory.getLogger(ConfirmCallback.class);

    @Override
    public void confirm(CorrelationData correlationData, boolean ack, String cause) {
        if (ack) {
            EventDefinitionRegistry registry = SettingSupport.context.getBean(TMMServiceImpl.class);
            registry.removeEventDefinition(correlationData.getId(), EventDefinition.EventType.MQ);
        } else {
            logger.warn("发送mq确认失败,cause:" + cause);
        }
    }

}
