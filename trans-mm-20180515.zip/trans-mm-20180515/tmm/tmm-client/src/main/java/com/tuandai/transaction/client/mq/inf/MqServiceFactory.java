package com.tuandai.transaction.client.mq.inf;

public interface MqServiceFactory {

    MqService createMqService();

}
