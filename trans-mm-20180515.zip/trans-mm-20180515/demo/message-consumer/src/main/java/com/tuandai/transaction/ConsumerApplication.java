package com.tuandai.transaction;

import com.tuandai.transaction.client.consumer.DeclareDeadQueue;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class ConsumerApplication {

	public static void main(String[] args) {
		 SpringApplication.run(ConsumerApplication.class, args);
	}

	// ------------------------------------------业务队列一
	@Bean
	public DeclareDeadQueue createAmqpConfig() {
		return new DeclareDeadQueue("demoQu", "myVhost", "mychange");
	}

	@Bean
	public FanoutExchange mychange() {
		return  new FanoutExchange("mychange");
	}

	@Bean
	public Binding bindingDemoQuAndMychange(@Qualifier("demoQu") Queue queue, @Qualifier("mychange") FanoutExchange fanoutExchange ) {
		return BindingBuilder.bind(queue).to(fanoutExchange);
	}


	// -----------------------------------------业务队列二
//	@Bean
//	public DeclareDeadQueue createAmqpConfig2() {
//		return new DeclareDeadQueue("demoQu2", "myVhost", "mychange");
//	}
//
//	@Bean
//	public Binding bindingDemoQu2AndMychange(@Qualifier("demoQu2") Queue queue, @Qualifier("mychange") FanoutExchange fanoutExchange) {
//		return BindingBuilder.bind(queue).to(fanoutExchange);
//	}




}
