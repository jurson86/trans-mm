package com.tuandai.transaction.controller;

import java.io.IOException;
import java.util.Random;
import java.util.UUID;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tuandai.transaction.client.bo.SendState;
import com.tuandai.transaction.client.model.BeginLog;
import com.tuandai.transaction.client.model.EndLog;
import com.tuandai.transaction.client.model.RabbitMQTopic;
import com.tuandai.transaction.client.service.TMMService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.tuandai.transaction.domain.TransactionCheck;
import com.tuandai.transaction.service.inf.TransactionCheckService;

@RestController
@RequestMapping(value = "/msg")
public class MsgClientController {

	private static final Logger logger = LoggerFactory.getLogger(MsgClientController.class);

	@Autowired
	private TransactionCheckService transactionCheckService;

	@Autowired
	private TMMService tMMService;

	private static Random random = new Random();
	private static Random random2 = new Random();
	
	/**
	 * 发送事务消息
	 *
	 * @param presendbackurl
	 * @return
	 */
	@RequestMapping(value = "/producer", method = RequestMethod.GET)
	public String Producer(@RequestParam String msg) throws IOException {

		String msgId = UUID.randomUUID().toString();
		long startTime = System.currentTimeMillis();		
        // 记录发送的消息

        //RpcClientFacade.sendDataToFlume(transactionCheck.toString());
		RabbitMQTopic rabbitMQTopic = new RabbitMQTopic();
		rabbitMQTopic.setvHost("myVhost");
		rabbitMQTopic.setExchange("mychange");
		rabbitMQTopic.setExchangeType("fanout");
		//rabbitMQTopic.setRouteKey("route");
		//rabbitMQTopic.setCustomExchange(true);
		if (msg.equals("73")) {
            rabbitMQTopic.setIp("first");
		} else {
            rabbitMQTopic.setIp("default");
		}


		// 打印开始日志
		BeginLog beginLog = new BeginLog();
		beginLog.setCheck("/msg/tmm/check");
            beginLog.setMessage(null);
		beginLog.setServiceName("transaction-producer");
		beginLog.setTopic(rabbitMQTopic.toJSONString());
		beginLog.setUid(msgId);
		tMMService.sendTransBeginToFlume(beginLog);

		// 打印结束日志
		EndLog endLog = new EndLog();
		if (random.nextInt(4)  == 3) {
			// 本地事务
			endLog.setState(SendState.CANCEL);
		} else {
			TransactionCheck transactionCheck = new TransactionCheck(msgId, msg);
			transactionCheckService.insertTransactionCheck(transactionCheck);
			long time = System.currentTimeMillis() - startTime;
			logger.info("mysql存储消息执行的时间：[" + time + "ms]");
			endLog.setState(SendState.COMMIT);
		}

		endLog.setMessage("hello world");
		endLog.setServiceName("transaction-producer");
		endLog.setUid(msgId);
		if (random2.nextInt(1000)  != 999) {
			tMMService.sendTransEndToFlume(endLog);
		}
		return msg;
	}


	@RequestMapping(value = "/producer/test", method = RequestMethod.GET)
	public String Producer2(@RequestParam String msgId, @RequestParam String msg) throws IOException {

		long startTime = System.currentTimeMillis();
		// 记录发送的消息

		//RpcClientFacade.sendDataToFlume(transactionCheck.toString());
		RabbitMQTopic rabbitMQTopic = new RabbitMQTopic();
		rabbitMQTopic.setvHost("myVhost");
		rabbitMQTopic.setExchange("mychange");
		rabbitMQTopic.setExchangeType("fanout");
		//rabbitMQTopic.setRouteKey("route");
		rabbitMQTopic.setCustomExchange(true);

		// 打印开始日志
		BeginLog beginLog = new BeginLog();
		beginLog.setCheck("/msg/tmm/check");
		beginLog.setMessage(null);
		beginLog.setServiceName("transaction-producer");
		beginLog.setTopic(rabbitMQTopic.toJSONString());
		beginLog.setUid(msgId);
		tMMService.sendTransBeginToFlume(beginLog);

		// 打印结束日志
		EndLog endLog = new EndLog();

		TransactionCheck transactionCheck = new TransactionCheck(msgId, "压力测试" + msg);
		transactionCheckService.insertTransactionCheck(transactionCheck);
		long time = System.currentTimeMillis() - startTime;
		logger.info("mysql存储消息执行的时间：[" + time + "ms]");
		endLog.setState(SendState.COMMIT);

		endLog.setMessage(msg);
		endLog.setServiceName("transaction-producer");
		endLog.setUid(msgId);
		tMMService.sendTransEndToFlume(endLog);
		return msgId;
	}


	@RequestMapping(value = "/tmm/check", method = RequestMethod.POST)
	public String  check(@RequestBody String body) {
		String uid = JSON.parseObject(body).getString("uid");


		RabbitMQTopic rabbitMQTopic = new RabbitMQTopic();
		rabbitMQTopic.setvHost("myVhost");
		rabbitMQTopic.setExchange("mychange");
		rabbitMQTopic.setExchangeType("fanout");
		//rabbitMQTopic.setRouteKey("route");
		rabbitMQTopic.setCustomExchange(true);

		EndLog endLog = new EndLog();
		if (random.nextInt(4)  == 3) {
			endLog.setState(SendState.CANCEL);
		} else {
			endLog.setState(SendState.COMMIT);
		}
		endLog.setMessage("重发！check");
		endLog.setServiceName("transaction-producer");
		endLog.setUid(uid);
		endLog.setTopic(rabbitMQTopic.toJSONString());
		String result = JSONObject.toJSONString(endLog);
		logger.info("回调返回参数：" + result);
		return result;
	}

}