package com.tuandai.transaction.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.tuandai.transaction.repository.TransactionCheckRepository;


@Component
public class InitailDBTables {

	@Autowired
	private TransactionCheckRepository transactionCheckRepository;


	public void createTables() {
		transactionCheckRepository.createIfNotExistsTable();
	}
}
