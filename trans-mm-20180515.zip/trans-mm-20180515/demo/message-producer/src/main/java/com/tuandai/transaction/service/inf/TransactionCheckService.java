package com.tuandai.transaction.service.inf;

import com.tuandai.transaction.domain.TransactionCheck;

import java.util.List;

public interface TransactionCheckService {

	List<String> messageNotAcceptCheck(List<String> transactionIds);

	List<String> messageRepeatAcceptCheck(List<String> transactionIds);

    void insertTransactionCheck(TransactionCheck transactionCheck);

    void deleteTransactionCheck(String msgId);

    TransactionCheck queryTransactionCheckById(String  msgId);
}
