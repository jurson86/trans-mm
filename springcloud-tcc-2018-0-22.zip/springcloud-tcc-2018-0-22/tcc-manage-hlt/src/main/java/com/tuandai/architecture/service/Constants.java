package com.tuandai.architecture.service;

public class Constants {

	public static Integer checkResult=0;
	
	public static Integer tryResult=0;
	
	public static Integer cancelResult=0;
	
	public static Integer confirmResult=0;
	
}
