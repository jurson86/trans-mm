package com.tuandai.transaction.constant;

public class Constants {
	public static final String RES_URL_SPLIT = ",";
}
